from enum import Enum


class AutoStrEnum(str, Enum):
    """
    string based enum that supports enum.auto()
    """
    @staticmethod
    def _generate_next_value_(name: str, start: int, count: int, last_values: list):
        return name