from ratings.feature_ratings import BooleanFeatureRatings as Bool
from ratings.feature_ratings import FloatFeatureRatings as Float
import pyspark.sql.functions as F
from pyspark.sql.column import Column
from typing import Dict
from enum import auto
from auto_str_enum import AutoStrEnum
from collections import ChainMap


class PersonaTags(AutoStrEnum):

    # these are defined according to
    # the 4 groupings in https://www.smartone.com/en/mobile_and_price_plans/roaming/
    FREQUENT_TRAVELER_CHINA_MACAU = auto()
    FREQUENT_TRAVELER_APAC = auto()
    FREQUENT_TRAVELER_WORLDWIDE = auto()
    FREQUENT_TRAVELER_OTHER = auto()

    HIGH_TRAVEL_INTENTION_CHINA_AND_MACAU = auto()

    HIGH_TRAVEL_INTENTION_OVERSEAS = auto()
    HIGH_TRAVEL_INTENTION_OVERSEAS_1 = auto()
    HIGH_TRAVEL_INTENTION_OVERSEAS_2 = auto()
    HIGH_TRAVEL_INTENTION_OVERSEAS_3 = auto()
    HIGH_TRAVEL_INTENTION_OVERSEAS_4 = auto()
    HIGH_TRAVEL_INTENTION_OVERSEAS_5 = auto()

    UNIVERSITY_STUDENT = auto()

    MONTHLY_INCOME_TIER_1 = auto()
    MONTHLY_INCOME_TIER_2 = auto()
    MONTHLY_INCOME_TIER_3 = auto()
    MONTHLY_INCOME_TIER_4 = auto()
    MONTHLY_INCOME_TIER_5 = auto()

    FAMILY_WITH_KIDS_AGE_0_2 = auto()
    FAMILY_WITH_KIDS_AGE_2_6 = auto()
    FAMILY_WITH_KIDS_AGE_6_12 = auto()
    FAMILY_WITH_KIDS_AGE_12_PLUS = auto()
    FAMILY_WITH_KIDS = auto()
    FAMILY_WITH_DEPENDENT_ELDERLY = auto()

    MOBILITY_FREQUENT_STAY_IN_SAME_DISTRICT = auto()
    MOBILITY_FREQUENT_ROUND_TRIP_BY_DISTRICT = auto()
    MOBILITY_FREQUENT_VISIT_MULTI_DISTRICTS = auto()

    LONG_STAY_CHINA_TRAVELER = auto()
    LONG_STAY_JAPAN_TRAVELER = auto()
    LONG_STAY_TAIWAN_TRAVELER = auto()
    LONG_STAY_KOREA_TRAVELER = auto()
    LONG_STAY_APAC_TRAVELER = auto()
    LONG_STAY_NON_APAC_TRAVELER = auto()

    LONG_HAUL_TRAVELER = auto()

    HEAVY_ZOOM_APP_USER = auto()
    HEAVY_MICROSOFT_TEAMS_APP_USER = auto()

    HEAVY_STREAMING_APPS_USER = auto()
    HEAVY_STREAMING_APPS_USER_TIER_1 = auto()
    HEAVY_STREAMING_APPS_USER_TIER_2 = auto()
    HEAVY_STREAMING_APPS_USER_TIER_3 = auto()
    HEAVY_STREAMING_APPS_USER_TIER_4 = auto()
    HEAVY_STREAMING_APPS_USER_TIER_5 = auto()

    NORMAL_MTR_USER = auto() # 14 days with noraml use MTR: 1800+ seoncds
    HEAVY_MTR_USER = auto()  # 14 days with heavy use MTR: 3600+ seconds
    ALWAYS_ON_THE_ROAD = auto() 

    FREQUENT_GOLDEN_MTR_USER_FULL = auto()
    FREQUENT_GOLDEN_MTR_USER_2024 = auto()
    FREQUENT_GOLDEN_MTR_USER_2025 = auto()

    NORTHBOUND_DRIVER = auto()
    ACTIVE_DRIVER = auto()

    FREQUENT_MICROSOFT_TEAMS_USER = auto()
    FREQUENT_MICROSOFT_TEAMS_USER_5GHBB = auto()
    FREQUENT_ZOOM_USER = auto()
    FREQUENT_ZOOM_USER_5GHBB = auto()
    FREQUENT_STREAMING_NETFLIX_USER = auto()
    FREQUENT_STREAMING_DISNEYPLUS_USER = auto()
    FREQUENT_STREAMING_YOUTUBE_USER = auto()
    FREQUENT_STREAMING_MYTVSUPER_USER = auto()
    FREQUENT_STREAMING_VIUTV_USER = auto()
    FREQUENT_STREAMING_NETFLIX_USER_5GHBB = auto()
    FREQUENT_STREAMING_DISNEYPLUS_USER_5GHBB = auto()
    FREQUENT_STREAMING_YOUTUBE_USER_5GHBB = auto()
    FREQUENT_STREAMING_MYTVSUPER_USER_5GHBB = auto()
    FREQUENT_STREAMING_VIUTV_USER_5GHBB = auto()
    FREQUENT_STREAMING_APPS_USER = auto()
    FREQUENT_STREAMING_APPS_USER_5GHBB = auto()

    NORMAL_CASUAL_MOBILE_GAMER = auto()
    NORMAL_CONSOLE_GAMER = auto()
    NORMAL_GENERAL_GAMER = auto()
    NORMAL_NON_CASUAL_MOBILE_GAMER = auto()
    FREQUENT_CASUAL_MOBILE_GAMER = auto()
    FREQUENT_CONSOLE_GAMER = auto()
    FREQUENT_GENERAL_GAMER = auto()
    FREQUENT_NON_CASUAL_MOBILE_GAMER = auto()

    POTENTIAL_HOUSE_MOVER = auto()
    
    HANDSET_CHANGE_HIGH_PROBABILITY = auto()
    HEAVY_MESSAGING_APP_MOBILE_UPLINK_USAGE = auto()
    MOBILE_DATA_SPIKE = auto()

    FREQUENT_VISIT_DISNEY = auto()

    DISNEY_PLUS_VIEWER = auto()


def _traveler_tags():
    return {
        PersonaTags.FREQUENT_TRAVELER_CHINA_MACAU: (
            F.col(Bool.ROAMING_TRIP_COUNT_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
            F.col(Bool.ROAMING_TRIP_COUNT_MACAU_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1)
        ),

        PersonaTags.FREQUENT_TRAVELER_APAC: (
                F.col(Bool.ROAMING_TRIP_COUNT_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_MACAU_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_PRODUCT_AUS_NEWZ_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1)
        ),
        PersonaTags.FREQUENT_TRAVELER_WORLDWIDE: (
                F.col(Bool.ROAMING_TRIP_COUNT_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_MACAU_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_PRODUCT_AUS_NEWZ_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_PRODUCT_EUROPE_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_PRODUCT_US_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
                F.col(Bool.ROAMING_TRIP_COUNT_PRODUCT_OTHER_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1)
        ),

        PersonaTags.FREQUENT_TRAVELER_OTHER: (
            F.col(Bool.ROAMING_TRIP_COUNT_PRODUCT_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1) |
            F.col(Bool.ROAMING_TRIP_COUNT_PRODUCT_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1)
        ),

        PersonaTags.LONG_STAY_CHINA_TRAVELER: F.col(Bool.ROAMING_TRIP_AVG_DURATION_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        PersonaTags.LONG_STAY_JAPAN_TRAVELER: F.col(Bool.ROAMING_TRIP_AVG_DURATION_JAPAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        PersonaTags.LONG_STAY_TAIWAN_TRAVELER: F.col(Bool.ROAMING_TRIP_AVG_DURATION_TAIWAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        PersonaTags.LONG_STAY_KOREA_TRAVELER: F.col(Bool.ROAMING_TRIP_AVG_DURATION_KOREA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        PersonaTags.LONG_STAY_APAC_TRAVELER: F.col(Bool.ROAMING_TRIP_AVG_DURATION_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        PersonaTags.LONG_STAY_NON_APAC_TRAVELER: F.col(Bool.ROAMING_TRIP_AVG_DURATION_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        PersonaTags.LONG_HAUL_TRAVELER: F.col(
            Bool.ROAMING_TRIP_COUNT_RATIO_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1_OR_IS_100
        ),

        PersonaTags.HIGH_TRAVEL_INTENTION_CHINA_AND_MACAU: F.col(Bool.TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1),

        PersonaTags.HIGH_TRAVEL_INTENTION_OVERSEAS:
            (F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1) |
             F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2) |
             F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3) |
             F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4) |
             F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5)),

        PersonaTags.HIGH_TRAVEL_INTENTION_OVERSEAS_1: F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1),
        PersonaTags.HIGH_TRAVEL_INTENTION_OVERSEAS_2: F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2),
        PersonaTags.HIGH_TRAVEL_INTENTION_OVERSEAS_3: F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3),
        PersonaTags.HIGH_TRAVEL_INTENTION_OVERSEAS_4: F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4),
        PersonaTags.HIGH_TRAVEL_INTENTION_OVERSEAS_5: F.col(Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5),

    }


def _geo_movement_tags():
    return {
        PersonaTags.MOBILITY_FREQUENT_STAY_IN_SAME_DISTRICT:(
            (
                (F.col(Float.MAX_DAY_COUNT_BY_DISTRICT_WHEN_STAY_IN_SAME_DISTRICT) >= 18) &
                ((F.col(Float.AGE) >= 18) & (F.col(Float.AGE) <= 64))
            ) 
        ),
        PersonaTags.MOBILITY_FREQUENT_ROUND_TRIP_BY_DISTRICT:(
            (
                (F.col(Float.MAX_DAY_COUNT_BY_TRIP_WHEN_ROUND_TRIP) >= 14 ) &
                ((F.col(Float.AGE) >= 18) & (F.col(Float.AGE) <= 64)) &
                # NOT PersonaTags.MOBILITY_ONE_DISTRICT
                ~(  (F.col(Float.MAX_DAY_COUNT_BY_DISTRICT_WHEN_STAY_IN_SAME_DISTRICT).isNotNull()) &
                    (F.col(Float.MAX_DAY_COUNT_BY_DISTRICT_WHEN_STAY_IN_SAME_DISTRICT) >= 18)
                )
            ) 
        ),
        PersonaTags.MOBILITY_FREQUENT_VISIT_MULTI_DISTRICTS: (
            (
                (
                    (F.col(Float.ROUND_TRIP_MID_POINT_ENTROPY) >= 2.4 ) |
                    (F.col(Float.DAY_COUNT_WHEN_TRAVEL_4_PLUS_DISTRICTS) >= 14 )
                ) &

                ((F.col(Float.AGE) >= 18) & (F.col(Float.AGE) <= 64)) &
                # NOT PersonaTags.MOBILITY_TWO_DISTRICT OR PersonaTags.MOBILITY_TWO_DISTRICT
                # If not add ".isNotNull()", the output will filter out more than ten thousands NULL value CUST_NUM AND SUBR_NUM,
                # which is wrongly filtered out a set of CUST_NUM AND SUBR_NUM with NULL value in
                # MAX_DAY_COUNT_BY_TRIP_WHEN_ROUND_TRIP and MAX_DAY_COUNT_BY_DISTRICT_WHEN_STAY_IN_SAME_DISTRICT column
                ~(
                    (   (F.col(Float.MAX_DAY_COUNT_BY_TRIP_WHEN_ROUND_TRIP).isNotNull()) &
                        (F.col(Float.MAX_DAY_COUNT_BY_TRIP_WHEN_ROUND_TRIP) >= 14) ) |

                    (   (F.col(Float.MAX_DAY_COUNT_BY_DISTRICT_WHEN_STAY_IN_SAME_DISTRICT).isNotNull()) &
                        (F.col(Float.MAX_DAY_COUNT_BY_DISTRICT_WHEN_STAY_IN_SAME_DISTRICT) >= 18)
                    )
                )
            ) 
        ),
        PersonaTags.HEAVY_MTR_USER:(F.col(Float.DAY_COUNT_MTR_HEAVY_USAGE_30D) >= 14),
        PersonaTags.NORMAL_MTR_USER:( (F.col(Float.DAY_COUNT_MTR_NORMAL_USAGE_30D) >= 14 ) &
                                    ~ (F.col(Float.DAY_COUNT_MTR_HEAVY_USAGE_30D) >= 14 )),
        PersonaTags.ALWAYS_ON_THE_ROAD:(
            (F.col(Float.DAY_COUNT_WHEN_TRAVEL_4_PLUS_DISTRICTS) >= 14) |
            (F.col(Float.DAY_COUNT_MTR_HEAVY_USAGE_30D) >= 14)
        ),
        PersonaTags.FREQUENT_GOLDEN_MTR_USER_FULL:(F.col(Float.DAY_COUNT_VISITED_GOLDEN_MTR_FULL_30D) >= 14),
        PersonaTags.FREQUENT_GOLDEN_MTR_USER_2024:(F.col(Float.DAY_COUNT_VISITED_GOLDEN_MTR_2024_30D) >= 14),
        PersonaTags.FREQUENT_GOLDEN_MTR_USER_2025:(F.col(Float.DAY_COUNT_VISITED_GOLDEN_MTR_2025_30D) >= 14),

        PersonaTags.NORTHBOUND_DRIVER: (
            (F.col(Float.WEBLOG_TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D) >= 2) &
            (F.col(Float.WEBLOG_NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D) >= 1) &
            (F.col(Float.WEBLOG_MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D) >= 1)
        ),

        PersonaTags.ACTIVE_DRIVER: (
            (F.col(Bool.CDP_IS_SHKP_MALL_PARKER)) |
            (F.col(Bool.WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN)) |
            (F.col(Bool.WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN)) |
            (F.col(Bool.WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN)) |
            (F.col(Bool.WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN)) |
            (F.col(Bool.WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN)) |
            (F.col(Bool.WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN)) |
            (F.col(Bool.WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN))
        ),
        PersonaTags.FREQUENT_VISIT_DISNEY: (
            F.col(Float.DAY_COUNT_VISITED_DISNEY_LAST_12_MONTHS) > 2
        )
    }


def _app_usage_tags():

    DEFINITION_FREQUENT_GENERAL_GAMER = (
            (F.col(Float.WEBLOG_MISCELLANEOUS_GAME_DAY_CNT_PAST_30D) >= 20)
            | (F.col(Float.WEBLOG_CONSOLE_GAME_DAY_CNT_PAST_30D) >= 20)
            | (F.col(Float.WEBLOG_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) >= 20)
            | (F.col(Float.WEBLOG_NON_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) >= 20)
        )
    
    return {
        PersonaTags.HEAVY_STREAMING_APPS_USER: F.col(
            Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK
        ).isNotNull(),
        PersonaTags.HEAVY_STREAMING_APPS_USER_TIER_1: (
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) >= 0) &
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) < 0.2)
        ),
        PersonaTags.HEAVY_STREAMING_APPS_USER_TIER_2: (
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) >= 0.2) &
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) < 0.4)
        ),
        PersonaTags.HEAVY_STREAMING_APPS_USER_TIER_3: (
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) >= 0.4) &
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) < 0.6)
        ),
        PersonaTags.HEAVY_STREAMING_APPS_USER_TIER_4: (
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) >= 0.6) &
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) < 0.8)
        ),
        PersonaTags.HEAVY_STREAMING_APPS_USER_TIER_5:
            (F.col(Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK) >= 0.8),


        PersonaTags.HEAVY_ZOOM_APP_USER: F.col(Bool.CNSS_APP_ZOOM_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT),
        PersonaTags.HEAVY_MICROSOFT_TEAMS_APP_USER: F.col(Bool.CNSS_APP_MS_TEAMS_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT),

        PersonaTags.FREQUENT_MICROSOFT_TEAMS_USER: (F.col(Bool.CNSS_APP_MS_TEAMS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_MICROSOFT_TEAMS_USER_5GHBB: (F.col(Bool.CNSS_APP_MS_TEAMS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_ZOOM_USER: (F.col(Bool.CNSS_APP_ZOOM_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_ZOOM_USER_5GHBB: (F.col(Bool.CNSS_APP_ZOOM_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),

        PersonaTags.FREQUENT_STREAMING_NETFLIX_USER: (F.col(Bool.CNSS_APP_NETFLIX_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_DISNEYPLUS_USER: (F.col(Bool.CNSS_APP_DISNEY_PLUS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_YOUTUBE_USER: (F.col(Bool.CNSS_APP_YOUTUBE_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_MYTVSUPER_USER: (F.col(Bool.CNSS_APP_MYTV_SUPER_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_VIUTV_USER: (F.col(Bool.CNSS_APP_VIU_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_NETFLIX_USER_5GHBB: (F.col(Bool.CNSS_APP_NETFLIX_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_DISNEYPLUS_USER_5GHBB: (F.col(Bool.CNSS_APP_DISNEY_PLUS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_YOUTUBE_USER_5GHBB: (F.col(Bool.CNSS_APP_YOUTUBE_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_MYTVSUPER_USER_5GHBB: (F.col(Bool.CNSS_APP_MYTV_SUPER_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),
        PersonaTags.FREQUENT_STREAMING_VIUTV_USER_5GHBB: (F.col(Bool.CNSS_APP_VIU_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)),

        PersonaTags.FREQUENT_STREAMING_APPS_USER: (
            (F.col(Bool.CNSS_APP_DISNEY_PLUS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)) |
            (F.col(Bool.CNSS_APP_MYTV_SUPER_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)) | 
            (F.col(Bool.CNSS_APP_NETFLIX_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)) |
            (F.col(Bool.CNSS_APP_VIU_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)) |
            (F.col(Bool.CNSS_APP_YOUTUBE_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT))
        ),

        PersonaTags.FREQUENT_STREAMING_APPS_USER_5GHBB: (
            (F.col(Bool.CNSS_APP_DISNEY_PLUS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)) |
            (F.col(Bool.CNSS_APP_MYTV_SUPER_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)) | 
            (F.col(Bool.CNSS_APP_NETFLIX_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)) |
            (F.col(Bool.CNSS_APP_VIU_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT)) |
            (F.col(Bool.CNSS_APP_YOUTUBE_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT))
        ),

        PersonaTags.NORMAL_CASUAL_MOBILE_GAMER:(
            (F.col(Float.WEBLOG_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) >= 4) & 
            (F.col(Float.WEBLOG_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) < 20)
        ),
        PersonaTags.NORMAL_CONSOLE_GAMER: (
            (F.col(Float.WEBLOG_CONSOLE_GAME_DAY_CNT_PAST_30D) >= 4) & 
            (F.col(Float.WEBLOG_CONSOLE_GAME_DAY_CNT_PAST_30D) < 20)
        ),
        PersonaTags.NORMAL_GENERAL_GAMER: (
            (
                ((F.col(Float.WEBLOG_MISCELLANEOUS_GAME_DAY_CNT_PAST_30D) >= 4) & (F.col(Float.WEBLOG_MISCELLANEOUS_GAME_DAY_CNT_PAST_30D) < 20))
                | ((F.col(Float.WEBLOG_NON_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) >= 4) & (F.col(Float.WEBLOG_NON_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) < 20))
                | ((F.col(Float.WEBLOG_CONSOLE_GAME_DAY_CNT_PAST_30D) >= 4) & (F.col(Float.WEBLOG_CONSOLE_GAME_DAY_CNT_PAST_30D) < 20))
                | ((F.col(Float.WEBLOG_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) >= 4) & (F.col(Float.WEBLOG_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) < 20))
            ) &
            ~DEFINITION_FREQUENT_GENERAL_GAMER
        ),
        PersonaTags.NORMAL_NON_CASUAL_MOBILE_GAMER: (
            (F.col(Float.WEBLOG_NON_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) >= 4) & (F.col(Float.WEBLOG_NON_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) < 20)
        ),
        PersonaTags.FREQUENT_CASUAL_MOBILE_GAMER:(
            F.col(Float.WEBLOG_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) >= 20
        ),
        PersonaTags.FREQUENT_CONSOLE_GAMER: (
            F.col(Float.WEBLOG_CONSOLE_GAME_DAY_CNT_PAST_30D) >= 20
        ),
        PersonaTags.FREQUENT_GENERAL_GAMER: DEFINITION_FREQUENT_GENERAL_GAMER,
        PersonaTags.FREQUENT_NON_CASUAL_MOBILE_GAMER: (
            F.col(Float.WEBLOG_NON_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D) >= 20
        ),

        PersonaTags.HEAVY_MESSAGING_APP_MOBILE_UPLINK_USAGE: ( (F.col(Float.CNSS_APP_MOBILE_TOTAL_UPLINK_BYTES_PERCENTILE_RANK_30D) < 0.1 ) 
                                                         & (F.col(Float.CNSS_CATEGORY_MESSAGING_MOBILE_UPLOAD_GB_30D) > 1.0)
                                                        ),

        
        PersonaTags.MOBILE_DATA_SPIKE: ( (F.col(Float.WEBLOG_USAGE_DAILY_N_MONTHLY_AVG_RATIO) > 3.0) & 
                                        (F.col(Float.WEBLOG_USAGE_PREVIOIS_MONTH_GB) > 1.0) &
                                        ~(F.col(Bool.IS_HBB))
                                        ),


        PersonaTags.DISNEY_PLUS_VIEWER: (
            F.col(Bool.EBM_APP_IS_DISNEY_PLUS_USER)
        )
    }


def conditions() -> Dict[PersonaTags, Column]:

    others = {

        PersonaTags.UNIVERSITY_STUDENT: (
                (F.col(Float.AGE) >= 18) & (F.col(Float.AGE) <= 25) &
                (F.col(Float.UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25) >= 0.70) &
                (F.col(Bool.UNI_GEOLOCATION_AT_LEAST_3_DAYS_30D_ANY_6M))
            ),

        PersonaTags.MONTHLY_INCOME_TIER_1: (
                (F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) >= 0) &
                (F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) < 25000)
            ),
        PersonaTags.MONTHLY_INCOME_TIER_2: (
                (F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) >= 25000) &
                (F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) < 35000)
            ),
        PersonaTags.MONTHLY_INCOME_TIER_3: (
                (F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) >= 35000) &
                (F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) < 45000)
            ),
        PersonaTags.MONTHLY_INCOME_TIER_4: (
                (F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) >= 45000) &
                (F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) < 70000)
            ),
        PersonaTags.MONTHLY_INCOME_TIER_5: (
                F.col(Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME) >= 70000
            ),

        PersonaTags.FAMILY_WITH_KIDS: (
            (
                (F.col(Float.FAMILY_WITH_KIDS_RELATED_DOMAIN_CNT_180D) + F.col(Float.FAMILY_WITH_KIDS_RELATED_RED_FLAG_DOMAIN_CNT_180D) >= 2) |
                (F.col(Float.FAMILY_WITH_KIDS_RELATED_RED_FLAG_DOMAIN_CNT_180D) >= 1)
            ) &
                (F.col(Float.AGE) >= 20) & (F.col(Float.AGE) <= 55)
        ),
        PersonaTags.FAMILY_WITH_KIDS_AGE_0_2: (
            (
                (F.col(Float.FAMILY_WITH_KIDS_AGE_0_2_RELATED_DOMAIN_CNT_180D) >= 2)
            ) &
                (F.col(Float.AGE) >= 20) & (F.col(Float.AGE) <= 55)
        ),
        PersonaTags.FAMILY_WITH_KIDS_AGE_2_6: (
            (
                (F.col(Float.FAMILY_WITH_KIDS_AGE_2_6_RELATED_RED_FLAG_DOMAIN_CNT_180D) >= 1)
            ) &
                (F.col(Float.AGE) >= 20) & (F.col(Float.AGE) <= 55)
        ),
        PersonaTags.FAMILY_WITH_KIDS_AGE_6_12: (
            (
                (F.col(Float.FAMILY_WITH_KIDS_AGE_6_12_RELATED_RED_FLAG_DOMAIN_CNT_180D) >= 1)
            ) &
                (F.col(Float.AGE) >= 20) & (F.col(Float.AGE) <= 55)
        ),
        PersonaTags.FAMILY_WITH_KIDS_AGE_12_PLUS: (
            (
                (F.col(Float.FAMILY_WITH_KIDS_AGE_12_PLUS_RELATED_RED_FLAG_DOMAIN_CNT_180D) >= 1)
            ) &
                (F.col(Float.AGE) >= 20) & (F.col(Float.AGE) <= 55)
        ),
        PersonaTags.FAMILY_WITH_DEPENDENT_ELDERLY: (
            (
                (F.col(Float.FAMILY_WITH_DEPENDENT_ELDERLY_RELATED_DOMAIN_CNT_180D) >= 2)
            )
        ),

        PersonaTags.POTENTIAL_HOUSE_MOVER: (
            (
                (F.col(Float.WEBLOG_HOUSE_MOVING_DAY_CNT_PAST_30D) >= 1) &
                (F.col(Float.WEBLOG_HOUSE_RENTAL_DAY_CNT_PAST_30D) >= 1)
            ) |
            (F.col(Bool.CALLLOG_MOVING_COMPANY_CALLER))
        ),

        PersonaTags.HANDSET_CHANGE_HIGH_PROBABILITY: (F.col(Bool.HANDSET_CHANGE_HIGH_PROBABILITY) | F.col(Bool.HANDSET_REUSE_OLD))

    }

    return dict(ChainMap(others, _traveler_tags(), _geo_movement_tags(), _app_usage_tags()))