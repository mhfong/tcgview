from pyspark.sql import SparkSession, DataFrame
from datetime import datetime
from observability.subscriber_count import calc_subscriber_count_by_tag, calc_2_tag_overlap


def run(spark: SparkSession, run_date: datetime, version: str):
    path_date = run_date.strftime('%Y-%m-%d')

    data = calc_subscriber_count_by_tag(spark, run_date, version)
    data.coalesce(6).write.mode('overwrite').csv(
        f'dtap://TenantStorage/personas/observability/run_date={path_date}/version={version}',
        header=True
    )

    overlap = calc_2_tag_overlap(spark, run_date, version)
    overlap.coalesce(6).write.mode('overwrite').csv(
        f'dtap://TenantStorage/personas/observability/2_tag_overlap/run_date={path_date}/version={version}',
        header=True
    )


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='tags observability')
    parser.add_argument('run_date', metavar='yyyy-mm-dd', type=str)
    parser.add_argument('version', metavar='v', type=str)
    args = parser.parse_args()

    spark = SparkSession.builder.appName("persona-observe").getOrCreate()
    run_date = datetime.strptime(args.run_date, '%Y-%m-%d')

    run(spark, run_date, args.version)
