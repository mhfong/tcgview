from pyspark.sql import DataFrame
import pyspark.sql.functions as F
import paths
from datetime import datetime
import hashlib


class SideOutputWriter:
    def __init__(self, run_date: datetime, version: str):
        self.run_date = run_date
        self.version = version

    def _make_key_value(self, df, key_prefix):
        return df.limit(1).select(F.explode(F.array([
            F.struct(
                F.lit(key_prefix + c).alias('key'),
                F.col(c).alias('value')
            )
            for c in df.columns
        ])).alias('sideoutput')).select(
            'sideoutput.key', 'sideoutput.value'
        )

    def write(self, data: DataFrame, key_prefix=''):
        """
        save first row of data into key value columns

        Input:
        COL1 | COL2 | COL3 | ...
        val1 | val2 | val3 | ...

        writes
        key  | value
        key_prefix + COL1 | val1
        key_prefix + COL2 | val2
        ...

        :param data:
        :param key_prefix:
        :return:
        """
        col_hash = hashlib.sha256(
            (','.join(sorted(data.columns)) + ',' + key_prefix).encode()
        ).hexdigest()  # allows for overwriting

        self._make_key_value(data, key_prefix).write.mode('overwrite').csv(
            paths.side_output.format(  # csv because easier to put in mysql
                path_date=self.run_date.strftime('%Y-%m-%d'), version=self.version,
                col_hash=col_hash
            ),
            header=True
        )


class EchoSideOutput(SideOutputWriter):  # for unit tests

    def __init__(self):
        super().__init__(datetime(2000, 1, 1), '')
        self.data = None

    def write(self, data: DataFrame, key_prefix=''):
        self.data = data