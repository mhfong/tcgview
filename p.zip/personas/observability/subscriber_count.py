import pyspark.sql.functions as F
from pyspark.sql import DataFrame
import paths
from datetime import datetime
from tagging.persona_tags import PersonaTags


def calc_subscriber_count_by_tag(spark, run_date: datetime, version: str) -> DataFrame:
    """
    Tag count
    """
    path_date = run_date.strftime('%Y-%m-%d')
    subscribers = spark.read.parquet(paths.active_users.format(path_date=path_date, version=version))
    
    tags = spark.read.parquet(
        paths.tags.format(path_date=path_date, version=version)
    )

    all_tags = spark.createDataFrame([[f.name] for f in PersonaTags], schema=['TAG'])
    return _calc_subscriber_count_by_tag(subscribers, tags, all_tags)


def _calc_subscriber_count_by_tag(subscribers, tags, all_tags) -> DataFrame:
    
    counts = tags.join(
        subscribers, on=['SUBR_NUM', 'CUST_NUM'], how='left'
    ).select(
        F.concat('SUBR_NUM', 'CUST_NUM').alias('users'),
        'POST_PAID', 'POST_PAID_NON_CONTRACT', 'HOME_BROADBAND', 
        'PREPAID', 
        F.explode('TAGS').alias('TAG')

    ).groupBy('TAG').agg(
        F.countDistinct(F.col('users')).alias('SUBSCRIBER_COUNT'),

        F.countDistinct(F.when(F.col('POST_PAID'), F.col('users'))).alias('SUBSCRIBER_COUNT_POST_PAID'),
        F.countDistinct(F.when(F.col('POST_PAID_NON_CONTRACT'), F.col('users'))).alias('SUBSCRIBER_COUNT_POST_PAID_NON_CONTRACT'),
        F.countDistinct(F.when(F.col('HOME_BROADBAND'), F.col('users'))).alias('SUBSCRIBER_COUNT_HOME_BROADBAND'),
        F.countDistinct(F.when(F.col('PREPAID'), F.col('users'))).alias('SUBSCRIBER_COUNT_PREPAID'),
    )

    return all_tags.join(counts, how='left', on='TAG').fillna(0)


def calc_2_tag_overlap(spark, run_date: datetime, version: str) -> DataFrame:
    """
    Tag A and B overlap %
    num tags * num tags - num tags rows
    """
    path_date = run_date.strftime('%Y-%m-%d')
    df = spark.read.parquet(
        paths.tags.format(path_date=path_date, version=version)
    ).filter(
        F.size('TAGS') > 0
    )
    tag_cols = [f for f in PersonaTags]
    return _calc_2_tag_overlap(df, tag_cols)


def _calc_2_tag_overlap(df, tag_cols: list) -> DataFrame:

    pairs = []
    for i in range(len(tag_cols)):
        for j in range(i + 1, len(tag_cols)):
            pairs.append((tag_cols[i], tag_cols[j]))

    bools = tag_cols + [p1 + ',' + p2 for p1, p2 in pairs]

    counts = df.select(
        *([
              F.when(F.col(p1) & F.col(p2), True).otherwise(False).alias(p1 + ',' + p2)
              for p1, p2 in pairs
          ] + [
              F.col(t) for t in tag_cols
          ])
    ).agg(
        *[F.sum(F.when(F.col(b), 1).otherwise(0)).alias(b) for b in bools]
    )

    overlaps = counts.limit(1).select(
        F.array([
            F.struct([
                F.col(p1 + ',' + p2).alias('overlap'),
                F.when(F.col(p1) != 0, F.col(p1 + ',' + p2) / F.col(p1)).otherwise(float(0)).alias('tag1_overlap_percentage'),
                F.when(F.col(p2) != 0, F.col(p1 + ',' + p2) / F.col(p2)).otherwise(float(0)).alias('tag2_overlap_percentage'),
                F.lit(p1).alias('tag1'),
                F.lit(p2).alias('tag2'),
            ])
            for p1, p2 in pairs
        ]).alias('pairs')
    ).select(F.explode('pairs').alias('pairs')).repartition(3).cache()

    way1 = overlaps.select(  # upper triangular
        F.col('pairs.tag1').alias('TAG1'),
        F.col('pairs.tag2').alias('TAG2'),

        F.col('pairs.tag1_overlap_percentage').alias('TAG1_OVERLAP_PERCENTAGE'),
        F.col('pairs.tag2_overlap_percentage').alias('TAG2_OVERLAP_PERCENTAGE'),

        F.col('pairs.overlap').alias('OVERLAP'),
    )

    way2 = way1.select(  # add lower triangular to show on dashboard easier
        F.col('TAG2').alias('TAG1'),
        F.col('TAG1').alias('TAG2'),
        F.col('TAG2_OVERLAP_PERCENTAGE').alias('TAG1_OVERLAP_PERCENTAGE'),
        F.col('OVERLAP')
    )

    return way1.select('TAG1', 'TAG2', 'TAG1_OVERLAP_PERCENTAGE', 'OVERLAP').union(
        way2
    )