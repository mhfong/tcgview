from main_persona_tags_warnings import (compute_true_counts,
                                        compute_avg_for_each_key, get_abnormal_dict_values_diff,
                                        get_path_with_closest_version_by_tag_paths)
from pyspark.sql.types import StructType, StructField, StringType, BooleanType
from pyspark.sql import SparkSession


def test_compute_true_counts(spark: SparkSession):
    # Define the schema
    schema = StructType([
        StructField("SUBR_NUM", StringType(), True),
        StructField("CUST_NUM", StringType(), True),
        StructField("TAG1", BooleanType(), True),
        StructField("TAG2", BooleanType(), True)
    ])

    # Create sample data
    data = [
        {"SUBR_NUM": "1", "CUST_NUM": "1", "TAG1": True, "TAG2": False},
        {"SUBR_NUM": "2", "CUST_NUM": "1", "TAG1": False, "TAG2": False},
        {"SUBR_NUM": "3", "CUST_NUM": "2", "TAG1": True, "TAG2": False},
        {"SUBR_NUM": "4", "CUST_NUM": "2", "TAG1": False, "TAG2": False}
    ]

    df = spark.createDataFrame(data, schema)
    
    true_counts = compute_true_counts(df)
    assert true_counts["TAG1"] == 2
    assert true_counts["TAG2"] == 0


def test_compute_avg_for_each_key():
    
    list_of_true_counts = []
    
    true_counts_1 = {}
    true_counts_1["TAG1"] = 1.0
    true_counts_1["TAG2"] = 1.0
    
    true_counts_2 = {}
    true_counts_2["TAG1"] = 2.0
    true_counts_2["TAG2"] = 2.0
    
    true_counts_3 = {}
    true_counts_3["TAG1"] = 3.0
    true_counts_3["TAG3"] = 3.0
    
    list_of_true_counts.append(true_counts_1)
    list_of_true_counts.append(true_counts_2)
    list_of_true_counts.append(true_counts_3)
    
    avg_counts = compute_avg_for_each_key(list_of_true_counts)
    
    assert avg_counts["TAG1"] == 2.0
    assert avg_counts["TAG2"] == 1.5
    assert avg_counts["TAG3"] == 3.0
    


def test_check_dict_values_diff():
    dict1 = {}
    dict1["TAG1"] = 1
    dict1["TAG2"] = 2
    dict1["TAG3"] = 3
    
    dict2 = {}
    dict2["TAG1"] = 1
    dict2["TAG2"] = 21
    dict2["TAG4"] = 3

    diff_tags = get_abnormal_dict_values_diff(dict1, dict2, 0.1)
    assert len(diff_tags) == 1
    assert "TAG2" in diff_tags[0]

def test_get_path_with_closest_version_by_tag_paths():

    version_1 = "v1.1.0"
    files_1 = ["dtap://TenantStorage/version=v1.0.39", "dtap://TenantStorage/version=v1.0.38"]

    version_2 = "v1.1.0"
    files_2 = ["dtap://TenantStorage/version=v1.1.0", "dtap://TenantStorage/version=v1.0.38"]

    version_3 = "v1.1.0"
    files_3 = ["dtap://TenantStorage/version=v1.1.1", "dtap://TenantStorage/version=v1.1.2"]

    assert get_path_with_closest_version_by_tag_paths(version_1, files_1) == "dtap://TenantStorage/version=v1.0.39"
    assert get_path_with_closest_version_by_tag_paths(version_2, files_2) == "dtap://TenantStorage/version=v1.1.0"
    assert get_path_with_closest_version_by_tag_paths(version_3, files_3) is None