
from pyspark.sql import SparkSession
from observability.subscriber_count import _calc_2_tag_overlap, _calc_subscriber_count_by_tag


def test_personas_tags(spark: SparkSession):
    r = spark.createDataFrame(
        [
            [True, False, True, ['A', 'C']],
            [True, False, True, ['A', 'C']],
            [True, False, True, ['A', 'C']],
            [True, True, True, ['A', 'B', 'C']],
            [True, True, False, ['A', 'B']],

            [False, False, False, []],
        ],
        schema=[
            'A', 'B', 'C', 'TAGS'
        ]
    )

    df = _calc_2_tag_overlap(r, ['A', 'B', 'C']).sort('TAG1', 'TAG2')
    
    rows = df.collect()
    assert rows[0]['TAG1'] == 'A'
    assert rows[0]['TAG2'] == 'B'
    assert rows[0]['TAG1_OVERLAP_PERCENTAGE'] == 2/5
    assert rows[0]['OVERLAP'] == 2

    assert rows[1]['TAG1'] == 'A'
    assert rows[1]['TAG2'] == 'C'
    assert rows[1]['TAG1_OVERLAP_PERCENTAGE'] == 4/5
    assert rows[1]['OVERLAP'] == 4

    assert rows[2]['TAG1'] == 'B'
    assert rows[2]['TAG2'] == 'A'
    assert rows[2]['TAG1_OVERLAP_PERCENTAGE'] == 2 / 2
    assert rows[2]['OVERLAP'] == 2

    assert rows[3]['TAG1'] == 'B'
    assert rows[3]['TAG2'] == 'C'
    assert rows[3]['TAG1_OVERLAP_PERCENTAGE'] == 1 / 2
    assert rows[3]['OVERLAP'] == 1

    assert rows[4]['TAG1'] == 'C'
    assert rows[4]['TAG2'] == 'A'
    assert rows[4]['TAG1_OVERLAP_PERCENTAGE'] == 4 / 4
    assert rows[4]['OVERLAP'] == 4

    assert rows[5]['TAG1'] == 'C'
    assert rows[5]['TAG2'] == 'B'
    assert rows[5]['TAG1_OVERLAP_PERCENTAGE'] == 1 / 4
    assert rows[5]['OVERLAP'] == 1


def test_personas_tags_count(spark: SparkSession):
    tags = spark.createDataFrame(
        [
            ['1', '6', True, False, True, ['A', 'C']],
            ['1', '5', True, False, True, ['A', 'C']],
            ['1', '4', True, False, True, ['A', 'C']],
            ['1', '3', True, True, True, ['A', 'B', 'C']],
            ['1', '2', True, True, False, ['A', 'B']],

            ['1', '1', False, False, False, []],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'A', 'B', 'C', 'TAGS'
        ]
    )
    users = spark.createDataFrame(
        [
            ['1', '6', False, True, False, False],
            ['1', '5', False, True, False, False],
            ['1', '4', True, False, False, False],
            ['1', '3', False, False, True, False,],
            ['1', '2', False, False, False, True],

            ['1', '1', False, False, True, False],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'POST_PAID', 'POST_PAID_NON_CONTRACT', 'HOME_BROADBAND', 
            'PREPAID', 
        ]
    )
    all_tags = spark.createDataFrame([['A'], ['B'], ['C'], ['D']], schema=['TAG'])

    df = _calc_subscriber_count_by_tag(users, tags, all_tags).sort('TAG')

    rows = df.collect()

    row = rows[0]
    assert row['TAG'] == 'A'
    assert row['SUBSCRIBER_COUNT'] == 5
    assert row['SUBSCRIBER_COUNT_POST_PAID'] == 1
    assert row['SUBSCRIBER_COUNT_POST_PAID_NON_CONTRACT'] == 2
    assert row['SUBSCRIBER_COUNT_HOME_BROADBAND'] == 1
    assert row['SUBSCRIBER_COUNT_PREPAID'] == 1

    row = rows[1]
    assert row['TAG'] == 'B'
    assert row['SUBSCRIBER_COUNT'] == 2
    assert row['SUBSCRIBER_COUNT_POST_PAID'] == 0
    assert row['SUBSCRIBER_COUNT_POST_PAID_NON_CONTRACT'] == 0
    assert row['SUBSCRIBER_COUNT_HOME_BROADBAND'] == 1
    assert row['SUBSCRIBER_COUNT_PREPAID'] == 1

    row = rows[2]
    assert row['TAG'] == 'C'
    assert row['SUBSCRIBER_COUNT'] == 4
    assert row['SUBSCRIBER_COUNT_POST_PAID'] == 1
    assert row['SUBSCRIBER_COUNT_POST_PAID_NON_CONTRACT'] == 2
    assert row['SUBSCRIBER_COUNT_HOME_BROADBAND'] == 1
    assert row['SUBSCRIBER_COUNT_PREPAID'] == 0

    row = rows[3]
    assert row['TAG'] == 'D'
    assert row['SUBSCRIBER_COUNT'] == 0
    assert row['SUBSCRIBER_COUNT_POST_PAID'] == 0
    assert row['SUBSCRIBER_COUNT_POST_PAID_NON_CONTRACT'] == 0
    assert row['SUBSCRIBER_COUNT_HOME_BROADBAND'] == 0
    assert row['SUBSCRIBER_COUNT_PREPAID'] == 0