from main_calculate_persona_tags import make_personas_df
from tagging.persona_tags import PersonaTags, conditions
from ratings.feature_ratings import BooleanFeatureRatings, FloatFeatureRatings
import pyspark.sql.functions as F
from pyspark.sql import SparkSession


def test_personas_tags(spark: SparkSession):
    subs = spark.createDataFrame(
        [
            ['1', '1', '1', '1'],
            ['2', '2', '2', '2'],
            ['4', '4', None, '4'],
            ['1', None, '1', '1'],
            ['1', '', '1', '1'],
        ],
        schema=['SUBR_NUM', 'CUST_NUM', 'CUST_ID', 'ACCT_NUM']
    )
    ratings = spark.createDataFrame(
        [
            ['1', '1', 1.0],
            ['2', '2', 0.0],
            ['3', '3', 1.1],
            ['4', '4', 1.0]
        ], schema=['SUBR_NUM', 'CUST_NUM', BooleanFeatureRatings.ROAMING_TRIP_COUNT_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1.name]
    )
    c = {
        PersonaTags.FREQUENT_TRAVELER_APAC: F.col(BooleanFeatureRatings.ROAMING_TRIP_COUNT_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1.name) > F.lit(0.5),
        PersonaTags.FREQUENT_TRAVELER_OTHER: F.col(BooleanFeatureRatings.ROAMING_TRIP_COUNT_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1.name) > F.lit(0.1),
    }

    df = make_personas_df(ratings, subs, c)

    rows = df.orderBy('SUBR_NUM', 'CUST_NUM').collect()
    assert len(rows) == 3
    row = rows[0]
    assert row['SUBR_NUM'] == '1'
    assert row['CUST_NUM'] == '1'
    assert row['CUST_ID'] == '1'
    assert row['ACCT_NUM'] == '1'
    assert row['TAGS'] == ['FREQUENT_TRAVELER_APAC', 'FREQUENT_TRAVELER_OTHER']

    row = rows[1]
    assert row['SUBR_NUM'] == '2'
    assert row['CUST_NUM'] == '2'
    assert row['CUST_ID'] == '2'
    assert row['ACCT_NUM'] == '2'
    assert row['TAGS'] == []
    
    row = rows[2]
    assert row['SUBR_NUM'] == '4'
    assert row['CUST_NUM'] == '4'
    assert row['CUST_ID'] == None
    assert row['ACCT_NUM'] == '4'
    assert row['TAGS'] == ['FREQUENT_TRAVELER_APAC', 'FREQUENT_TRAVELER_OTHER']


def test_personas_tags_conditions_syntax(spark: SparkSession):
    # test run with the real tags conditions
    subs = spark.createDataFrame(
        [
            ['1', '1', '1', '1'],
            ['2', '2', '2', '2'],
            ['4', '4', None, '4'],
            ['1', None, '1', '1'],
            ['1', '', '1', '1'],
        ],
        schema=['SUBR_NUM', 'CUST_NUM', 'CUST_ID', 'ACCT_NUM']
    )
    b = [True for _ in BooleanFeatureRatings]
    f = [1.0 for _ in FloatFeatureRatings]
    cols = [fcol for fcol in FloatFeatureRatings] + [bcol for bcol in BooleanFeatureRatings]
    ratings = spark.createDataFrame(
        [
            ['1', '1'] + f + b,
            ['2', '2'] + f + b,
            ['3', '3'] + f + b,
            ['4', '4'] + f + b
        ], schema=['SUBR_NUM', 'CUST_NUM'] + cols
    )

    assert make_personas_df(ratings, subs, conditions()).count() == 3
