import pytest
from pyspark.sql import SparkSession
from observability.side_output import EchoSideOutput


# Get one spark session for the whole test session
@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master('local[2]').getOrCreate()


@pytest.fixture
def side_output():
    return EchoSideOutput()