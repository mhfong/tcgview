from main_calculate_ratings import join_ratings
from ratings.feature_ratings import FloatFeatureRatings
from pyspark.sql import SparkSession


def test_personas_tags(spark: SparkSession):
    a = spark.createDataFrame([
            ['1', '1', 1],
            ['2', '2', 1],
            ['4', '4', 1],
        ],
        schema=['SUBR_NUM', 'CUST_NUM', FloatFeatureRatings.AGE]
    )
    b = spark.createDataFrame([
            ['1', '1', 1.0],
            ['2', '2', 1.0],
            ['3', '3', 1.0],
        ],
        schema=['SUBR_NUM', 'CUST_NUM', FloatFeatureRatings.ROUND_TRIP_MID_POINT_ENTROPY]
    )

    df = join_ratings([a, b], {FloatFeatureRatings.AGE: 0}).sort('SUBR_NUM', 'CUST_NUM').collect()
    assert len(df) == 4
    row = df[0]
    assert row['SUBR_NUM'] == '1'
    assert row['CUST_NUM'] == '1'
    assert row['AGE'] == 1
    assert row['ROUND_TRIP_MID_POINT_ENTROPY'] == 1.0

    row = df[1]
    assert row['SUBR_NUM'] == '2'
    assert row['CUST_NUM'] == '2'
    assert row['AGE'] == 1
    assert row['ROUND_TRIP_MID_POINT_ENTROPY'] == 1.0

    row = df[2]
    assert row['SUBR_NUM'] == '3'
    assert row['CUST_NUM'] == '3'
    assert row['AGE'] == 0
    assert row['ROUND_TRIP_MID_POINT_ENTROPY'] == 1.0

    row = df[3]
    assert row['SUBR_NUM'] == '4'
    assert row['CUST_NUM'] == '4'
    assert row['AGE'] == 1
    assert row['ROUND_TRIP_MID_POINT_ENTROPY'] is None