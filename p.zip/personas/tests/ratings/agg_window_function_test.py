from ratings.agg_window_functions import _multi_partition_percent_rank, _rolling_sum_total_ratio
import pyspark.sql.functions as F
from pyspark.sql.window import Window


def test_rolling_sum(spark):

    df = spark.createDataFrame([
        ['a', 'a', 0, 5],
        ['a', 'b', 1, 5],
        ['a', 'c', 1, 5],
        ['a', 'd', 1, 5],
        ['a', 'e', 1, 5],
        ['a', 'f', 1, 5],
    ], schema=['SUBR_NUM', 'CUST_NUM', 'A', 'B'])

    r = _rolling_sum_total_ratio(
        df, rolling_sum_col='A', total_col='B', result_col_name='C'
    ).sort('SUBR_NUM', 'CUST_NUM').select('C').collect()
    r = [row['C'] for row in r]

    assert r == [0, 1/5, 2/5, 3/5, 4/5, 1]

    df = spark.createDataFrame([
        ['a', 'a', 0, 1555],
        ['a', 'b', 6, 1555],
        ['a', 'c', 36, 1555],
        ['a', 'd', 1, 1555],
        ['a', 'e', 216, 1555],
        ['a', 'f', 1296, 1555],
    ], schema=['SUBR_NUM', 'CUST_NUM', 'A', 'B'])

    r = _rolling_sum_total_ratio(
        df, rolling_sum_col='A', total_col='B', result_col_name='C'
    ).sort('SUBR_NUM', 'CUST_NUM').select('C').collect()
    r = [row['C'] for row in r]

    assert r == [0, 7/1555, 43/1555, 1/1555, 259/1555, 1]


def test_percent_rank(spark):

    df = spark.createDataFrame([
        ['a', 'a', 1],
        ['a', 'b', 1],
        ['a', 'c', 1],
        ['a', 'd', 1],
        ['a', 'e', 1],
        ['a', 'f', 1],
    ], schema=['SUBR_NUM', 'CUST_NUM', 'A'])

    r = _multi_partition_percent_rank(
        df, 'A'
    ).sort('SUBR_NUM', 'CUST_NUM').select('percent_rank').collect()
    r = [row['percent_rank'] for row in r]

    expected = df.withColumn(
        'percent_rank', F.percent_rank().over(Window.orderBy('A'))
    ).sort('SUBR_NUM', 'CUST_NUM').select('percent_rank').collect()
    expected = [row['percent_rank'] for row in expected]
    assert r == expected

    df = spark.createDataFrame([
        ['a', 'a', 0],
        ['a', 'b', 6],
        ['a', 'c', 36],
        ['a', 'd', 1],
        ['a', 'e', 216],
        ['a', 'f', 1296],
    ], schema=['SUBR_NUM', 'CUST_NUM', 'A'])

    r = _multi_partition_percent_rank(
        df, rank_col='A'
    ).sort('SUBR_NUM', 'CUST_NUM').select('percent_rank').collect()
    r = [row['percent_rank'] for row in r]

    expected = df.withColumn(
        'percent_rank', F.percent_rank().over(Window.orderBy('A'))
    ).sort('SUBR_NUM', 'CUST_NUM').select('percent_rank').collect()
    expected = [row['percent_rank'] for row in expected]
    assert r == expected

    assert _multi_partition_percent_rank(
        df.limit(0), rank_col='A'
    ).count() == 0