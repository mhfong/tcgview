
from pyspark.sql import SparkSession
from ratings.calllog_ratings import _moving_company_caller


def test_moving_company_caller(spark: SparkSession):
    r = spark.createDataFrame(
        [
            ['0', '1', 12345678, 20],
            ['0', '1', 23371234, 20],
            ['1', '1', 23371234, 30],
            ['2', '1', 11114444, 30],
            ['3', '1', 29581233, 20]
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'A_NUM',
            'CALL_REC_TYPE_CD'
        ]
    )

    df = _moving_company_caller(r).sort('CUST_NUM', 'SUBR_NUM').collect()

    assert len(df) == 2
    assert df[0]['CUST_NUM'] == '1'
    assert df[0]['SUBR_NUM'] == '0'
    assert df[0]['CALLLOG_MOVING_COMPANY_CALLER'] == True

    assert df[1]['CUST_NUM'] == '1'
    assert df[1]['SUBR_NUM'] == '3'
    assert df[1]['CALLLOG_MOVING_COMPANY_CALLER'] == True