from ratings.geolocation_cell_site_ratings import (
    _uni_geo_footprint_feature, _many_districts_visited_day_count_feature, _max_day_count_in_the_same_district_feature,
    _max_round_trip_day_count_feature, _mid_point_district_distribution_entropy_feature,
    _get_mtr_day_count_by_duration, _get_golden_mtr_stations_visited_day_count
)
from pyspark.sql import SparkSession
from datetime import date

def test_uni_geo_footprint_feature(spark: SparkSession):
    geo_uni_record = spark.createDataFrame(
        [
            ['0','1',"cuhk"],
            ['0','2',"cuhk"],
            ['0','3',"cityu"],
            ['0','4',"cityu"],
            ['0','2',"ust"],
            ['0','4',"buhk"],
        ],
        schema=[
            'cust_num', 'subr_num',
            'uni'
        ]
    )
    df = _uni_geo_footprint_feature(geo_uni_df=geo_uni_record).sort('CUST_NUM', 'SUBR_NUM').collect()

    assert len(df) == 4
    assert df[0]['CUST_NUM'] == '0'
    assert df[0]['SUBR_NUM'] == '1'
    assert df[0]['UNI_GEOLOCATION_AT_LEAST_3_DAYS_30D_ANY_6M'] == True

    assert df[1]['CUST_NUM'] == '0'
    assert df[1]['SUBR_NUM'] == '2'
    assert df[1]['UNI_GEOLOCATION_AT_LEAST_3_DAYS_30D_ANY_6M'] == True

    assert df[2]['CUST_NUM'] == '0'
    assert df[2]['SUBR_NUM'] == '3'
    assert df[2]['UNI_GEOLOCATION_AT_LEAST_3_DAYS_30D_ANY_6M'] == True

    assert df[3]['CUST_NUM'] == '0'
    assert df[3]['SUBR_NUM'] == '4'
    assert df[3]['UNI_GEOLOCATION_AT_LEAST_3_DAYS_30D_ANY_6M'] == True


def test_many_districts_visited_day_count_feature(spark: SparkSession):
    data = spark.createDataFrame(
        [
            ["20240101", "0001", "0001", 4],
            ["20240103", "0001", "0001", 3],
            ["20240105", "0001", "0001", 7],
            ["20240130", "0001", "0001", 9],
            ["20240101", "0002", "0002", 1],
            ["20240102", "0002", "0002", 1],
            ["20240111", "0002", "0002", 2],
            ["20240129", "0002", "0002", 19],
            ["20240101", "0003", "0003", 4],
            ["20240102", "0003", "0003", 5],
            ["20240111", "0003", "0003", 6],
            ["20240129", "0003", "0003", 7],
         ],

        schema=[
            'date_id','cust_num', 'subr_num', 'count_district'
        ]
    )
    df = _many_districts_visited_day_count_feature(stat_district_count=data,
                                                   district_count_threshold=4)\
                                                .sort('CUST_NUM', 'SUBR_NUM')
    df_rows = [list(row) for row in df.collect()]
    assert df.columns == ['CUST_NUM', 'SUBR_NUM', "DAY_COUNT_WHEN_TRAVEL_4_PLUS_DISTRICTS"]
    assert df_rows == [
        ["0001", "0001", 3],
        ["0002", "0002", 1],
        ["0003", "0003", 4],
    ]


def test_mid_point_district_distribution_entropy_feature(spark: SparkSession):
    data = spark.createDataFrame(
        [
        # very low entropy
        [20240218, '00000000', '00000003', 'Tuen Mun District'],
        [20240219, '00000000', '00000003', 'Tuen Mun District'],
        [20240220, '00000000', '00000003', 'Tuen Mun District'],
        [20240221, '00000000', '00000003', 'Tuen Mun District'],
        [20240222, '00000000', '00000003', 'Tuen Mun District'],
        [20240223, '00000000', '00000003', 'Kwun Tong District'],

         # higher than 00000004
        [20240218, '00000001', '00000004', 'Yuen Long District'],
        [20240219, '00000001', '00000004', 'Tuen Mun District'],
        [20240220, '00000001', '00000004', 'Sai Kung District'],
        [20240221, '00000001', '00000004', 'Tuen Mun District'],
        [20240222, '00000001', '00000004', 'Tuen Mun District'],
        [20240223, '00000001', '00000004', 'Kwun Tong District'],

        # high entropy
        [20240217, '00000002', '00000005', 'Yuen Long District'],
        [20240218, '00000002', '00000005', 'Central and Western District'],
        [20240219, '00000002', '00000005', 'Tuen Mun District'],
        [20240220, '00000002', '00000005', 'Sai Kung District'],
        [20240221, '00000002', '00000005', 'Southern District'],
        [20240222, '00000002', '00000005', 'Yau Tsim Mong District'],
        [20240223, '00000002', '00000005', 'Kwun Tong District'],
        [20240224, '00000002', '00000005', 'Tuen Mun District'],
        [20240225, '00000002', '00000005', 'Wan Chai District'],
        [20240226, '00000002', '00000005', 'Kwun Tong District'],
        [20240227, '00000002', '00000005', 'Kwun Tong District'],
        [20240228, '00000002', '00000005', 'Tuen Mun District'],
        [20240229, '00000002', '00000005', 'Kowloon City District'],
         ],

        schema=[
            'date_id','cust_num', 'subr_num', 'mid_point_district'
        ]
    )
    df = _mid_point_district_distribution_entropy_feature(round_trip_record=data)\
                                                .sort('CUST_NUM', 'SUBR_NUM')
    df_rows = [list(row) for row in df.collect()]
    assert df.columns == ['CUST_NUM', 'SUBR_NUM', "ROUND_TRIP_MID_POINT_ENTROPY"]
    assert df_rows == [
        ["00000000", "00000003", 0.65002],
        ["00000001", "00000004", 1.79248],
        ["00000002", "00000005", 2.96892],
    ]


def test_max_round_trip_day_count_feature(spark: SparkSession):
    data = spark.createDataFrame(
        [
            [20240218, '00000000', '00000003', 'Tuen Mun District', 'Yuen Long District', 4],
            [20240219, '00000000', '00000003', 'Tuen Mun District', 'Yuen Long District', 4],
            [20240220, '00000000', '00000003', 'Tuen Mun District', 'Yuen Long District', 4],
            [20240221, '00000000', '00000003', 'Tuen Mun District', 'Yuen Long District', 4],
            [20240222, '00000000', '00000003', 'Tuen Mun District', 'Yuen Long District', 5], # does not count as max_group > 4
            [20240223, '00000000', '00000003', 'Kwun Tong District', 'Yuen Long District', 4],

            [20240218, '00000001', '00000004', 'Yuen Long District', 'Tuen Mun District', 6], # does not count as max_group > 4
            [20240219, '00000001', '00000004', 'Tuen Mun District', 'Sai Kung District', 4],
            [20240220, '00000001', '00000004', 'Sai Kung District', 'Tuen Mun District', 4],
            [20240221, '00000001', '00000004', 'Tuen Mun District', 'Sai Kung District', 4],
            [20240222, '00000001', '00000004', 'Tuen Mun District', 'Sai Kung District', 4],
            [20240223, '00000001', '00000004', 'Kwun Tong District', 'Tuen Mun District', 4],
        ],

        schema=[
            'date_id','cust_num', 'subr_num', 'mid_point_district', 'end_point_district', 'max_grouping'
        ]
    )
    df = _max_round_trip_day_count_feature(round_trip_record=data).sort('CUST_NUM', 'SUBR_NUM')

    df_rows = [list(row) for row in df.collect()]
    assert df.columns == ['CUST_NUM', 'SUBR_NUM', "MAX_DAY_COUNT_BY_TRIP_WHEN_ROUND_TRIP"]
    assert df_rows == [
        ["00000000", "00000003", 4],
        ["00000001", "00000004", 3],
    ]


def test_max_day_count_in_the_same_district_feature(spark: SparkSession):
    data = spark.createDataFrame(
        [
            [20240218, '00000000', '00000003', 'Tuen Mun District'], # 1
            [20240219, '00000000', '00000003', 'Tuen Mun District'], # 2
            [20240220, '00000000', '00000003', 'Tuen Mun District'], # 3
            [20240221, '00000000', '00000003', 'Tuen Mun District'], # 4
            [20240222, '00000000', '00000003', 'Tuen Mun District'], # 5
            [20240223, '00000000', '00000003', 'Kwun Tong District'],

            [20240218, '00000001', '00000004', 'Yuen Long District'],
            [20240219, '00000001', '00000004', 'Tuen Mun District'], # 1
            [20240220, '00000001', '00000004', 'Sai Kung District'],
            [20240221, '00000001', '00000004', 'Tuen Mun District'], # 2
            [20240222, '00000001', '00000004', 'Tuen Mun District'], # 3
            [20240223, '00000001', '00000004', 'Kwun Tong District'],

            [20240217, '00000002', '00000005', 'Yuen Long District'],
            [20240218, '00000002', '00000005', 'Central and Western District'],
            [20240219, '00000002', '00000005', 'Tuen Mun District'],
            [20240220, '00000002', '00000005', 'Sai Kung District'], # 1
            [20240221, '00000002', '00000005', 'Sai Kung District'], # 2
            [20240222, '00000002', '00000005', 'Sai Kung District'], # 3
            [20240223, '00000002', '00000005', 'Sai Kung District'], # 4
            [20240224, '00000002', '00000005', 'Sai Kung District'], # 5
            [20240225, '00000002', '00000005', 'Sai Kung District'], # 6
            [20240226, '00000002', '00000005', 'Sai Kung District'], # 7
            [20240227, '00000002', '00000005', 'Sai Kung District'], # 8
            [20240228, '00000002', '00000005', 'Sai Kung District'], # 9
            [20240229, '00000002', '00000005', 'Sai Kung District'], # 10

    ],

        schema=[
            'date_id','cust_num', 'subr_num', 'district'
        ]
    )
    df = _max_day_count_in_the_same_district_feature(district_days_count_count=data).sort('CUST_NUM', 'SUBR_NUM')

    df_rows = [list(row) for row in df.collect()]
    assert df.columns == ['CUST_NUM', 'SUBR_NUM', "MAX_DAY_COUNT_BY_DISTRICT_WHEN_STAY_IN_SAME_DISTRICT"]
    assert df_rows == [
        ["00000000", "00000003", 5],
        ["00000001", "00000004", 3],
        ["00000002", "00000005", 10],
    ]

def test_get_mtr_day_count_abv_duration(spark: SparkSession):
    data = spark.createDataFrame(
        [
            [20240218, '00000000', '00000003', 300], 
            [20240219, '00000000', '00000003', 600], 
            [20240220, '00000000', '00000003', 900], 
            [20240221, '00000000', '00000003', 1000], 
            [20240222, '00000000', '00000003', 18000],
            [20240223, '00000000', '00000003', 2000], 

            [20240218, '00000001', '00000004', 19000], 
            [20240219, '00000001', '00000004', 10000], 
            [20240220, '00000001', '00000004', 18000], 
            [20240221, '00000001', '00000004', 1000], 
            [20240222, '00000001', '00000004', 1800], 
            [20240223, '00000001', '00000004', 1700],

            [20240217, '00000002', '00000005', 1100],
            [20240218, '00000002', '00000005', 1700],
            [20240219, '00000002', '00000005', 1900],
            [20240220, '00000002', '00000005', 1100], 
            [20240221, '00000002', '00000005', 11000], 
            [20240222, '00000002', '00000005', 1300], 
            [20240223, '00000002', '00000005', 2000], 
            [20240224, '00000002', '00000005', 2000], 
            [20240225, '00000002', '00000005', 2100], 
            [20240226, '00000002', '00000005', 3600],
            [20240227, '00000002', '00000005', 4700],
            [20240228, '00000002', '00000005', 1500], 
            [20240229, '00000002', '00000005', 1799], 

    ],

        schema=[
            'date_id','CUST_NUM', 'SUBR_NUM', 'total_journey_duration'
        ]
    )
    df = _get_mtr_day_count_by_duration(mtr_records=data)\
            .sort('CUST_NUM', 'SUBR_NUM')

    df_rows = [list(row) for row in df.collect()]
    assert df.columns == ['CUST_NUM', 'SUBR_NUM', 'DAY_COUNT_MTR_NORMAL_USAGE_30D', 'DAY_COUNT_MTR_HEAVY_USAGE_30D']
    assert df_rows == [
            ['00000000', '00000003', 2, 1], 
            ['00000001', '00000004', 4, 3], 
            ['00000002', '00000005', 7, 3]
        ]


def test_get_golden_mtr_stations_visited_day_count(spark: SparkSession):
    data = spark.createDataFrame(
        [
            ['454060000000000', 2, 'Tsuen Wan', 'Tsuen Wan', '2024-06-01 09:56:31', '2024-06-01 11:44:33', 159, 131, 6482, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Mei Foo', 'Lai Chi Kok', 'Cheung Sha Wan', 'Sham Shui Po', 'Prince Edward', 'Mong Kok', 'Prince Edward', 'Mong Kok', 
              'Yau Ma Tei', 'Jordan', 'Yau Ma Tei', 'Jordan', 'Tsim Sha Tsui', 'Admiralty', 'Central', 'Admiralty', 'Central', 'Sheung Wan', 'Central', 'Sheung Wan', 'Sai Ying Pun', 'HKU', 'Sai Ying Pun', 
              'Sheung Wan', 'Central', 'Hong Kong', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
              '00000000', '50000001', date(2024, 6, 1)],
            ['454060000000000', 4, 'Tsuen Wan', 'Tseung Kwan O', '2024-06-01 15:06:37', '2024-06-01 16:04:01', 140, 487, 3444, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Mei Foo', 'Lai King', 'Mei Foo', 'Lai Chi Kok', 'Cheung Sha Wan', 'Sham Shui Po', 'Prince Edward', 
              'Shek Kip Mei', 'Kowloon Tong', 'Lok Fu', 'Kowloon Tong', 'Lok Fu', 'Wong Tai Sin', 'Diamond Hill', 'Choi Hung', 'Kowloon Bay', 'Ngau Tau Kok', 'Kwun Tong', 
              'Lam Tin', 'Yau Tong', 'Tiu Keng Leng', 'Tseung Kwan O'], 
              '00000000', '50000001', date(2024, 6, 1)],
            ['454060000000000', 8, 'Tseung Kwan O', 'Tsuen Wan', '2024-06-02 00:06:28', '2024-06-02 00:59:01', 182, 192, 3153, 
             ['Tseung Kwan O', 'Tiu Keng Leng', 'Yau Tong', 'Lam Tin', 'Kwun Tong', 'Ngau Tau Kok', 'Kowloon Bay', 'Choi Hung', 'Diamond Hill', 'Wong Tai Sin', 
              'Lok Fu', 'Kowloon Tong', 'Shek Kip Mei', 'Prince Edward', 'Sham Shui Po', 'Cheung Sha Wan', 'Lai Chi Kok', 'Mei Foo', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
              '00000000', '50000001', date(2024, 6, 1)],
            ['454060000000000', 1, 'Tsuen Wan', 'Hong Kong', '2024-06-03 07:35:39', '2024-06-03 08:01:26', 23, 497, 1547, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Nam Cheong', 'Olympic', 'Kowloon', 'Hong Kong'], 
             '00000000', '50000001', date(2024, 6, 3)],
            ['454060000000000', 3, 'Hong Kong', 'Tsuen Wan', '2024-06-03 22:04:03', '2024-06-03 22:29:56', 340, 126, 1553, 
             ['Hong Kong', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
             '00000000', '50000001', date(2024, 6, 3)],
            ['454060000000000', 2, 'Tsuen Wan', 'Hong Kong', '2024-06-04 07:32:56', '2024-06-04 08:00:10', 42, 440, 1634, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Nam Cheong', 'Olympic', 'Kowloon', 'Hong Kong'], 
             '00000000', '50000001', date(2024, 6, 4)],
            ['454060000000000', 1, 'Tsuen Wan', 'Hong Kong', '2024-06-05 07:32:11', '2024-06-05 08:01:17', 206, 511, 1746, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Nam Cheong', 'Olympic', 'Kowloon', 'Hong Kong'], 
             '00000000', '50000001', date(2024, 6, 5)],
            ['454060000000000', 3, 'Hong Kong', 'Tsuen Wan', '2024-06-05 19:56:17', '2024-06-05 20:22:46', 426, 191, 1589, 
             ['Hong Kong', 'Kowloon', 'Olympic', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
             '00000000', '50000001', date(2024, 6, 5)],
            ['454060000000000', 1, 'Tsuen Wan', 'Central', '2024-06-06 07:31:57', '2024-06-06 07:59:23', 128, 390, 1646, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Nam Cheong', 'Olympic', 'Kowloon', 'Hong Kong', 'Central'], 
             '00000000', '50000001', date(2024, 6, 6)],
            ['454060000000000', 3, 'Hong Kong', 'Tsuen Wan', '2024-06-06 20:21:26', '2024-06-06 20:46:33', 296, 125, 1507, 
             ['Hong Kong', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
             '00000000', '50000001', date(2024, 6, 6)],
            ['454060000000000', 1, 'Tsuen Wan', 'Hong Kong', '2024-06-07 07:51:13', '2024-06-07 08:19:50', 154, 465, 1717, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Nam Cheong', 'Olympic', 'Kowloon', 'Hong Kong'], 
             '00000000', '50000001', date(2024, 6, 7)],
            ['454060000000000', 3, 'Hong Kong', 'Tsuen Wan', '2024-06-07 19:25:49', '2024-06-07 19:54:24', 554, 43, 1715, 
             ['Hong Kong', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
             '00000000', '50000001', date(2024, 6, 7)],
            ['454060000000000', 2, 'Tsuen Wan', 'Hong Kong', '2024-06-10 12:51:14', '2024-06-10 13:20:26', 242, 352, 1752, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Nam Cheong', 'Olympic', 'Kowloon', 'Hong Kong'], 
             '00000000', '50000001', date(2024, 6, 10)],
            ['454060000000000', 4, 'Hong Kong', 'Tsuen Wan', '2024-06-10 17:42:46', '2024-06-10 18:17:24', 853, 40, 2078, 
             ['Hong Kong', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
             '00000000', '50000001', date(2024, 6, 10)],
            ['454060000000000', 3, 'Hong Kong', 'Tsuen Wan', '2024-06-27 21:00:46', '2024-06-27 21:30:04', 558, 202, 1758, 
             ['Hong Kong', 'Kowloon', 'Olympic', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
             '00000000', '50000001', date(2024, 6, 27)],
            ['454060000000000', 2, 'Tsuen Wan', 'Hong Kong', '2024-06-28 07:35:18', '2024-06-28 08:04:13', 150, 455, 1735, 
             ['Tsuen Wan', 'Tai Wo Hau', 'Kwai Hing', 'Tai Wo Hau', 'Kwai Hing', 'Kwai Fong', 'Lai King', 'Nam Cheong', 'Olympic', 'Kowloon', 'Hong Kong'], 
             '00000000', '50000001', date(2024, 6, 28)],
            ['454060000000000', 4, 'Hong Kong', 'Tsuen Wan', '2024-06-28 20:35:16', '2024-06-28 21:06:48', 754, 126, 1892, 
             ['Hong Kong', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
             '00000000', '50000001', date(2024, 6, 28)],
            ['454060000000000', 4, 'Fortress Hill', 'Tsuen Wan', '2024-06-30 14:42:50', '2024-06-30 15:29:36', 333, 132, 2806, 
             ['Fortress Hill', 'Tin Hau', 'Causeway Bay', 'Wan Chai', 'Admiralty', 'Central', 'Hong Kong', 'Kowloon', 'Olympic', 'Nam Cheong', 'Lai King', 
              'Kwai Fong', 'Kwai Hing', 'Tai Wo Hau', 'Tsuen Wan'], 
              '00000000', '50000001', date(2024, 6, 30)],
            ['454060000000001', 1, 'Tin Shui Wai', 'Tuen Mun', '2024-06-24 09:04:08', '2024-06-24 09:18:12', 211, 240, 844, 
             ['Tin Shui Wai', 'Siu Hong', 'Tuen Mun'], 
             '00000001', '99999999', date(2024, 6, 24)],
            ['454060000000001', 3, 'Tuen Mun', 'Tin Shui Wai', '2024-06-24 11:29:23', '2024-06-24 11:43:08', 381, 108, 825, 
             ['Tuen Mun', 'Siu Hong', 'Tin Shui Wai'], 
             '00000001', '99999999', date(2024, 6, 24)],
            ['454060000000001', 5, 'Tin Shui Wai', 'Tsuen Wan West', '2024-06-24 12:31:09', '2024-06-24 12:53:10', 413, 183, 1321, 
             ['Tin Shui Wai', 'Long Ping', 'Yuen Long', 'Kam Sheung Road', 'Tsuen Wan West'], 
             '00000001', '99999999', date(2024, 6, 24)],
            ['454060000000001', 11, 'Tsuen Wan West', 'Tin Shui Wai', '2024-06-24 22:31:35', '2024-06-24 22:52:44', 433, 133, 1269, 
             ['Tsuen Wan West', 'Kam Sheung Road', 'Yuen Long', 'Long Ping', 'Tin Shui Wai'], 
             '00000001', '99999999', date(2024, 6, 24)],
            ['454060000000001', 2, 'Tin Shui Wai', 'Tsuen Wan West', '2024-06-25 12:08:17', '2024-06-25 12:26:17', 119, 258, 1080, 
             ['Tin Shui Wai', 'Long Ping', 'Yuen Long', 'Kam Sheung Road', 'Tsuen Wan West'], 
             '00000001', '99999999', date(2024, 6, 25)],
            ['454060000000001', 1, 'Tin Shui Wai', 'Tsuen Wan West', '2024-06-27 07:32:28', '2024-06-27 08:00:05', 166, 677, 1657, 
             ['Tin Shui Wai', 'Long Ping', 'Yuen Long', 'Kam Sheung Road', 'Tsuen Wan West'], 
             '00000001', '99999999', date(2024, 6, 27)],
            ['454060000000001', 9, 'Tsuen Wan West', 'Tin Shui Wai', '2024-06-27 17:31:21', '2024-06-27 17:48:23', 250, 46, 1022, 
             ['Tsuen Wan West', 'Kam Sheung Road', 'Yuen Long', 'Long Ping', 'Tin Shui Wai'], 
             '00000001', '99999999', date(2024, 6, 27)],
            ['454060000000001', 9, 'Tsuen Wan West', 'Exhibition Centre', '2024-06-28 18:14:31', '2024-06-28 18:37:25', 305, 177, 1374, 
             ['Tsuen Wan West', 'Mei Foo', 'Nam Cheong', 'Austin', 'East Tsim Sha Tsui', 'Hung Hom', 'Exhibition Centre'], 
             '00000001', '99999999', date(2024, 6, 28)],
            ['454060000000001', 11, 'Exhibition Centre', 'Tin Shui Wai', '2024-06-28 23:24:38', '2024-06-29 00:14:21', 444, 85, 2983, 
             ['Exhibition Centre', 'Hung Hom', 'East Tsim Sha Tsui', 'Austin', 'Nam Cheong', 'Mei Foo', 'Tsuen Wan West', 'Kam Sheung Road', 'Yuen Long', 'Long Ping', 'Tin Shui Wai'], 
             '00000001', '99999999', date(2024, 6, 28)],
            ['454060000000001', 1, 'Tin Shui Wai', 'Tsuen Wan West', '2024-06-29 07:28:45', '2024-06-29 08:00:49', 243, 941, 1924, 
             ['Tin Shui Wai', 'Long Ping', 'Yuen Long', 'Kam Sheung Road', 'Tsuen Wan West'], 
             '00000001', '99999999', date(2024, 6, 29)],
            ['454060000000001', 15, 'Tsuen Wan West', 'Tin Shui Wai', '2024-06-29 18:32:45', '2024-06-29 18:49:19', 216, 53, 994, 
             ['Tsuen Wan West', 'Kam Sheung Road', 'Yuen Long', 'Long Ping', 'Tin Shui Wai'], 
             '00000001', '99999999', date(2024, 6, 29)],
            ['454060000000001', 1, 'Tin Shui Wai', 'Tsuen Wan West', '2024-06-30 07:36:26', '2024-06-30 07:57:01', 137, 376, 1235, 
             ['Tin Shui Wai', 'Long Ping', 'Yuen Long', 'Kam Sheung Road', 'Tsuen Wan West'], 
             '00000001', '99999999', date(2024, 6, 30)],
            ['454060000000001', 7, 'Tsuen Wan West', 'Tin Shui Wai', '2024-06-30 17:30:19', '2024-06-30 17:49:38', 394, 86, 1159, 
             ['Tsuen Wan West', 'Kam Sheung Road', 'Yuen Long', 'Long Ping', 'Tin Shui Wai'], 
             '00000001', '99999999', date(2024, 6, 30)],
        ],
        schema = [
            'IMSI', 'journey_id', 'start_station', 'end_station', 
            'start_station_start_time', 'end_station_end_time', 
            'start_station_duration', 'end_station_duration', 
            'total_journey_duration', 'stations_list', 
            'CUST_NUM', 'SUBR_NUM', 'date_id'
            ]
    )
    df = _get_golden_mtr_stations_visited_day_count(mtr_records=data)\
            .sort('CUST_NUM', 'SUBR_NUM')

    df_rows = [list(row) for row in df.collect()]
    assert df.columns == ['CUST_NUM', 'SUBR_NUM', 'DAY_COUNT_VISITED_GOLDEN_MTR_FULL_30D', 'DAY_COUNT_VISITED_GOLDEN_MTR_2024_30D', 'DAY_COUNT_VISITED_GOLDEN_MTR_2025_30D']
    assert df_rows == [
        ['00000000', '50000001', 8, 10, 8],
        ['00000001', '99999999', 0, 0, 0]
        ]