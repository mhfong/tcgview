
from pyspark.sql import SparkSession
from ratings.weblog_ratings import _airlines_booking_data_usage_ratings, _uni_domains_visit_days_cnt_percentile_feature, \
    _family_related_ratings, _northbound_driver_ratings, _driver_ratings


def test_airlines_booking_data_usage_ratings(spark: SparkSession):
    r = spark.createDataFrame(
        [
            ['0', '1', 0, 123],
            ['1', '1', 1, 0],
            ['2', '1', 0, 11389],
            ['3', '1', 2, 1000001],
            ['4', '1', 0, 3000001],
            ['5', '1', 2, 5000001],
            ['6', '1', 0, 9000001],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D',
            'AIRLINES_BOOKING_DATA_USAGE_SUM_PAST_180D',
        ]
    )

    df = _airlines_booking_data_usage_ratings(r).sort('CUST_NUM', 'SUBR_NUM').collect()

    assert len(df) == 7
    # all false
    assert df[0]['CUST_NUM'] == '1'
    assert df[0]['SUBR_NUM'] == '0'
    assert df[0]['TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1'] == False
    assert df[0]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1'] == False
    assert df[0]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2'] == False
    assert df[0]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3'] == False
    assert df[0]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4'] == False
    assert df[0]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5'] == False

    # china true overseas all false
    assert df[1]['CUST_NUM'] == '1'
    assert df[1]['SUBR_NUM'] == '1'
    assert df[1]['TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1'] == True
    assert df[1]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1'] == False
    assert df[1]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2'] == False
    assert df[1]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3'] == False
    assert df[1]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4'] == False
    assert df[1]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5'] == False

    # china false overseas 1 true
    assert df[2]['CUST_NUM'] == '1'
    assert df[2]['SUBR_NUM'] == '2'
    assert df[2]['TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1'] == False
    assert df[2]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1'] == True
    assert df[2]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2'] == False
    assert df[2]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3'] == False
    assert df[2]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4'] == False
    assert df[2]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5'] == False

    # china true overseas 2 true
    assert df[3]['CUST_NUM'] == '1'
    assert df[3]['SUBR_NUM'] == '3'
    assert df[3]['TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1'] == True
    assert df[3]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1'] == False
    assert df[3]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2'] == True
    assert df[3]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3'] == False
    assert df[3]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4'] == False
    assert df[3]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5'] == False

    # china false overseas 3 true
    assert df[4]['CUST_NUM'] == '1'
    assert df[4]['SUBR_NUM'] == '4'
    assert df[4]['TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1'] == False
    assert df[4]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1'] == False
    assert df[4]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2'] == False
    assert df[4]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3'] == True
    assert df[4]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4'] == False
    assert df[4]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5'] == False

    # china true overseas 4 true
    assert df[5]['CUST_NUM'] == '1'
    assert df[5]['SUBR_NUM'] == '5'
    assert df[5]['TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1'] == True
    assert df[5]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1'] == False
    assert df[5]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2'] == False
    assert df[5]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3'] == False
    assert df[5]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4'] == True
    assert df[5]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5'] == False

    # china false overseas 5 true
    assert df[6]['CUST_NUM'] == '1'
    assert df[6]['SUBR_NUM'] == '6'
    assert df[6]['TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1'] == False
    assert df[6]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1'] == False
    assert df[6]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2'] == False
    assert df[6]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3'] == False
    assert df[6]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4'] == False
    assert df[6]['AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5'] == True

def test_uni_domains_visit_days_cnt_percentile_ratings(spark: SparkSession):
    weblog_uni_record = spark.createDataFrame(
        [
            ['0', '1', 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 3, 1, 5, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            ['0', '2', 2, 0, 1, 1, 1, 1, 0, 0, 2, 0, 3, 1, 5, 1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0],
            ['0', '3', 3, 0, 1, 1, 1, 1, 0, 0, 3, 0, 3, 1, 5, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            ['0', '4', 4, 0, 1, 1, 1, 1, 0, 0, 4, 0, 3, 1, 5, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            ['1', '1', 5, 0, 0, 1, 7, 1, 0, 0, 5, 0, 3, 1, 5, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            ['1', '2', 6, 0, 0, 1, 7, 1, 0, 0, 6, 0, 3, 1, 5, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            ['2', '3', 7, 0, 0, 1, 7, 1, 0, 0, 7, 0, 3, 1, 5, 1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0],
            ['2', '4', 8, 0, 0, 1, 7, 1, 0, 0, 8, 0, 3, 1, 5, 1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0],
            ['2', '5', 9, 0, 0, 1, 7, 1, 0, 0, 9, 0, 3, 1, 5, 1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0],
        ],
        schema=[
            'CUST_NUM', 'SUBR_NUM',
            "CITYU_DAY_CNT_PAST_180D",
            "CUHK_DAY_CNT_PAST_180D",
            "EDUHK_DAY_CNT_PAST_180D",
            "HKBU_DAY_CNT_PAST_180D",
            "HKU_DAY_CNT_PAST_180D",
            "HKUST_DAY_CNT_PAST_180D",
            "LINGU_DAY_CNT_PAST_180D",
            "POLYU_DAY_CNT_PAST_180D",
            "CITYU_USAGE_SUM_PAST_180D",
            "CUHK_USAGE_SUM_PAST_180D",
            "EDUHK_USAGE_SUM_PAST_180D",
            "HKBU_USAGE_SUM_PAST_180D",
            "HKU_USAGE_SUM_PAST_180D",
            "HKUST_USAGE_SUM_PAST_180D",
            "LINGU_USAGE_SUM_PAST_180D",
            "POLYU_USAGE_SUM_PAST_180D",
            "CITYU_DOMAIN_CNT_PAST_180D",
            "CUHK_DOMAIN_CNT_PAST_180D",
            "EDUHK_DOMAIN_CNT_PAST_180D",
            "HKBU_DOMAIN_CNT_PAST_180D",
            "HKU_DOMAIN_CNT_PAST_180D",
            "HKUST_DOMAIN_CNT_PAST_180D",
            "LINGU_DOMAIN_CNT_PAST_180D",
            "POLYU_DOMAIN_CNT_PAST_180D",

        ]
    )

    n1_table = spark.createDataFrame(
        [
            ['0', '1',18],
            ['0', '2',18],
            ['0', '3',18],
            ['0', '4',27],
            ['1', '1',19],
            ['1', '2',50],
            ['2', '3',19],
            ['2', '4',19],
            ['2', '5',21],
        ],
        schema=[
            'CUST_NUM', 'SUBR_NUM', "D_AGE"
        ]
    )

    df = _uni_domains_visit_days_cnt_percentile_feature(weblog_uni_record, n1_table).orderBy(['CUST_NUM', 'SUBR_NUM']).collect()
    assert len(df) == 7
    # 
    assert df[0]['CUST_NUM'] == '0'
    assert df[0]['SUBR_NUM'] == '1'
    assert df[0]['UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25'] == 0.0

    # 
    assert df[1]['CUST_NUM'] == '0'
    assert df[1]['SUBR_NUM'] == '2'
    assert df[1]['UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25'] == 1/6.0

    # 
    assert df[2]['CUST_NUM'] == '0'
    assert df[2]['SUBR_NUM'] == '3'
    assert df[2]['UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25'] == 1/3.0

    # 
    assert df[3]['CUST_NUM'] == '1'
    assert df[3]['SUBR_NUM'] == '1'
    assert df[3]['UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25'] == 0.5

    # 
    assert df[4]['CUST_NUM'] == '2'
    assert df[4]['SUBR_NUM'] == '3'
    assert df[4]['UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25'] == 0.5

    # 
    assert df[5]['CUST_NUM'] == '2'
    assert df[5]['SUBR_NUM'] == '4'
    assert df[5]['UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25'] == 0.8333333333333334

    # 
    assert df[6]['CUST_NUM'] == '2'
    assert df[6]['SUBR_NUM'] == '5'
    assert df[6]['UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25'] == 1.0


def test_family_website_hit_count_tags(spark: SparkSession):
    r = spark.createDataFrame(
        [
            ['0', '1', 1, 1, 1, 1, 1, 1, 1],
            ['1', '1', 0, 0, 0, 0, 0, 0, 1],
            ['2', '1', 100, 100, 100, 0, 0, 0, 0],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'FAMILY_KIDS_0_2_DOMAIN_CNT_PAST_180D',
            'FAMILY_KIDS_2_6_RED_FLAG_DOMAIN_CNT_PAST_180D',
            'FAMILY_KIDS_6_12_RED_FLAG_DOMAIN_CNT_PAST_180D',
            'FAMILY_KIDS_12_PLUS_RED_FLAG_DOMAIN_CNT_PAST_180D',
            'FAMILY_GENERAL_DOMAIN_CNT_PAST_180D',
            'FAMILY_GENERAL_RED_FLAG_DOMAIN_CNT_PAST_180D',
            'FAMILY_ELDERLY_DOMAIN_CNT_PAST_180D',
        ]
    )

    df = _family_related_ratings(r).sort('CUST_NUM', 'SUBR_NUM').collect()

    assert len(df) == 3

    assert df[0]['CUST_NUM'] == '1'
    assert df[0]['SUBR_NUM'] == '0'
    assert df[0]['FAMILY_WITH_KIDS_AGE_0_2_RELATED_DOMAIN_CNT_180D'] == 1
    assert df[0]['FAMILY_WITH_KIDS_AGE_2_6_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 1
    assert df[0]['FAMILY_WITH_KIDS_AGE_6_12_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 1
    assert df[0]['FAMILY_WITH_KIDS_AGE_12_PLUS_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 1
    assert df[0]['FAMILY_WITH_KIDS_RELATED_DOMAIN_CNT_180D'] == 1
    assert df[0]['FAMILY_WITH_KIDS_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 1
    assert df[0]['FAMILY_WITH_DEPENDENT_ELDERLY_RELATED_DOMAIN_CNT_180D'] == 1

    assert df[1]['CUST_NUM'] == '1'
    assert df[1]['SUBR_NUM'] == '1'
    assert df[1]['FAMILY_WITH_KIDS_AGE_0_2_RELATED_DOMAIN_CNT_180D'] == 0
    assert df[1]['FAMILY_WITH_KIDS_AGE_2_6_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 0
    assert df[1]['FAMILY_WITH_KIDS_AGE_6_12_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 0
    assert df[1]['FAMILY_WITH_KIDS_AGE_12_PLUS_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 0
    assert df[1]['FAMILY_WITH_KIDS_RELATED_DOMAIN_CNT_180D'] == 0
    assert df[1]['FAMILY_WITH_KIDS_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 0
    assert df[1]['FAMILY_WITH_DEPENDENT_ELDERLY_RELATED_DOMAIN_CNT_180D'] == 1

    assert df[2]['CUST_NUM'] == '1'
    assert df[2]['SUBR_NUM'] == '2'
    assert df[2]['FAMILY_WITH_KIDS_AGE_0_2_RELATED_DOMAIN_CNT_180D'] == 100
    assert df[2]['FAMILY_WITH_KIDS_AGE_2_6_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 100
    assert df[2]['FAMILY_WITH_KIDS_AGE_6_12_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 100
    assert df[2]['FAMILY_WITH_KIDS_AGE_12_PLUS_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 0
    assert df[2]['FAMILY_WITH_KIDS_RELATED_DOMAIN_CNT_180D'] == 0
    assert df[2]['FAMILY_WITH_KIDS_RELATED_RED_FLAG_DOMAIN_CNT_180D'] == 0
    assert df[2]['FAMILY_WITH_DEPENDENT_ELDERLY_RELATED_DOMAIN_CNT_180D'] == 0


def test_northbound_driver_ratings(spark: SparkSession):
    r = spark.createDataFrame(
        [
            ['0', '1', 0, 0, 200],
            ['1', '1', 200, 200, 0],
            ['2', '1', 1, 1, 1],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D',
            'NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D',
            'MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D'
        ]
    )

    df = _northbound_driver_ratings(r).sort('CUST_NUM', 'SUBR_NUM').collect()

    assert len(df) == 3

    assert df[0]['CUST_NUM'] == '1'
    assert df[0]['SUBR_NUM'] == '0'
    assert df[0]['WEBLOG_NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D'] == 0
    assert df[0]['WEBLOG_MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D'] == 200
    assert df[0]['WEBLOG_TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D'] == 0

    assert df[1]['CUST_NUM'] == '1'
    assert df[1]['SUBR_NUM'] == '1'
    assert df[1]['WEBLOG_NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D'] == 200
    assert df[1]['WEBLOG_MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D'] == 0
    assert df[1]['WEBLOG_TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D'] == 200

    assert df[2]['CUST_NUM'] == '1'
    assert df[2]['SUBR_NUM'] == '2'
    assert df[2]['WEBLOG_NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D'] == 1
    assert df[2]['WEBLOG_MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D'] == 1
    assert df[2]['WEBLOG_TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D'] == 1


def test_driver_ratings(spark: SparkSession):
    r = spark.createDataFrame(
        [
            ['0', '1', 1, 0, 1, 0, 50, 61, 4],
            ['1', '1', 1, 1, 1, 0, 50, 62, 6],
            ['2', '1', 1, 2, 1, 0, 5, 63, 50],
            ['3', '1', 1, 3, 1, 0, 5, 64, 5],
            ['4', '1', 1, 4, 2, 1, 1, 65, 3],
            ['5', '1', 1, 5, 2, 1, 0, 66, 0],
            ['6', '1', 1, 6, 2, 1, 0, 67, 1],
            ['7', '1', 1, 7, 2, 1, 0, 68, 77],
            ['8', '1', 1, 8, 3, 2, 0, 69, 7]
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'CALTEX_DAY_CNT_PAST_180D',
            'ESSO_DAY_CNT_PAST_180D',
            'HKEMETERAPP_DAY_CNT_PAST_180D',
            'HKETOLL_DAY_CNT_PAST_180D',
            'SHELL_DAY_CNT_PAST_180D',
            'SHELLRECHARGE_DAY_CNT_PAST_180D',
            'TESLA_DAY_CNT_PAST_180D',
        ]
    )

    df = _driver_ratings(r).sort('CUST_NUM', 'SUBR_NUM').collect()

    assert len(df) == 9
    assert df[0]['CUST_NUM'] == '1'
    assert df[0]['SUBR_NUM'] == '0'
    assert df[0]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[0]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[0]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[0]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[0]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[0]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[0]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False

    assert df[1]['CUST_NUM'] == '1'
    assert df[1]['SUBR_NUM'] == '1'
    assert df[1]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[1]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[1]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[1]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[1]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[1]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[1]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True

    assert df[2]['CUST_NUM'] == '1'
    assert df[2]['SUBR_NUM'] == '2'
    assert df[2]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[2]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[2]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[2]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[2]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[2]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[2]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True

    assert df[3]['CUST_NUM'] == '1'
    assert df[3]['SUBR_NUM'] == '3'
    assert df[3]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[3]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[3]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[3]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[3]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[3]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[3]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True

    assert df[4]['CUST_NUM'] == '1'
    assert df[4]['SUBR_NUM'] == '4'
    assert df[4]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[4]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[4]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[4]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[4]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[4]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[4]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False

    assert df[5]['CUST_NUM'] == '1'
    assert df[5]['SUBR_NUM'] == '5'
    assert df[5]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[5]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[5]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[5]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[5]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[5]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[5]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False

    assert df[6]['CUST_NUM'] == '1'
    assert df[6]['SUBR_NUM'] == '6'
    assert df[6]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[6]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[6]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[6]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[6]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[6]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[6]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False

    assert df[7]['CUST_NUM'] == '1'
    assert df[7]['SUBR_NUM'] == '7'
    assert df[7]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[7]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[7]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[7]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[7]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[7]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[7]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True

    assert df[8]['CUST_NUM'] == '1'
    assert df[8]['SUBR_NUM'] == '8'
    assert df[8]['WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[8]['WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[8]['WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[8]['WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[8]['WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN'] == False
    assert df[8]['WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True
    assert df[8]['WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN'] == True