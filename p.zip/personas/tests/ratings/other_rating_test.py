
from pyspark.sql import SparkSession
from ratings.other_ratings import _cdp_mall_parker, _handset_change_ratings


def test_cdp_mall_parker(spark: SparkSession):
    r = spark.createDataFrame(
        [
            ['0', '1', 0.0],
            ['1', '1', 1.0],
            ['2', '1', 1.0],
            ['3', '1', 2.0]
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'BEHAVIORS_DRIVER_SHKP_PARKER'
        ]
    )

    df = _cdp_mall_parker(r).sort('CUST_NUM', 'SUBR_NUM').collect()

    assert len(df) == 4
    assert df[0]['CUST_NUM'] == '1'
    assert df[0]['SUBR_NUM'] == '0'
    assert df[0]['CDP_IS_SHKP_MALL_PARKER'] == False

    assert df[1]['CUST_NUM'] == '1'
    assert df[1]['SUBR_NUM'] == '1'
    assert df[1]['CDP_IS_SHKP_MALL_PARKER'] == True

    assert df[2]['CUST_NUM'] == '1'
    assert df[2]['SUBR_NUM'] == '2'
    assert df[2]['CDP_IS_SHKP_MALL_PARKER'] == True

    assert df[3]['CUST_NUM'] == '1'
    assert df[3]['SUBR_NUM'] == '3'
    assert df[3]['CDP_IS_SHKP_MALL_PARKER'] == False


def test_handset_change(spark: SparkSession):
    df = spark.createDataFrame(
        [
            ['0', '1', True, 100, [0.4, 0.6]],
            ['1', '1', False, 200, [0.3, 0.7]],
            ['2', '1', False, 400, [0.4, 0.6]],
            ['3', '1', False, 400, [0.3, 0.7]]
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'USING_OLD', 'LAST_DEVICE_USED_FOR', 'prob'
        ]
    )
    r = _handset_change_ratings(
        df
    ).sort('SUBR_NUM', 'CUST_NUM')
    
    r.show()

    rows = r.collect()

    assert len(rows) == 2
    assert rows[0]['HANDSET_REUSE_OLD']

    assert rows[1]['HANDSET_CHANGE_HIGH_PROBABILITY']

