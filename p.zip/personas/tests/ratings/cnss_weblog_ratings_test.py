from pyspark.sql import SparkSession

from ratings.cnss_weblog_ratings import (
    _cnss_app_data_usage, _cnss_category_data_usage,
    _cnss_app_active_minutes_usage
)


def test_cnss_app_data_usage(spark: SparkSession, side_output):
    r = spark.createDataFrame(
        [
            [1, 0, 1, 1 ],
            [2, 0, 1, 1 ],
            [3, 0, 1, 1 ],
            [4, 0, 1, 1 ],
            [1, 1, 1, 1 ],
            [2, 1, 1, 1 ],
            [3, 1, 1, 1 ],
            [4, 1, 2, 1 ],
            [5, 1, 3, 1 ],
            [6, 1, 4, 1 ],
            [7, 1, 5, 1 ],
            [8, 1, 6, 1 ],
            [9, 1, 7, 1 ],
            [10, 1, 8, 1],
            [11, 1, 9, 1],
            [12, 1, 10, 1],
            [13, 1, 11, 1],
            [14, 1, 12, 1],
            [15, 1, 13, 1],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'CNSS_APP_MS_TEAMS_DATA_USAGE_30D',
            'CNSS_APP_ZOOM_DATA_USAGE_30D'
        ]
    )
    r = _cnss_app_data_usage(r, side_output).sort('SUBR_NUM', 'CUST_NUM').collect()
    cols = [
        'SUBR_NUM', 'CUST_NUM',
        'CNSS_APP_MS_TEAMS_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_ZOOM_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT'
    ]
    r = [[row[c] for c in cols] for row in r]
    assert r == [
        [1, 0, False, False],
        [1, 1, False, False],
        [2, 0, False, False],
        [2, 1, False, False],
        [3, 0, False, False],
        [3, 1, False, False],
        [4, 0, False, False],
        [4, 1, False, False],
        [5, 1, False, False],
        [6, 1, False, False],
        [7, 1, False, False],
        [8, 1, False, False],
        [9, 1, False, False],
        [10, 1, False, False],
        [11, 1, False, False],
        [12, 1, True, False],
        [13, 1, True, False],
        [14, 1, True, False],
        [15, 1, True, False]
    ]


def test_cnss_category_data_usage(spark: SparkSession, side_output):
    r = spark.createDataFrame(
        [
            [1, 0, 1],
            [2, 0, 1],
            [3, 0, 1],
            [4, 0, 1],
            [1, 1, 1],
            [2, 1, 1],
            [3, 1, 1],
            [4, 1, 2],
            [5, 1, 3],
            [6, 1, 4],
            [7, 1, 5],
            [8, 1, 6],
            [9, 1, 7],
            [10, 1, 8],
            [11, 1, 9],
            [12, 1, 10],
            [13, 1, 11],
            [14, 1, 12],
            [15, 1, 13],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'CNSS_CATEGORY_STREAMING_DATA_USAGE_30D'
        ]
    )
    r = _cnss_category_data_usage(r, side_output).sort('SUBR_NUM', 'CUST_NUM').collect()
    cols = [
        'SUBR_NUM', 'CUST_NUM',
        'CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK'
    ]
    r = [[row[c] for c in cols] for row in r]
    assert r == [
        [12, 1, 0.0],
        [13, 1, 0.3333333333333333],
        [14, 1, 0.6666666666666666],
        [15, 1, 1.0]
    ]


def test_cnss_app_active_minutes_usage(spark: SparkSession, side_output):
    r = spark.createDataFrame(
        [
            [1, 1, 100, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            [1, 2, 100, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2],
            [1, 3, 100, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 3],
            [2, 1, 100, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 4],
            [2, 2, 100, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 5],
            [2, 3, 100, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 6],
            [3, 1, 100, 3, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 7],
            [3, 2, 100, 3, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 8],
            [3, 3, 100, 4, 1, 9, 1, 1, 1, 1, 1, 1, 1, 1, 1, 9],
            [4, 4, 100, 5, 1, 10, 2, 1, 1, 1, 1, 1, 1, 1, 1, 10],
        ],
        schema=[
            'CUST_NUM', 'SUBR_NUM',
            'CNSS_APP_DISNEY_PLUS_5GHBB_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_DISNEY_PLUS_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_MS_TEAMS_5GHBB_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_MS_TEAMS_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_MYTV_SUPER_5GHBB_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_MYTV_SUPER_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_NETFLIX_5GHBB_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_NETFLIX_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_VIU_5GHBB_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_VIU_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_YOUTUBE_5GHBB_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_YOUTUBE_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_ZOOM_5GHBB_ACTIVE_MINUTES_PAST_30D',
            'CNSS_APP_ZOOM_ACTIVE_MINUTES_PAST_30D'
        ]
    )
    r = _cnss_app_active_minutes_usage(r, side_output).sort('CUST_NUM', 'SUBR_NUM').collect()
    cols = [
        'CUST_NUM', 'SUBR_NUM',
        'CNSS_APP_DISNEY_PLUS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_DISNEY_PLUS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_MS_TEAMS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_MS_TEAMS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_MYTV_SUPER_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_MYTV_SUPER_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_NETFLIX_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_NETFLIX_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_VIU_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_VIU_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_YOUTUBE_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_YOUTUBE_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_ZOOM_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT',
        'CNSS_APP_ZOOM_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT'
    ]
    r = [[row[c] for c in cols] for row in r]
    assert r == [
        [1, 1, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
        [1, 2, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
        [1, 3, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
        [2, 1, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
        [2, 2, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
        [2, 3, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
        [3, 1, False, False, False, False, False, False, False, False, False, False, False, False, False, False],
        [3, 2, False, False, False, False, False, False, False, False, False, False, False, False, False, True],
        [3, 3, False, True, False, False, False, False, False, False, False, False, False, False, False, True],
        [4, 4, False, True, False, True, False, False, False, False, False, False, False, False, False, True]
    ]