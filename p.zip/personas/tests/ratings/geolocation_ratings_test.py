
from pyspark.sql import SparkSession
from ratings.geolocation_ratings import (
    _roaming_trip_avg_duration, _roaming_trip_count_ratios,
    _roaming_group_trip_count_features
)


def test_roaming_group_trip_count(spark: SparkSession, side_output):
    r = spark.createDataFrame(
        [
            ['1', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ['2', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ['3', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ['4', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ['1', '1', 5, 15, 0, 0, 0, 0, 0, 0, 0],
            ['2', '1', 5, 14, 0, 0, 0, 0, 0, 0, 0],
            ['3', '1', 5, 13, 0, 0, 0, 0, 0, 0, 0],
            ['4', '1', 5, 12, 0, 0, 0, 0, 0, 0, 0],
            ['5', '1', 5, 11, 0, 0, 0, 0, 0, 0, 0],
            ['6', '1', 6, 10, 0, 0, 0, 0, 0, 0, 0],
            ['7', '1', 7, 9, 0, 0, 0, 0, 0, 0, 0],
            ['8', '1', 8, 8, 0, 0, 0, 0, 0, 0, 0],
            ['9', '1', 9, 7, 0, 0, 0, 0, 0, 0, 0],
            ['10', '1', 10, 6, 0, 0, 0, 0, 0, 0, 0],
            ['11', '1', 11, 5, 0, 0, 0, 0, 0, 0, 0],
            ['12', '1', 12, 4, 0, 0, 0, 0, 0, 0, 0],
            ['13', '1', 13, 3, 0, 0, 0, 0, 0, 0, 0],
            ['14', '1', 14, 2, 0, 0, 0, 0, 0, 0, 0],
            ['15', '1', 15, 1, 0, 0, 0, 0, 0, 0, 0],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',

            'ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_AUS_NEWZ_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_EUROPE_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_US_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_OTHER_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_APAC_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_NON_APAC_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_TRIP_COUNT_180D',

            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_MACAU_TRIP_COUNT_180D'
        ]
    )

    df = _roaming_group_trip_count_features(r, side_output).sort('CUST_NUM', 'SUBR_NUM').collect()
    assert len(df) == 19
    # all false
    assert df[0]['CUST_NUM'] == '0'
    assert df[0]['SUBR_NUM'] == '1'
    assert df[0]['ROAMING_TRIP_COUNT_PRODUCT_AUS_NEWZ_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False

    assert df[6]['CUST_NUM'] == '1'
    assert df[6]['SUBR_NUM'] == '11'
    assert df[6]['ROAMING_TRIP_COUNT_PRODUCT_AUS_NEWZ_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == True

    assert df[5]['CUST_NUM'] == '1'
    assert df[5]['SUBR_NUM'] == '10'
    assert df[5]['ROAMING_TRIP_COUNT_PRODUCT_AUS_NEWZ_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False


def test_roaming_average_trip_duration(spark: SparkSession, side_output):
    r = spark.createDataFrame(
        [
            ['1',  '0',  1,1,1,1,     0,  0,  0,  0, 0, 0],
            ['2',  '0',  1,1,1,1,     0,  0,  0,  0, 0, 0],
            ['3',  '0',  1,1,1,1,     0,  0,  0,  0, 0, 0],
            ['4',  '0',  1,1,1,1,     0,  0,  0,  0, 0, 0],
            ['1',  '1',  1,1,1,1,     5,  5,  5,  5, 15, 0],
            ['2',  '1',  1,1,1,1,     5,  5,  5,  5, 14, 0],
            ['3',  '1',  1,1,1,1,     5,  5,  5,  5, 13, 0],
            ['4',  '1',  1,1,1,1,     5,  5,  5,  5, 12, 0],
            ['5',  '1',  1,1,1,1,     5,  5,  5,  5, 11, 0],
            ['6',  '1',  1,1,1,1,     6,  6,  6,  6, 10, 0],
            ['7',  '1',  1,1,1,1,     7,  7,  7,  7, 9, 0],
            ['8',  '1',  1,1,1,1,     8,  8,  8,  8, 8, 0],
            ['9',  '1',  1,1,1,1,     9,  9,  9,  9, 7, 0],
            ['10', '1',  1,1,1,1,     10, 10, 10, 10, 6, 0],
            ['11', '1',  1,1,1,1,     11, 11, 11, 11, 5, 0],
            ['12', '1',  1,1,1,1,     12, 12, 12, 12, 4, 0],
            ['13', '1',  1,1,1,1,     13, 13, 13, 13, 3, 0],
            ['14', '1',  1,1,1,1,     14, 14, 14, 14, 2, 0],
            ['15', '1',  1,1,1,30,    15, 15, 15, 15, 1, 0],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_UNITED_KINGDOM_TRIP_DAYS_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_TAIWAN_TRIP_DAYS_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_CANADA_TRIP_DAYS_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_OCEANIA_TRIP_DAYS_COUNT_180D',

            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_TRIP_DURATION_AVG_DAYS_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_JAPAN_TRIP_DURATION_AVG_DAYS_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_TAIWAN_TRIP_DURATION_AVG_DAYS_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_SOUTH_KOREA_TRIP_DURATION_AVG_DAYS_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_TRIP_DURATION_AVG_DAYS_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_NON_APAC_TRIP_DURATION_AVG_DAYS_180D'
        ]
    )

    df = _roaming_trip_avg_duration(r, side_output).sort('CUST_NUM', 'SUBR_NUM').collect()

    assert len(df) == 18

    assert df[0]['CUST_NUM'] == '0'
    assert df[0]['SUBR_NUM'] == '1'
    assert df[0]['ROAMING_TRIP_AVG_DURATION_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[0]['ROAMING_TRIP_AVG_DURATION_JAPAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[0]['ROAMING_TRIP_AVG_DURATION_TAIWAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[0]['ROAMING_TRIP_AVG_DURATION_KOREA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[0]['ROAMING_TRIP_AVG_DURATION_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[0]['ROAMING_TRIP_AVG_DURATION_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False

    assert df[9]['CUST_NUM'] == '1'
    assert df[9]['SUBR_NUM'] == '14'
    assert df[9]['ROAMING_TRIP_AVG_DURATION_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == True
    assert df[9]['ROAMING_TRIP_AVG_DURATION_JAPAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == True
    assert df[9]['ROAMING_TRIP_AVG_DURATION_TAIWAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == True
    assert df[9]['ROAMING_TRIP_AVG_DURATION_KOREA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == True
    assert df[9]['ROAMING_TRIP_AVG_DURATION_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[9]['ROAMING_TRIP_AVG_DURATION_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False

    assert df[4]['CUST_NUM'] == '1'
    assert df[4]['SUBR_NUM'] == '1'
    assert df[4]['ROAMING_TRIP_AVG_DURATION_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[4]['ROAMING_TRIP_AVG_DURATION_JAPAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[4]['ROAMING_TRIP_AVG_DURATION_TAIWAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[4]['ROAMING_TRIP_AVG_DURATION_KOREA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False
    assert df[4]['ROAMING_TRIP_AVG_DURATION_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == True
    assert df[4]['ROAMING_TRIP_AVG_DURATION_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1'] == False


def test_roaming_trip_count_ratio(spark: SparkSession, side_output):
    r = spark.createDataFrame(
        [
            [1, 0,   1, 1, 1, 1,   0, 0, 0, 0],
            [2, 0,   1, 1, 1, 1,   0, 0, 0, 0],
            [3, 0,   1, 1, 1, 1,   0, 0, 0, 0],
            [4, 0,   1, 1, 1, 1,   0, 0, 0, 0],
            [1, 1,   1, 1, 1, 1,   5, 2, 5, 0],
            [2, 1,   1, 1, 1, 1,   5, 2, 5, 0],
            [3, 1,   1, 1, 1, 1,   5, 2, 5, 0],
            [4, 1,   1, 1, 1, 1,   5, 2, 5, 0],
            [5, 1,   1, 1, 1, 1,   5, 2, 5, 0],
            [6, 1,   1, 1, 1, 1,   6, 2, 6, 0],
            [7, 1,   1, 1, 1, 1,   7, 2, 7, 0],
            [8, 1,   1, 1, 1, 1,   8, 2, 8, 0],
            [9, 1,   1, 1, 1, 1,   9, 2, 9, 0],
            [10, 1,  1, 1, 1, 1,   10, 2, 10, 0],
            [11, 1,  1, 1, 1, 1,   11, 2, 11, 0],
            [12, 1,  1, 1, 1, 1,   12, 2, 12, 0],
            [13, 1,  1, 1, 1, 1,   13, 2, 13, 0],
            [14, 1,  1, 1, 1, 1,   1, 0, 0, 0],
            [15, 1,  1, 1, 1, 30,  15, 0, 0, 0],
        ],
        schema=[
            'SUBR_NUM', 'CUST_NUM',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_UNITED_KINGDOM_TRIP_DAYS_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_TAIWAN_TRIP_DAYS_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_CANADA_TRIP_DAYS_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_OCEANIA_TRIP_DAYS_COUNT_180D',

            'ROAMING_TRAVEL_COUNTRY_GROUP_NON_APAC_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_GROUP_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_TRIP_COUNT_180D',
            'ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_MACAU_TRIP_COUNT_180D'
        ]
    )

    df = _roaming_trip_count_ratios(r, side_output).sort('CUST_NUM', 'SUBR_NUM').collect()
    assert len(df) == 18

    assert df[0]['CUST_NUM'] == 0
    assert df[0]['SUBR_NUM'] == 1
    assert df[0]['ROAMING_TRIP_COUNT_RATIO_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1_OR_IS_100'] == False

    assert df[3]['CUST_NUM'] == 0
    assert df[3]['SUBR_NUM'] == 4
    assert df[3]['ROAMING_TRIP_COUNT_RATIO_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1_OR_IS_100'] == False

    assert df[17]['CUST_NUM'] == 1
    assert df[17]['SUBR_NUM'] == 14
    assert df[17]['ROAMING_TRIP_COUNT_RATIO_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1_OR_IS_100'] == True

    assert df[11]['CUST_NUM'] == 1
    assert df[11]['SUBR_NUM'] == 8
    assert df[11]['ROAMING_TRIP_COUNT_RATIO_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1_OR_IS_100'] == True

    assert df[10]['CUST_NUM'] == 1
    assert df[10]['SUBR_NUM'] == 7
    assert df[10]['ROAMING_TRIP_COUNT_RATIO_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1_OR_IS_100'] == False