from pyspark.sql import SparkSession, DataFrame
from datetime import datetime
from ratings.geolocation_cell_site_ratings import (
    ratings_uni_geo_footprint, rating_max_day_count_in_the_same_district,
    rating_max_round_trip_day_count, rating_mid_point_district_distribution_entropy,
    rating_many_districts_visited_day_count,
    rating_geolocation_mtr_normal_n_heavy_day_count,
    rating_geolocation_mtr_golden_stations,
    rating_geolocation_disney_last_12m
)
from ratings.geolocation_ratings import (
    ratings_roaming_trip_count, ratings_roaming_average_trip_duration, ratings_roaming_trip_count_ratios
)
from ratings.weblog_ratings import (
    ratings_airlines_booking_data_usage, ratings_uni_domains_visit_days_cnt_percentile,
    ratings_family_related_domain_count, ratings_northbound_driver, ratings_driver,
    ratings_gamer, ratings_house_mover,
    ratings_weblog_daily_usage,
)
from ratings.cnss_weblog_ratings import (
    ratings_cnss_app_usage, ratings_cnss_category_usage,
    ratings_cnss_app_active_minutes_usage,
    ratings_cnss_messaging_data_usage,
    rating_cnss_disney_plus_data_usage
)
from ratings.other_ratings import (
    ratings_cdp_mall_parker, ratings_handset_change
)
from ratings.calllog_ratings import (
    ratings_moving_company_caller
)
from ratings.subscribers_info_ratings import ratings_subscriber_age, ratings_subscriber_income, ratings_subscriber_is_hbb
from ratings.feature_ratings import ratings_defaults
from functools import reduce
from typing import Dict, Callable
import paths


ALL_RATINGS: Dict[str, Callable[[SparkSession, datetime, str], DataFrame]] = {
    'airlines_booking_data_usage': ratings_airlines_booking_data_usage,
    'geolocation_roaming_trip_count': ratings_roaming_trip_count,
    'geolocation_roaming_average_trip_duration': ratings_roaming_average_trip_duration,
    'geolocation_roaming_trip_count_ratio': ratings_roaming_trip_count_ratios,
    'rating_geolocation_mtr_normal_n_heavy_day_count': rating_geolocation_mtr_normal_n_heavy_day_count,
    'rating_geolocation_mtr_golden_stations': rating_geolocation_mtr_golden_stations,
    
    'subscriber_age': ratings_subscriber_age,
    'uni_geo_footprint': ratings_uni_geo_footprint,
    'uni_domains_visit_days_cnt_percentile': ratings_uni_domains_visit_days_cnt_percentile,
    'subscriber_income': ratings_subscriber_income,
    'family_member': ratings_family_related_domain_count,
    
    "max_day_count_in_the_same_district": rating_max_day_count_in_the_same_district,
    "max_round_trip_day_count": rating_max_round_trip_day_count,
    "mid_point_district_distribution_entropy": rating_mid_point_district_distribution_entropy,
    "rating_many_districts_visited_day_count": rating_many_districts_visited_day_count,
    
    'cnss_app_data_usage': ratings_cnss_app_usage,
    'cnss_category_data_usage': ratings_cnss_category_usage,
    'cnss_app_active_minutes_usage': ratings_cnss_app_active_minutes_usage,
    
    'driver_northbound_driver': ratings_northbound_driver,
    'driver_active_driver': ratings_driver,
    'driver_mall_parker': ratings_cdp_mall_parker,
    
    'ratings_gamer': ratings_gamer,
    
    'house_mover': ratings_house_mover,
    'moving_company_caller': ratings_moving_company_caller,
    'handset_change': ratings_handset_change,
    'weblog_data_usage': ratings_weblog_daily_usage,
    'ratings_cnss_messaging_data_usage': ratings_cnss_messaging_data_usage,
    'rating_geolocation_disney_last_12m': rating_geolocation_disney_last_12m,
    'ratings_subscriber_is_hbb': ratings_subscriber_is_hbb,

    'rating_cnss_disney_plus_data_usage': rating_cnss_disney_plus_data_usage
}


def join_ratings(all_ratings, defaults: dict):
    ratings_df = reduce(lambda a, b: a.join(b, how='outer', on=['SUBR_NUM', 'CUST_NUM']), all_ratings)
    ratings_df = ratings_df.fillna(defaults)
    return ratings_df


def run(spark: SparkSession, run_date: datetime, version: str):
    """
    Make (all_ratings)
    SUBR_NUM, CUST_NUM, RATING1, RATING2, ...
    x         x         1.0      2.0      ...
    ...

    Ratings are defined in ratings.feature_ratings
    """

    path_date = run_date.strftime('%Y-%m-%d')

    def save_ratings(rating_name: str, func: Callable[[SparkSession, datetime, str], DataFrame]) -> str:
        path = f'dtap://TenantStorage/personas/ratings/run_date={path_date}/rating={rating_name}/version={version}'
        func(spark, run_date, version).write.mode('overwrite').parquet(path)
        return path

    ratings_dfs = [save_ratings(n, f) for n, f in ALL_RATINGS.items()]
    ratings_dfs = [spark.read.parquet(p) for p in ratings_dfs]
    ratings_df = join_ratings(ratings_dfs, defaults=ratings_defaults())
    ratings_df.write.mode('overwrite').parquet(
        paths.all_ratings.format(path_date=path_date, version=version)
    )


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='calculate ratings')
    parser.add_argument('run_date', metavar='yyyy-mm-dd', type=str)
    parser.add_argument('version', metavar='v', type=str)
    args = parser.parse_args()

    spark = SparkSession.builder.appName("persona-ratings").getOrCreate()
    run_date = datetime.strptime(args.run_date, '%Y-%m-%d')
    _now = datetime.now()

    if (_now - run_date).days > 3:
        raise ValueError(f'now {_now} - run date {run_date} > 3 days, too late')

    run(spark, run_date, args.version)
