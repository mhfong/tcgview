# oracle data
prepaid_postpaid_n1 = 'dtap://TenantStorage/oracle_data/overwrite_tables/PRD_BIZ_SUMM_VW.VW_PREPD_POSTPAID_SUBR_N1'

active_postpaid_mass_market_and_business_market = 'dtap://TenantStorage/oracle_data/overwrite_tables/PRD_BIZ_SUMM_VW.VW_ACT_MNO_SUBR'
active_5G_home_broadband = 'dtap://TenantStorage/oracle_data/overwrite_tables/PRD_BIZ_SUMM_VW.VW_ACT_5GHBB_SUBR'
active_postpaid_non_contract = 'dtap://TenantStorage/oracle_data/overwrite_tables/PRD_BIZ_SUMM_VW.VW_ACT_NON_CONTRACT_SUBR'
# barkadahan Filipino Tagalog
# sahabat Indonesian
active_prepaid_normal_barkadahan_sahabat = 'dtap://TenantStorage/oracle_data/overwrite_tables/PRD_BIZ_SUMM_VW.VW_ACT_BSS_SSS_NORMAL_PREPD_SUBR'

# data for ratings
geolocation_roaming_trip_count = 'dtap://TenantStorage/geolocation/roaming_trip_counts'
weblog_travel_website_record = 'dtap://ext_mapr/weblog/subscribers/travel_website'
geolocation_stop_near_university = "dtap://TenantStorage/geolocation/university"
weblog_university_website_record = "dtap://ext_mapr/weblog/subscribers/university_website"
census_stat_by_address_estate_name = 'dtap://TenantStorage/gov_stat/by_estate'
weblog_family_website_record = 'dtap://ext_mapr/weblog/subscribers/family_website'
geolocation_round_trip_record = 'dtap://TenantStorage/geolocation/round_trip_district_record'
geolocation_count_of_district_record = 'dtap://TenantStorage/geolocation/count_of_district_group'
geolocation_full_day_stay_in_one_district_record = "dtap://TenantStorage/geolocation/full_day_stay_district_record"
cnss_app = 'dtap://TenantStorage/cnss/output_app/date_id={date_id}'
cnss_category = 'dtap://TenantStorage/cnss/output_category/date_id={date_id}'
geolocation_mtr_record = 'dtap://TenantStorage/geolocation/daily_mtr_footprint'
weblog_northbound_driver_website = 'dtap://ext_mapr/weblog/subscribers/northbound_driver_website'
weblog_driver_website = 'dtap://ext_mapr/weblog/subscribers/driver_website'
cdp_data = 'dtap://ext_mapr/cdp'
cnss_remote = 'dtap://TenantStorage/cnss/cnss_s11/output/frequent_remote_app'
cnss_streaming = 'dtap://TenantStorage/cnss/cnss_s11/output/frequent_streaming_app'
weblog_games_website = 'dtap://ext_mapr/weblog/subscribers/games_website'
weblog_house_moving_website = 'dtap://ext_mapr/weblog/subscribers/house_moving_website'
calllog = 'dtap://ext_mapr/c360_data/PRD_BIZ_SUMM_VW.VW_END_USER_MSC_CALL_DTL'
cnss_disney_plus = 'dtap://TenantStorage/cnss/cnss_s11/output/disney_plus_app'

ebm_data_usage_uplink_downlink_path = 'dtap://TenantStorage/cnss/ebm/personas_features/data_usage_uplink_downlink'
t_domain_daily_path = 'dtap://ext_mapr/weblog/t_domain_daily'
t_domain_monthly_path = 'dtap://ext_mapr/weblog/t_domain_monthly'
geolocation_feature = "dtap://ext_mapr/geolocation/stop/result/feature"
# tags
active_users = 'dtap://TenantStorage/personas/active_users/run_date={path_date}/version={version}'
tags = 'dtap://TenantStorage/personas/tags/run_date={path_date}/version={version}'
all_ratings = 'dtap://TenantStorage/personas/all_ratings/run_date={path_date}/version={version}'

# observability
side_output = 'dtap://TenantStorage/personas/observability/side_outputs/run_date={path_date}/version={version}/col_hash={col_hash}'