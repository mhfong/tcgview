import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from datetime import datetime, timedelta
from ratings.feature_ratings import BooleanFeatureRatings as Bool, FloatFeatureRatings as Float
from ratings.agg_window_functions import _rolling_sum_total_ratio
from ratings.subscribers_info_ratings import add_is_hbb
import paths
from observability.side_output import SideOutputWriter
from functools import reduce
from ratings.agg_window_functions import _multi_partition_percent_rank
from pyspark.sql.window import Window
from pyspark.sql import DataFrame

def _cnss_app_data_usage(data: DataFrame, side_output: SideOutputWriter) -> DataFrame:
    """
    make
    CNSS_APP_MS_TEAMS_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_ZOOM_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT

    :param data:
    :param side_output:
    :return:
    """

    apps = {
        'CNSS_APP_MS_TEAMS_DATA_USAGE_30D': Bool.CNSS_APP_MS_TEAMS_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_ZOOM_DATA_USAGE_30D': Bool.CNSS_APP_ZOOM_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT
    }

    totals = data.agg(
        *[F.sum(F.col(app)).alias(app + '_TOTAL') for app in apps]
    ).limit(1)

    data = data.crossJoin(
        F.broadcast(totals)
    )

    thresholds = [
        _rolling_sum_total_ratio(
            data,
            rolling_sum_col=app,
            total_col=app + '_TOTAL',
            result_col_name=app + '_ROLLING_SUM_RATIO'
        ).agg(
            F.min(
                F.when(F.col(app + '_ROLLING_SUM_RATIO') >= F.lit(0.5), F.col(app)).otherwise(None)
            ).alias(app + '_ROLLING_SUM_MID_POINT')
        ).limit(1)
        for app in apps
    ]
    thresholds = reduce(lambda a, b: a.crossJoin(b), thresholds)
    side_output.write(thresholds, key_prefix=_cnss_app_data_usage.__name__)

    data = data.crossJoin(
        F.broadcast(thresholds)
    )
    return data.select(
        'CUST_NUM', 'SUBR_NUM',
        *[
            F.when(
                F.col(app_usage) > F.col(app_usage + '_ROLLING_SUM_MID_POINT'), True
            ).otherwise(False).alias(feature)
            for app_usage, feature in apps.items()
        ]
    ).fillna(False)


def _cnss_category_data_usage(data: DataFrame, side_output: SideOutputWriter) -> DataFrame:
    """
    Make CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK
    :param data:
    :param side_output:
    :return:
    """
    feature = Float.CNSS_CATEGORY_STREAMING_DATA_USAGE_30D_GT_ROLLING_SUM_MID_POINT_PERCENT_RANK
    usage = 'CNSS_CATEGORY_STREAMING_DATA_USAGE_30D'

    totals = data.agg(
        F.sum(F.col(usage)).alias(usage + '_TOTAL')
    ).limit(1)

    data = data.crossJoin(
        F.broadcast(totals)
    )

    thresholds = _rolling_sum_total_ratio(
        data,
        rolling_sum_col=usage,
        total_col=usage + '_TOTAL',
        result_col_name=usage + '_ROLLING_SUM_RATIO'
    ).agg(
        F.min(
            F.when(F.col(usage + '_ROLLING_SUM_RATIO') >= F.lit(0.5), F.col(usage)).otherwise(None)
        ).alias(usage + '_ROLLING_SUM_MID_POINT')
    ).limit(1)

    side_output.write(thresholds, key_prefix=_cnss_category_data_usage.__name__)

    heavy = data.crossJoin(
        F.broadcast(thresholds)
    ).filter(
        F.col(usage) > F.col(usage + '_ROLLING_SUM_MID_POINT')
    )
    
    return _multi_partition_percent_rank(heavy, rank_col=usage).withColumnRenamed(
        'percent_rank', feature
    )


def ratings_cnss_app_usage(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=3)).strftime("%Y%m%d")
    df = spark.read.parquet(paths.cnss_app.format(date_id=path_date))
    side_output = SideOutputWriter(run_date, version)
    return _cnss_app_data_usage(df, side_output)


def ratings_cnss_category_usage(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=3)).strftime("%Y%m%d")
    df = spark.read.parquet(paths.cnss_category.format(date_id=path_date))
    side_output = SideOutputWriter(run_date, version)
    return _cnss_category_data_usage(df, side_output)


def _cnss_app_active_minutes_usage(data: DataFrame, side_output: SideOutputWriter) -> DataFrame:
    """
    make
    CNSS_APP_DISNEY_PLUS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_DISNEY_PLUS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_MS_TEAMS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_MS_TEAMS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_MYTV_SUPER_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_MYTV_SUPER_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_NETFLIX_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_NETFLIX_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_VIU_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_VIU_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_YOUTUBE_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_YOUTUBE_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_ZOOM_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    CNSS_APP_ZOOM_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    :param data:
    :param side_output:
    :return:
    """
    apps = {
        'CNSS_APP_DISNEY_PLUS_5GHBB_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_DISNEY_PLUS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_DISNEY_PLUS_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_DISNEY_PLUS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_MS_TEAMS_5GHBB_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_MS_TEAMS_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_MS_TEAMS_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_MS_TEAMS_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_MYTV_SUPER_5GHBB_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_MYTV_SUPER_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_MYTV_SUPER_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_MYTV_SUPER_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_NETFLIX_5GHBB_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_NETFLIX_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_NETFLIX_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_NETFLIX_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_VIU_5GHBB_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_VIU_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_VIU_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_VIU_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_YOUTUBE_5GHBB_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_YOUTUBE_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_YOUTUBE_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_YOUTUBE_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_ZOOM_5GHBB_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_ZOOM_5GHBB_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT,
        'CNSS_APP_ZOOM_ACTIVE_MINUTES_PAST_30D': Bool.CNSS_APP_ZOOM_ACTIVE_MINUTES_GT_ROLLING_SUM_MID_POINT
    }

    totals = data.agg(
        *[F.sum(F.col(app)).alias(app + '_TOTAL') for app in apps]
    ).limit(1)

    data = data.crossJoin(
        F.broadcast(totals)
    )

    thresholds = [
        _rolling_sum_total_ratio(
            data,
            rolling_sum_col=app,
            total_col=app + '_TOTAL',
            result_col_name=app + '_ROLLING_SUM_RATIO'
        ).agg(
            F.min(
                F.when(F.col(app + '_ROLLING_SUM_RATIO') >= F.lit(0.5), F.col(app)).otherwise(None)
            ).alias(app + '_ROLLING_SUM_MID_POINT')
        ).limit(1)
        for app in apps
    ]
    thresholds = reduce(lambda a, b: a.crossJoin(b), thresholds)
    side_output.write(thresholds, key_prefix=_cnss_app_active_minutes_usage.__name__)

    data = data.crossJoin(
        F.broadcast(thresholds)
    )
    return data.select(
        'CUST_NUM', 'SUBR_NUM',
        *[
            F.when(
                F.col(app_usage) > F.col(app_usage + '_ROLLING_SUM_MID_POINT'), True
            ).otherwise(False).alias(feature)
            for app_usage, feature in apps.items()
        ]
    ).fillna(False)


def ratings_cnss_app_active_minutes_usage(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=3)).strftime("%Y%m%d")
    df_streaming = spark.read.parquet(f"{paths.cnss_streaming}/date_id={path_date}")
    df_remote = spark.read.parquet(f"{paths.cnss_remote}/date_id={path_date}")
    df = df_streaming.join(df_remote, ['CUST_NUM','SUBR_NUM'], 'outer')
    side_output = SideOutputWriter(run_date, version)
    return _cnss_app_active_minutes_usage(df, side_output)


def _cnss_app_messaging_data_usage(df_30D: DataFrame) -> DataFrame:
    MB_TO_GB_CONVERSION = 1024
    key = ["CUST_NUM", "SUBR_NUM"]
    df_with_total = df_30D.groupBy(key)\
        .agg(F.sum("ALL_CNSS_APPS_TOTAL_UPLINK_USAGE_30D").alias("ALL_CNSS_APPS_TOTAL_UPLINK_USAGE_30D"),
            (F.sum("FACETIME_UPLINK_USAGE_30D") / MB_TO_GB_CONVERSION).alias("facetime_upload_gb_30d"),
            (F.sum("WECHAT_UPLINK_USAGE_30D") / MB_TO_GB_CONVERSION).alias("wechat_upload_gb_30d"),
            (F.sum("WHATSAPP_UPLINK_USAGE_30D") / MB_TO_GB_CONVERSION).alias("whatsapp_upload_gb_30d")
             )
    
    window = Window.orderBy(F.desc("ALL_CNSS_APPS_TOTAL_UPLINK_USAGE_30D"))
    
    # Add percentile rank and filter top 10%
    result_df = df_with_total\
        .withColumn(Float.CNSS_APP_MOBILE_TOTAL_UPLINK_BYTES_PERCENTILE_RANK_30D, F.round(F.percent_rank().over(window), 4))\
        .withColumn(Float.CNSS_CATEGORY_MESSAGING_MOBILE_UPLOAD_GB_30D, 
                        F.col("facetime_upload_gb_30d") + F.col("wechat_upload_gb_30d") + F.col("whatsapp_upload_gb_30d")
                    )
    
    return result_df.select(
        *key,
        Float.CNSS_APP_MOBILE_TOTAL_UPLINK_BYTES_PERCENTILE_RANK_30D,
        Float.CNSS_CATEGORY_MESSAGING_MOBILE_UPLOAD_GB_30D
    )


def ratings_cnss_messaging_data_usage(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=3)).strftime("%Y%m%d")
    df_data_usage = spark.read.parquet(f"{paths.ebm_data_usage_uplink_downlink_path}/date_id={path_date}")
    df_data_usage = add_is_hbb(df_data_usage)\
        .filter(F.col(Bool.IS_HBB) == False)\
        .drop(Bool.IS_HBB)
    side_output = SideOutputWriter(run_date, version)
    return _cnss_app_messaging_data_usage(df_data_usage)


def _cnss_disney_plus_data_usage(data: DataFrame) -> DataFrame:
    """
    Make EBM_APP_IS_DISNEY_PLUS_USER
    :param data:
    :param side_output:
    :return:
    """

    return data.withColumn(
        Bool.EBM_APP_IS_DISNEY_PLUS_USER,
        F.when(F.col('WATCHED_DISNEY_PLUS_PAST_30D'), True)
    ).select(
        'CUST_NUM', 'SUBR_NUM',
        Bool.EBM_APP_IS_DISNEY_PLUS_USER
    ).fillna(False)


def rating_cnss_disney_plus_data_usage(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=3)).strftime("%Y%m%d")
    df = spark.read.parquet(f"{paths.cnss_disney_plus}/date_id={path_date}")
    return _cnss_disney_plus_data_usage(df)