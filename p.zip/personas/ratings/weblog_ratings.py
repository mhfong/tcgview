import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar
from ratings.feature_ratings import BooleanFeatureRatings as Bool
from ratings.feature_ratings import FloatFeatureRatings as Float
from paths import (weblog_travel_website_record,
                   weblog_university_website_record,
                   weblog_family_website_record,
                   weblog_northbound_driver_website,
                   weblog_driver_website,
                   weblog_house_moving_website,
                   prepaid_postpaid_n1,
                   weblog_games_website,
                   t_domain_daily_path,
                   t_domain_monthly_path)
from ratings.schema import travel_website_schema, family_website_schema
from ratings.cnss_weblog_ratings import _multi_partition_percent_rank


def _airlines_booking_data_usage_ratings(df) -> DataFrame:
    """
    Calculate
    Bool.TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1
    Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1
    Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2
    Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3
    Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4
    Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5
    """

    china_macau_domain_cnt = "TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D"
    airline_booking_data_usage = "AIRLINES_BOOKING_DATA_USAGE_SUM_PAST_180D"

    df = df.withColumn(
        Bool.TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1,
        F.col(china_macau_domain_cnt) >= 1
    )

    df = df.withColumn(
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1,
        F.when((F.col(airline_booking_data_usage) > 11388.5) & (F.col(airline_booking_data_usage) <= 1000000), True)
    ).withColumn(
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2,
        F.when((F.col(airline_booking_data_usage) > 1000000) & (F.col(airline_booking_data_usage) <= 3000000), True)
    ).withColumn(
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3,
        F.when((F.col(airline_booking_data_usage) > 3000000) & (F.col(airline_booking_data_usage) <= 5000000), True)
    ).withColumn(
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4,
        F.when((F.col(airline_booking_data_usage) > 5000000) & (F.col(airline_booking_data_usage) <= 9000000), True)
    ).withColumn(
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5,
        F.col(airline_booking_data_usage) > 9000000
    )

    df = df.select(
        'CUST_NUM', 'SUBR_NUM',
        Bool.TRANSPORTATION_BOOKING_CHINA_AND_MACAU_DOMAIN_CNT_PAST_14D_GTE_1,

        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER1,
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER2,
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER3,
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER4,
        Bool.AIRLINES_BOOKING_DATA_USAGE_PAST_180D_IS_TIER5,
    ).fillna(False)

    return df


def ratings_airlines_booking_data_usage(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=2)).strftime("%Y%m%d")
    weblog_usage = spark.read.schema(travel_website_schema).parquet(f'{weblog_travel_website_record}/date_id={path_date}')
    return _airlines_booking_data_usage_ratings(weblog_usage)


def _uni_domains_visit_days_cnt_percentile_feature(weblog_uni_df: DataFrame, n1_table: DataFrame) -> DataFrame:
    """
    Return university domain day count in percentile weblog record
    :param weblog_uni_df:
    :return:
    """

    related_university_columns = ["CITYU_DAY_CNT_PAST_180D",
                                  "CUHK_DAY_CNT_PAST_180D",
                                  "EDUHK_DAY_CNT_PAST_180D",
                                  "HKBU_DAY_CNT_PAST_180D",
                                  "HKU_DAY_CNT_PAST_180D",
                                  "HKUST_DAY_CNT_PAST_180D",
                                  "LINGU_DAY_CNT_PAST_180D",
                                  "POLYU_DAY_CNT_PAST_180D"]
    # weblog filtering
    age_lowerbound = 18  # inclusive
    age_upperbound = 25  # inclusive
    filtered_n1 = n1_table.select("CUST_NUM", "SUBR_NUM", "D_AGE") \
        .filter((F.col("D_AGE").isNotNull()) & \
                (F.col("D_AGE").isin(*range(age_lowerbound, age_upperbound + 1))))

    weblog_uni_df = weblog_uni_df.join(filtered_n1, on=["CUST_NUM", "SUBR_NUM"], how="inner")

    weblog_uni_df = weblog_uni_df.withColumn('MAX_DAY_CNT_PAST_180D',
                                             F.greatest(*[col for col in related_university_columns]))
    # w = Window.orderBy('MAX_DAY_CNT_PAST_180D')
    weblog_uni_df = _multi_partition_percent_rank(
        weblog_uni_df, rank_col='MAX_DAY_CNT_PAST_180D'
    ).withColumnRenamed('percent_rank', Float.UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25)

    return weblog_uni_df.select("CUST_NUM", "SUBR_NUM",
                                Float.UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25)


def ratings_uni_domains_visit_days_cnt_percentile(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    weblog_path_date_no_hyphen = (run_date - timedelta(days=2)).strftime("%Y%m%d")
    n1_table = spark.read.parquet(f"{prepaid_postpaid_n1}")
    weblog_df = spark.read.parquet(f"{weblog_university_website_record}/date_id={weblog_path_date_no_hyphen}")
    n1_table = n1_table.select("CUST_NUM", "SUBR_NUM", "D_AGE")

    return _uni_domains_visit_days_cnt_percentile_feature(
        weblog_uni_df=weblog_df,
        n1_table=n1_table
    )


def _family_related_ratings(df) -> DataFrame:
    """
    Calculate
    Float.FAMILY_WITH_KIDS_AGE_0_2_RELATED_DOMAIN_CNT_180D
    Float.FAMILY_WITH_KIDS_AGE_2_6_RELATED_RED_FLAG_DOMAIN_CNT_180D
    Float.FAMILY_WITH_KIDS_AGE_6_12_RELATED_RED_FLAG_DOMAIN_CNT_180D
    Float.FAMILY_WITH_KIDS_AGE_12_PLUS_RELATED_RED_FLAG_DOMAIN_CNT_180D
    Float.FAMILY_WITH_KIDS_RELATED_DOMAIN_CNT_180D
    Float.FAMILY_WITH_KIDS_RELATED_RED_FLAG_DOMAIN_CNT_180D
    Float.FAMILY_WITH_DEPENDENT_ELDERLY_RELATED_DOMAIN_CNT_180D
    """

    kids_0_2_domain_cnt = "FAMILY_KIDS_0_2_DOMAIN_CNT_PAST_180D"
    kids_2_6_red_flag_domain_cnt = "FAMILY_KIDS_2_6_RED_FLAG_DOMAIN_CNT_PAST_180D"
    kids_6_12_red_flag_domain_cnt = "FAMILY_KIDS_6_12_RED_FLAG_DOMAIN_CNT_PAST_180D"
    kids_12_plus_red_flag_domain_cnt = "FAMILY_KIDS_12_PLUS_RED_FLAG_DOMAIN_CNT_PAST_180D"
    kids_general_domain_cnt = "FAMILY_GENERAL_DOMAIN_CNT_PAST_180D"
    kids_general_red_flag_domain_cnt = "FAMILY_GENERAL_RED_FLAG_DOMAIN_CNT_PAST_180D"
    elderly_domain_cnt = "FAMILY_ELDERLY_DOMAIN_CNT_PAST_180D"


    df = df.withColumn(
        Float.FAMILY_WITH_KIDS_AGE_0_2_RELATED_DOMAIN_CNT_180D,
        F.col(kids_0_2_domain_cnt)
    ).withColumn(
        Float.FAMILY_WITH_KIDS_AGE_2_6_RELATED_RED_FLAG_DOMAIN_CNT_180D,
        F.col(kids_2_6_red_flag_domain_cnt)
    ).withColumn(
        Float.FAMILY_WITH_KIDS_AGE_6_12_RELATED_RED_FLAG_DOMAIN_CNT_180D,
        F.col(kids_6_12_red_flag_domain_cnt)
    ).withColumn(
        Float.FAMILY_WITH_KIDS_AGE_12_PLUS_RELATED_RED_FLAG_DOMAIN_CNT_180D,
        F.col(kids_12_plus_red_flag_domain_cnt)
    ).withColumn(
        Float.FAMILY_WITH_KIDS_RELATED_DOMAIN_CNT_180D,
        F.col(kids_general_domain_cnt)
    ).withColumn(
        Float.FAMILY_WITH_KIDS_RELATED_RED_FLAG_DOMAIN_CNT_180D,
        F.col(kids_general_red_flag_domain_cnt)
    ).withColumn(
        Float.FAMILY_WITH_DEPENDENT_ELDERLY_RELATED_DOMAIN_CNT_180D,
        F.col(elderly_domain_cnt)
    )

    df = df.select(
        'CUST_NUM', 'SUBR_NUM',
        Float.FAMILY_WITH_KIDS_AGE_0_2_RELATED_DOMAIN_CNT_180D,
        Float.FAMILY_WITH_KIDS_AGE_2_6_RELATED_RED_FLAG_DOMAIN_CNT_180D,
        Float.FAMILY_WITH_KIDS_AGE_6_12_RELATED_RED_FLAG_DOMAIN_CNT_180D,
        Float.FAMILY_WITH_KIDS_AGE_12_PLUS_RELATED_RED_FLAG_DOMAIN_CNT_180D,

        Float.FAMILY_WITH_KIDS_RELATED_DOMAIN_CNT_180D,
        Float.FAMILY_WITH_KIDS_RELATED_RED_FLAG_DOMAIN_CNT_180D,

        Float.FAMILY_WITH_DEPENDENT_ELDERLY_RELATED_DOMAIN_CNT_180D,
    ).fillna(0)

    return df


def ratings_family_related_domain_count(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=2)).strftime("%Y%m%d")
    weblog_usage = spark.read.schema(family_website_schema).parquet(f'{weblog_family_website_record}/date_id={path_date}')
    return _family_related_ratings(weblog_usage)


def _northbound_driver_ratings(df) -> DataFrame:
    """
    Calculate
    Float.WEBLOG_TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D
    Float.WEBLOG_NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D
    Float.WEBLOG_MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D
    """

    td_domain_cnt = "TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D"
    hz_day_cnt = "NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D"
    cn_day_cnt = "MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D"


    df = df.withColumn(
        Float.WEBLOG_TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D,
        F.col(td_domain_cnt)
    ).withColumn(
        Float.WEBLOG_NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D,
        F.col(hz_day_cnt)
    ).withColumn(
        Float.WEBLOG_MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D,
        F.col(cn_day_cnt)
    )

    df = df.select(
        'CUST_NUM', 'SUBR_NUM',
        Float.WEBLOG_TRANSPORT_DEPARTMENT_DOMAIN_CNT_PAST_365D,
        Float.WEBLOG_NORTHBOUND_OFFICIAL_DAY_CNT_PAST_365D,
        Float.WEBLOG_MAINLAND_TRANSPORT_SYSTEM_DAY_CNT_PAST_365D,
    ).fillna(0)

    return df


def ratings_northbound_driver(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=2)).strftime("%Y%m%d")
    weblog_usage = spark.read.parquet(f'{weblog_northbound_driver_website}/date_id={path_date}')
    return _northbound_driver_ratings(weblog_usage)


def _driver_ratings(df) -> DataFrame:
    """
    Calculate
    Bool.WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN
    Bool.WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN
    Bool.WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN
    Bool.WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN
    Bool.WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN
    Bool.WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN
    Bool.WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN
    """

    caltex_day_cnt = "CALTEX_DAY_CNT_PAST_180D"
    esso_day_cnt = "ESSO_DAY_CNT_PAST_180D"
    hkemeter_day_cnt = "HKEMETERAPP_DAY_CNT_PAST_180D"
    etoll_day_cnt = "HKETOLL_DAY_CNT_PAST_180D"
    shell_day_cnt = "SHELL_DAY_CNT_PAST_180D"
    shellrecharge_day_cnt = "SHELLRECHARGE_DAY_CNT_PAST_180D"
    tesla_day_cnt = "TESLA_DAY_CNT_PAST_180D"

    medians = {
        'caltex': df.filter(F.col(caltex_day_cnt)>=1).approxQuantile(caltex_day_cnt, [0.5], 0.0)[0],
        'esso': df.filter(F.col(esso_day_cnt)>=1).approxQuantile(esso_day_cnt, [0.5], 0.0)[0],
        'hkemeter': df.filter(F.col(hkemeter_day_cnt)>=1).approxQuantile(hkemeter_day_cnt, [0.5], 0.0)[0],
        'etoll': df.filter(F.col(etoll_day_cnt)>=1).approxQuantile(etoll_day_cnt, [0.5], 0.0)[0],
        'shell': df.filter(F.col(shell_day_cnt)>=1).approxQuantile(shell_day_cnt, [0.5], 0.0)[0],
        'shellrecharge': df.filter(F.col(shellrecharge_day_cnt)>=1).approxQuantile(shellrecharge_day_cnt, [0.5], 0.0)[0],
        'tesla': df.filter(F.col(tesla_day_cnt)>=1).approxQuantile(tesla_day_cnt, [0.5], 0.0)[0]
    }

    df = df.withColumn(
        Bool.WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN,
        F.when(F.col(caltex_day_cnt) >= medians['caltex'], True)
    ).withColumn(
        Bool.WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN,
        F.when(F.col(esso_day_cnt) >= medians['esso'], True)
    ).withColumn(
        Bool.WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN,
        F.when(F.col(hkemeter_day_cnt) >= medians['hkemeter'], True)
    ).withColumn(
        Bool.WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN,
        F.when(F.col(etoll_day_cnt) >= medians['etoll'], True)
    ).withColumn(
        Bool.WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN,
        F.when(F.col(shell_day_cnt) >= medians['shell'], True)
    ).withColumn(
        Bool.WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN,
        F.when(F.col(shellrecharge_day_cnt) >= medians['shellrecharge'], True)
    ).withColumn(
        Bool.WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN,
        F.when(F.col(tesla_day_cnt) >= medians['tesla'], True)
    )

    df = df.select(
        'CUST_NUM', 'SUBR_NUM',
        Bool.WEBLOG_CALTEX_DAY_CNT_PAST_180D_GTE_MEDIAN,
        Bool.WEBLOG_ESSO_DAY_CNT_PAST_180D_GTE_MEDIAN,
        Bool.WEBLOG_HKEMETERAPP_DAY_CNT_PAST_180D_GTE_MEDIAN,
        Bool.WEBLOG_HKETOLL_DAY_CNT_PAST_180D_GTE_MEDIAN,
        Bool.WEBLOG_SHELL_DAY_CNT_PAST_180D_GTE_MEDIAN,
        Bool.WEBLOG_SHELLRECHARGE_DAY_CNT_PAST_180D_GTE_MEDIAN,
        Bool.WEBLOG_TESLA_DAY_CNT_PAST_180D_GTE_MEDIAN
    ).fillna(False)

    return df


def ratings_driver(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=2)).strftime("%Y%m%d")
    weblog_usage = spark.read.parquet(f'{weblog_driver_website}/date_id={path_date}')
    return _driver_ratings(weblog_usage)


def _gamer_ratings(df: DataFrame) -> DataFrame:
    df = df.withColumnRenamed(
        "CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D", Float.WEBLOG_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D
    ).withColumnRenamed(
        "CONSOLE_GAME_DAY_CNT_PAST_30D", Float.WEBLOG_CONSOLE_GAME_DAY_CNT_PAST_30D
    ).withColumnRenamed(
        "MISCELLANEOUS_GAME_DAY_CNT_PAST_30D", Float.WEBLOG_MISCELLANEOUS_GAME_DAY_CNT_PAST_30D
    ).withColumnRenamed(
        "NON_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D", Float.WEBLOG_NON_CASUAL_MOBILE_GAME_DAY_CNT_PAST_30D
    )
    return df


def ratings_gamer(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=2)).strftime("%Y%m%d")
    weblog_usage = spark.read.parquet(f'{weblog_games_website}/date_id={path_date}')
    return _gamer_ratings(weblog_usage)


def _house_mover_ratings(df) -> DataFrame:
    """
    Calculate
    Float.WEBLOG_HOUSE_MOVING_DAY_CNT_PAST_30D
    Float.WEBLOG_HOUSE_RENTAL_DAY_CNT_PAST_30D
    """

    house_moving = "HOUSE_MOVING_DAY_CNT_PAST_30D"
    house_rental = "HOUSE_RENTAL_DAY_CNT_PAST_30D"

    df = df.withColumn(
        Float.WEBLOG_HOUSE_MOVING_DAY_CNT_PAST_30D,
        F.col(house_moving)
    ).withColumn(
        Float.WEBLOG_HOUSE_RENTAL_DAY_CNT_PAST_30D,
        F.col(house_rental)
    )

    df = df.select(
        'CUST_NUM', 'SUBR_NUM',
        Float.WEBLOG_HOUSE_MOVING_DAY_CNT_PAST_30D,
        Float.WEBLOG_HOUSE_RENTAL_DAY_CNT_PAST_30D
    ).fillna(0)

    return df


def ratings_house_mover(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=2)).strftime("%Y%m%d")
    weblog_usage = spark.read.parquet(f'{weblog_house_moving_website}/date_id={path_date}')
    return _house_mover_ratings(weblog_usage)


def get_weblog_daily_ratio_wtih_latest_month(weblog_daily: DataFrame, 
                                             weblog_comparison_monthly: DataFrame, 
                                             how_many_days_in_weblog_monthly: int) -> DataFrame:
    gb_to_bytes = 1024*1024*1024

    keys = ["CUST_NUM", "SUBR_NUM"]
    _weblog_daily = weblog_daily.groupby(keys).agg(
        (F.sum("byte_count")/gb_to_bytes).alias("daily_sum_byte_count_gb")
    )
    
    _weblog_monthly = weblog_comparison_monthly.groupby(keys).agg(
        ((F.sum("byte_count"))/gb_to_bytes).alias(Float.WEBLOG_USAGE_PREVIOIS_MONTH_GB)
    )
    
    merged_weblog = _weblog_daily.join(_weblog_monthly, on=keys, how = "left")\
                                .withColumn(Float.WEBLOG_USAGE_DAILY_N_MONTHLY_AVG_RATIO, 
                                               F.col("daily_sum_byte_count_gb")/(F.col(Float.WEBLOG_USAGE_PREVIOIS_MONTH_GB)/how_many_days_in_weblog_monthly)
                                    )\
                                .fillna(0, subset=[Float.WEBLOG_USAGE_DAILY_N_MONTHLY_AVG_RATIO])
    
    return merged_weblog.select(*keys,
                                Float.WEBLOG_USAGE_DAILY_N_MONTHLY_AVG_RATIO,
                                Float.WEBLOG_USAGE_PREVIOIS_MONTH_GB)


def ratings_weblog_daily_usage(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    
    path_date = (run_date - timedelta(days=2)).strftime("%Y%m%d")
    n1_table = spark.read.parquet(prepaid_postpaid_n1)\
        .select(
            "CUST_NUM", "SUBR_NUM", "D_ACTIVE_SUBR_FLG"
        ).filter(
            "D_ACTIVE_SUBR_FLG = 'Y' and SUBR_NUM is not null and CUST_NUM is not null and SUBR_NUM != '' and CUST_NUM != ''"
        ).select(
            "CUST_NUM", "SUBR_NUM"
        ).distinct()
    weblog_daily = spark.read.parquet(f'{t_domain_daily_path}/date_id={path_date}')\
                    .withColumnRenamed("subr_num", "SUBR_NUM")
    month_str = None
    how_many_days_in_weblog_monthly = None
    weblog_monthly = None
    try:
        last_month = run_date - relativedelta(months=1)
        month_str = last_month.strftime("%Y%m")
        how_many_days_in_weblog_monthly = calendar.monthrange(last_month.year, last_month.month)[1]

        weblog_monthly = spark.read.parquet(f'{t_domain_monthly_path}/month_id={month_str}')\
                            .withColumnRenamed("subr_num", "SUBR_NUM")
    except:
        month_before_last = run_date - relativedelta(months=2)
        month_str = month_before_last.strftime("%Y%m")
        how_many_days_in_weblog_monthly = calendar.monthrange(month_before_last.year, month_before_last.month)[1]

        weblog_monthly = spark.read.parquet(f'{t_domain_monthly_path}/month_id={month_str}')\
                            .withColumnRenamed("subr_num", "SUBR_NUM")

    print("Reading Weblog Monthly:", month_str)

    
    weblog_daily = weblog_daily.join(n1_table, on=["SUBR_NUM"], how="inner")
    weblog_monthly = weblog_monthly.join(n1_table, on=["SUBR_NUM"], how="inner")

    return get_weblog_daily_ratio_wtih_latest_month(weblog_daily, weblog_monthly, how_many_days_in_weblog_monthly)