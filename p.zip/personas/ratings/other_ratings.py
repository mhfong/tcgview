import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StringType
from datetime import datetime
from dateutil.relativedelta import relativedelta
from ratings.feature_ratings import BooleanFeatureRatings as Bool
from ratings.feature_ratings import FloatFeatureRatings as Float
from paths import prepaid_postpaid_n1, cdp_data


def _cdp_mall_parker(df) -> DataFrame:
    """
    Calculate
    Bool.CDP_IS_SHKP_MALL_PARKER
    """

    is_parker = "BEHAVIORS_DRIVER_SHKP_PARKER"

    df = df.withColumn(
        Bool.CDP_IS_SHKP_MALL_PARKER,
        F.when(F.col(is_parker) == 1, True)
    ).select(
        'CUST_NUM', 'SUBR_NUM',
        Bool.CDP_IS_SHKP_MALL_PARKER,
    ).fillna(False)

    return df


def ratings_cdp_mall_parker(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    n1 = spark.read.parquet(prepaid_postpaid_n1).filter(
        "D_ACTIVE_SUBR_FLG = 'Y' and SUBR_NUM is not null and CUST_NUM is not null and SUBR_NUM != '' and CUST_NUM != ''"
        ).withColumn(
        'HASHMOBILENO', F.sha2(
            (F.floor(((F.col('subr_num') + 85200000000)*8 + 45678) / 2)).cast(StringType()), 256)
        ).select(
            'SUBR_NUM','CUST_NUM','HASHMOBILENO'
        )

    cdp = spark.read.option("mergeSchema", "true").csv(
            [f'{cdp_data}/cdp_'+(run_date - relativedelta(months=i+2)).strftime('%Y-%m-01')+'.csv'
                for i in range(6)], header=True          # read latest 6 complete months
        ).withColumnRenamed(
            'BEHAVIORS | DRIVER | SHKP PARKER', 'BEHAVIORS_DRIVER_SHKP_PARKER'
        ).join(
            n1, on=['HASHMOBILENO']
        ).groupBy('CUST_NUM','SUBR_NUM').agg(
            F.max('BEHAVIORS_DRIVER_SHKP_PARKER').alias('BEHAVIORS_DRIVER_SHKP_PARKER')
        )

    return _cdp_mall_parker(cdp)


def _handset_change_ratings(df: DataFrame) -> DataFrame:
        high_prob = ((F.col('LAST_DEVICE_USED_FOR') > 360) & (F.col('prob').getItem(1) >= F.lit(0.7)))
        
        df = df.filter(
            (F.col('USING_OLD') | high_prob)
        ).select(
            'SUBR_NUM', 'CUST_NUM',
            F.col('USING_OLD').alias(Bool.HANDSET_REUSE_OLD),
            high_prob.alias(Bool.HANDSET_CHANGE_HIGH_PROBABILITY),
        )
        return df


def ratings_handset_change(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    
    if run_date.day > 4:
        cutoff = run_date.replace(day=2)
        
    else:
        cutoff = run_date.replace(day=2) - relativedelta(months=1)
    
    df = spark.read.parquet(f'dtap://TenantStorage/handset/scored/CUTOFF={cutoff.date().isoformat()}')
    

    return _handset_change_ratings(df)