from pyspark.sql.window import Window
import pyspark.sql.functions as F
from pyspark.sql import DataFrame


def _rolling_sum_total_ratio(df: DataFrame, rolling_sum_col: str, total_col: str, result_col_name: str) -> DataFrame:
    """
    Rolling sum of rolling_sum_col / Total of rolling_sum_col of the entire dataframe.

    Same as sum(rolling_sum_col).over(Window.orderBy(rolling_sum_col))/total_col, (1 partition for entire table),
    which will force everything into 1 partition thus not very scalable.

    This uses partitions to try to balance the partition data count.

    :param df:
    :param rolling_sum_col:
    :param total_col: name of Total of rolling_sum_col
    :param result_col_name:
    :return:
    """

    window = Window.partitionBy('block').orderBy(rolling_sum_col, 'SUBR_NUM', 'CUST_NUM')

    df = df.filter(F.col(rolling_sum_col).isNotNull()).repartitionByRange(
        rolling_sum_col
    ).withColumn(
        'block', F.spark_partition_id()
    ).cache() # must cache to prevent multiple repartitionByRange, which will give slightly different results

    block_agg = df.groupBy('block').agg(
        F.sum(rolling_sum_col).alias('block_total')
    ).withColumn(
        'prev_blocks_totals',
        F.sum('block_total').over(
            Window.orderBy('block').rowsBetween(Window.unboundedPreceding, Window.currentRow - 1)
        )
    ).fillna(0)

    return df.join(F.broadcast(block_agg), on='block').withColumn(
        result_col_name, (F.sum(rolling_sum_col).over(window) + F.col('prev_blocks_totals')) / F.col(total_col)
    ).drop('block', 'prev_blocks_totals')


def _multi_partition_percent_rank(df: DataFrame, rank_col: str) -> DataFrame:
    """
    rank percentile of entire table
    Same as F.percent_rank().over(Window.orderBy(rank_col))) (1 partition)
    but uses multiple partitions, more scalable.

    :param df: 'SUBR_NUM', 'CUST_NUM', rank_col
    :param rank_col:
    :return:
    """
    uniq = df.groupby(rank_col).agg(
        F.count(rank_col).alias('f_count'),
        F.collect_list(F.struct('SUBR_NUM', 'CUST_NUM')).alias('user')
    ).repartitionByRange(
        rank_col
    ).withColumn(
        'block', F.spark_partition_id()
    ).cache()  # must cache to prevent multiple repartitionByRange, which will give slightly different results

    window = Window.partitionBy('block').orderBy(rank_col).rowsBetween(Window.unboundedPreceding, Window.currentRow - 1)

    ###############################
    block_agg = uniq.groupBy('block').agg(
        F.sum('f_count').alias('block_total')
    ).withColumn(
        'prev_blocks_totals',
        F.sum('block_total').over(
            Window.orderBy('block').rowsBetween(Window.unboundedPreceding, Window.currentRow - 1)
        )
    ).fillna(0)
    ###############################

    return uniq.withColumn(
        'block_count_less_than_current',
        F.sum('f_count').over(window)
    ).fillna(0).join(
        F.broadcast(block_agg), on='block'
    ).withColumn(
        'count_less_than_current', F.col('block_count_less_than_current') + F.col('prev_blocks_totals')
    ).withColumn(
        'percent_rank', F.col('count_less_than_current') / (df.count() - 1)
    ).select(
        F.explode('user').alias('user'), 'percent_rank'
    ).select(
        'user.SUBR_NUM', 'user.CUST_NUM', 'percent_rank'
    )