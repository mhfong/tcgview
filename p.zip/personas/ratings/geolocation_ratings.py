import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from datetime import datetime, timedelta
from ratings.feature_ratings import BooleanFeatureRatings as Bool
from ratings.agg_window_functions import _rolling_sum_total_ratio
from paths import geolocation_roaming_trip_count
from functools import reduce
from observability.side_output import SideOutputWriter


def _roaming_group_trip_count_features(df, side_output: SideOutputWriter) -> DataFrame:
    """
    Make
    ROAMING_TRIP_COUNT_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
    ROAMING_TRIP_COUNT_PRODUCT_AUS_NEWZ_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
    ROAMING_TRIP_COUNT_PRODUCT_EUROPE_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
    ROAMING_TRIP_COUNT_PRODUCT_US_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
    ROAMING_TRIP_COUNT_PRODUCT_OTHER_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
    ROAMING_TRIP_COUNT_PRODUCT_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
    ROAMING_TRIP_COUNT_PRODUCT_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
    Calculate BooleanFeatureRatings.ROAMING_TRIP_COUNT_* ratings

    e.g. ROAMING_TRIP_COUNT_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
    X = roaming_china_trip_counts in 180 days for subscribers
    rolling sum midpoint = rolling sum( sorted ascending( X ) ) / total (X) closest to 0.5
    i.e. subscriber with X < rolling sum midpoint contributes around half of the total trip counts
    compared to subscriber with X >= rolling sum midpoint.
    i.e. the latter group contributes more per person to the total of X, i.e. they travel more compared to the former group

    ROAMING_TRIP_COUNT_CHINA_180D_IS_ROLLING_SUM_MID_POINT_PLUS_1 == true are subscribers with X == rolling sum midpoint + 1
    :param df:
    :return:

    """
    groups = [
        # roaming col, feature
        ('ROAMING_TRAVEL_COUNTRY_GROUP_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        ('ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_AUS_NEWZ_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_PRODUCT_AUS_NEWZ_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        ('ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_EUROPE_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_PRODUCT_EUROPE_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        ('ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_US_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_PRODUCT_US_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        ('ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_OTHER_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_PRODUCT_OTHER_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        ('ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_APAC_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_PRODUCT_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        ('ROAMING_TRAVEL_COUNTRY_GROUP_PRODUCT_NON_APAC_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_PRODUCT_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
    ]
    countries = [
        ('ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1),
        ('ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_MACAU_TRIP_COUNT_180D',
         Bool.ROAMING_TRIP_COUNT_MACAU_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1)
    ]
    countries = [
        (r[0].replace('ROAMING_TRAVEL_COUNTRY_CAT_LV1_', '').replace('_TRIP_COUNT_180D', ''), r[0], r[1]) for r in countries
    ]
    regions = [
        (r[0].replace('ROAMING_TRAVEL_COUNTRY_CAT_LV1_', '').replace('_TRIP_COUNT_180D', ''), r[0], r[1]) for r in groups
    ] + countries

    totals = df.agg(
        *[F.sum(col).alias(region + '_TOTAL') for region, col, _ in regions]
    ).limit(1)

    df = df.crossJoin(
        F.broadcast(totals)
    ).cache()

    thresholds = [
        _rolling_sum_total_ratio(
            df,
            rolling_sum_col=col,
            total_col=region+'_TOTAL',
            result_col_name='ROLLING_SUM_TOTAL_RATIO_'+region
        ).groupBy(F.spark_partition_id()).agg(
            F.min(
                F.when(F.col('ROLLING_SUM_TOTAL_RATIO_'+region) >= F.lit(0.5), F.col(col)).otherwise(None)
            ).alias(region+'_TRIP_COUNT_MID_POINT')
        ).select(
            F.min(region + '_TRIP_COUNT_MID_POINT').alias(region + '_TRIP_COUNT_MID_POINT')
        ).limit(1)
        for region, col, _ in regions
    ]
    thresholds = reduce(lambda a, b: a.crossJoin(b), thresholds)
    side_output.write(thresholds, key_prefix=_roaming_group_trip_count_features.__name__)

    df = df.crossJoin(
        F.broadcast(thresholds)
    )

    features = [
        (feature,
         F.col(col) >= F.col(region + '_TRIP_COUNT_MID_POINT') + 1)

        for region, col, feature in regions
    ]

    return df.select(
        'CUST_NUM', 'SUBR_NUM',
        *[
            F.when(condition, True).otherwise(False).alias(feature)
            for feature, condition in features
        ]
    ).fillna(False)


def _roaming_trip_avg_duration(df, side_output: SideOutputWriter):
    """
    Calculate ROAMING_TRIP_AVG_DURATION_* ratings

    Same as _roaming_trip_count_features, but using Trip duration 180D average
    """

    df = df.filter(  # remove suspected emigrated users
        """
        ROAMING_TRAVEL_COUNTRY_CAT_LV1_UNITED_KINGDOM_TRIP_DAYS_COUNT_180D < 30 and
        ROAMING_TRAVEL_COUNTRY_CAT_LV1_TAIWAN_TRIP_DAYS_COUNT_180D < 30 and
        ROAMING_TRAVEL_COUNTRY_CAT_LV1_CANADA_TRIP_DAYS_COUNT_180D < 30 and
        ROAMING_TRAVEL_COUNTRY_CAT_LV1_OCEANIA_TRIP_DAYS_COUNT_180D < 30 
        """
    )
    regions = [  # region name, source data column, feature column
        ('CHINA', 'ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_TRIP_DURATION_AVG_DAYS_180D',
         Bool.ROAMING_TRIP_AVG_DURATION_CHINA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
         ),
        ('JAPAN', 'ROAMING_TRAVEL_COUNTRY_CAT_LV1_JAPAN_TRIP_DURATION_AVG_DAYS_180D',
         Bool.ROAMING_TRIP_AVG_DURATION_JAPAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
         ),
        ('TAIWAN', 'ROAMING_TRAVEL_COUNTRY_CAT_LV1_TAIWAN_TRIP_DURATION_AVG_DAYS_180D',
         Bool.ROAMING_TRIP_AVG_DURATION_TAIWAN_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
         ),
        ('KOREA', 'ROAMING_TRAVEL_COUNTRY_CAT_LV1_SOUTH_KOREA_TRIP_DURATION_AVG_DAYS_180D',
         Bool.ROAMING_TRIP_AVG_DURATION_KOREA_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
         ),
        ('APAC', 'ROAMING_TRAVEL_COUNTRY_GROUP_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_TRIP_DURATION_AVG_DAYS_180D',
         Bool.ROAMING_TRIP_AVG_DURATION_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
         ),
        ('NON_APAC', 'ROAMING_TRAVEL_COUNTRY_GROUP_NON_APAC_TRIP_DURATION_AVG_DAYS_180D',
         Bool.ROAMING_TRIP_AVG_DURATION_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1
         )
    ]

    totals = df.groupBy(F.spark_partition_id()).agg(
        *[F.sum(col).alias(region + '_TOTAL') for region, col, _ in regions]
    ).select(
        *[F.sum(region + '_TOTAL').alias(region + '_TOTAL') for region, _, _ in regions]
    ).limit(1)

    df = df.crossJoin(
        F.broadcast(totals)
    ).cache()

    thresholds = [
        _rolling_sum_total_ratio(
            df,
            rolling_sum_col=col,
            total_col=region + '_TOTAL',
            result_col_name='ROLLING_SUM_TOTAL_RATIO_' + region
        ).groupBy(F.spark_partition_id()).agg(
            F.min(
                F.when(F.col('ROLLING_SUM_TOTAL_RATIO_' + region) >= F.lit(0.5), F.col(col)).otherwise(None)
            ).alias(region + '_TRIP_DURATION_AVG_MID_POINT')
        ).select(
            F.min(
                F.col(region + '_TRIP_DURATION_AVG_MID_POINT')
            ).alias(region + '_TRIP_DURATION_AVG_MID_POINT')
        ).limit(1)
        for region, col, _ in regions
    ]
    thresholds = reduce(lambda a, b: a.crossJoin(b), thresholds)
    side_output.write(thresholds, key_prefix=_roaming_trip_avg_duration.__name__)

    df = df.crossJoin(
        F.broadcast(thresholds)
    )

    return df.select(
        'CUST_NUM', 'SUBR_NUM',
        *[
            F.when(
                (F.col(col) >= F.col(region + '_TRIP_DURATION_AVG_MID_POINT') + F.lit(1.0)), True
            ).otherwise(False).alias(feature)
            for region, col, feature in regions
        ]
    ).fillna(False)


def _roaming_trip_count_ratios(df, side_output: SideOutputWriter):
    """
    Calculate ROAMING_TRIP_COUNT_RATIO_* ratings

    Same as _roaming_trip_count_features, but using Trip duration 180D average
    """
    df = df.filter(  # remove suspected emigrated users
        """
        ROAMING_TRAVEL_COUNTRY_CAT_LV1_UNITED_KINGDOM_TRIP_DAYS_COUNT_180D < 30 and
        ROAMING_TRAVEL_COUNTRY_CAT_LV1_TAIWAN_TRIP_DAYS_COUNT_180D < 30 and
        ROAMING_TRAVEL_COUNTRY_CAT_LV1_CANADA_TRIP_DAYS_COUNT_180D < 30 and
        ROAMING_TRAVEL_COUNTRY_CAT_LV1_OCEANIA_TRIP_DAYS_COUNT_180D < 30 
        """
    )
    ratio_col = 'NON_APAC_TRIP_COUNT_RATIO'
    ration_col_1_99 = ratio_col + '_1_99'
    df = df.select(
        'CUST_NUM', 'SUBR_NUM',
        F.floor((F.col('ROAMING_TRAVEL_COUNTRY_GROUP_NON_APAC_TRIP_COUNT_180D') * 100) / (
                F.col('ROAMING_TRAVEL_COUNTRY_GROUP_NON_APAC_TRIP_COUNT_180D') +
                F.col('ROAMING_TRAVEL_COUNTRY_GROUP_APAC_EXCLUDE_CHINA_AUSTRALIA_NEW_ZEALAND_TRIP_COUNT_180D') +
                F.col('ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_TRIP_COUNT_180D') +
                F.col('ROAMING_TRAVEL_COUNTRY_CAT_LV1_CHINA_MACAU_TRIP_COUNT_180D')
        )).alias(ratio_col)
    ).withColumn(  # use 1% to 99% values to calculate threshold due to high number of people with ration = 100%
        ration_col_1_99,
        F.when((F.col(ratio_col) > 0) & (F.col(ratio_col) < 100), F.col(ratio_col)).otherwise(None)
    )

    totals = df.groupBy(F.spark_partition_id()).agg(
        F.sum(ration_col_1_99).alias(ration_col_1_99)
    ).select(
        F.sum(ration_col_1_99).alias(ratio_col + '_1_99_TOTAL')
    ).limit(1)

    df = df.crossJoin(
        F.broadcast(totals)
    )

    threshold = _rolling_sum_total_ratio(
        df,
        rolling_sum_col=ration_col_1_99,
        total_col=ratio_col + '_1_99_TOTAL',
        result_col_name='ROLLING_SUM_TOTAL_RATIO'
    ).groupBy(F.spark_partition_id()).agg(
        F.min(
            F.when(F.col('ROLLING_SUM_TOTAL_RATIO') >= F.lit(0.5), F.col(ration_col_1_99)).otherwise(None)
        ).alias('MID_POINT')
    ).select(
        F.min(F.col('MID_POINT')).alias('MID_POINT')
    ).limit(1)

    side_output.write(threshold, key_prefix=_roaming_trip_count_ratios.__name__)

    return df.crossJoin(
        F.broadcast(threshold)
    ).select(
        'CUST_NUM', 'SUBR_NUM',
        F.when(
            (
            (F.col(ration_col_1_99) >= F.col('MID_POINT') + 1) |
            (F.col(ratio_col) >= 100)
            ),
            True
        ).otherwise(False).alias(
            Bool.ROAMING_TRIP_COUNT_RATIO_NON_APAC_180D_GTE_ROLLING_SUM_MID_POINT_PLUS_1_OR_IS_100
        )
    ).fillna(False)


def _read_roaming_trips(spark, run_date):
    path_date = (run_date - timedelta(days=2)).strftime("%Y-%m-%d")
    return spark.read.parquet(f'{geolocation_roaming_trip_count}/date_id={path_date}')


def ratings_roaming_trip_count(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    roaming_trip_counts = _read_roaming_trips(spark, run_date).cache()
    side_output = SideOutputWriter(run_date, version)
    return _roaming_group_trip_count_features(roaming_trip_counts, side_output)


def ratings_roaming_trip_count_ratios(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    roaming_trip_counts = _read_roaming_trips(spark, run_date)
    side_output = SideOutputWriter(run_date, version)
    return _roaming_trip_count_ratios(roaming_trip_counts, side_output)


def ratings_roaming_average_trip_duration(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    df = _read_roaming_trips(spark, run_date)
    side_output = SideOutputWriter(run_date, version)
    return _roaming_trip_avg_duration(df, side_output)
