from datetime import datetime, timedelta

from pyspark.sql import DataFrame, SparkSession, functions as F
from pyspark.sql.utils import AnalysisException
import logging
from paths import prepaid_postpaid_n1, census_stat_by_address_estate_name
from ratings.feature_ratings import FloatFeatureRatings as Float
from ratings.feature_ratings import BooleanFeatureRatings as Bool


def ratings_subscriber_age(spark: SparkSession, run_date: datetime, version) -> DataFrame:

    n1_table = spark.read.parquet(prepaid_postpaid_n1)
    n1_table = n1_table.select(
        "CUST_NUM", "SUBR_NUM", "D_AGE", "D_ACTIVE_SUBR_FLG"
    ).filter(
        "D_ACTIVE_SUBR_FLG = 'Y' and SUBR_NUM is not null and CUST_NUM is not null and SUBR_NUM != '' and CUST_NUM != ''"
    ).withColumnRenamed("D_AGE", Float.AGE)
    
    return n1_table.select("CUST_NUM", "SUBR_NUM", Float.AGE)


def ratings_subscriber_income(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    """
    Median income from residential address from census data
    """
    try:
        last_month = run_date - timedelta(days=run_date.day)
        _path = census_stat_by_address_estate_name + '/MONTH_ID=' + last_month.strftime('%Y%m')
        df = spark.read.parquet(_path)
        logging.info('Read ' + _path)

    except AnalysisException:  # dont know when the data will be ready
        last_month = run_date - timedelta(days=run_date.day)
        last_last_month = last_month - timedelta(days=last_month.day)
        _path = census_stat_by_address_estate_name + '/MONTH_ID=' + last_last_month.strftime('%Y%m')
        df = spark.read.parquet(_path)
        logging.info('Read ' + _path)

    return df.filter('MEDIAN_MONTHLY_HOUSEHOLD_INCOME_OF_ECONOMICALLY_ACTIVE_HOUSEHOLDS is not null').select(
        "CUST_NUM", "SUBR_NUM", F.col('MEDIAN_MONTHLY_HOUSEHOLD_INCOME_OF_ECONOMICALLY_ACTIVE_HOUSEHOLDS').alias(
            Float.CENSUS_MONTHLY_MEDIAN_INCOME_BY_RESIDENTIAL_ADDRESS_ESTATE_NAME
        )
    )


def add_is_hbb(sdf: DataFrame):
    return sdf.withColumn(Bool.IS_HBB, F.when(
            (F.col('SUBR_NUM').startswith('19943')) |
            (F.col('SUBR_NUM').startswith('19944')) |
            (F.col('SUBR_NUM').startswith('19945')) |
            (F.col('SUBR_NUM').startswith('19946')), True).otherwise(False)
        )


def ratings_subscriber_is_hbb(spark: SparkSession, run_date: datetime, version) -> DataFrame:

    n1_table = spark.read.parquet(prepaid_postpaid_n1)
    n1_table = n1_table.select(
        "CUST_NUM", "SUBR_NUM"
    ).distinct()\
    .filter(
        "SUBR_NUM is not null and CUST_NUM is not null and SUBR_NUM != '' and CUST_NUM != ''"
    )
    n1_table = add_is_hbb(n1_table)
    
    return n1_table.select("CUST_NUM", "SUBR_NUM", Bool.IS_HBB)