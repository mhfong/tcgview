import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import IntegerType
from datetime import datetime, timedelta
from ratings.feature_ratings import BooleanFeatureRatings as Bool
from ratings.feature_ratings import FloatFeatureRatings as Float
from pyspark.sql.window import Window
from paths import (
                   geolocation_stop_near_university,
                   geolocation_count_of_district_record,
                   geolocation_round_trip_record,
                   geolocation_full_day_stay_in_one_district_record,
                   geolocation_mtr_record,
                   geolocation_feature
                   )
from dateutil.relativedelta import relativedelta

def _uni_geo_footprint_feature(geo_uni_df: DataFrame) -> DataFrame:
    """
    Return university student list by using geolocation record.
    :param geo_uni_df:
    :return:
    """

    geo_uni_df = geo_uni_df.select("cust_num", "subr_num").distinct()

    geo_uni_df = geo_uni_df.withColumn(Bool.UNI_GEOLOCATION_AT_LEAST_3_DAYS_30D_ANY_6M,
                                       F.lit(True))

    return geo_uni_df.select(F.col("cust_num").alias("CUST_NUM"), F.col("subr_num").alias("SUBR_NUM"),
                             Bool.UNI_GEOLOCATION_AT_LEAST_3_DAYS_30D_ANY_6M)


def ratings_uni_geo_footprint(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    path_date = (run_date - timedelta(days=2)).strftime("%Y-%m-%d")
    geo_df = spark.read.parquet(f"{geolocation_stop_near_university}/date_id={path_date}")

    return _uni_geo_footprint_feature(geo_uni_df=geo_df)


def _max_day_count_in_the_same_district_feature(district_days_count_count: DataFrame):
    key_col = ["cust_num", "subr_num"]

    sdf = district_days_count_count.groupBy([*key_col, "district"]) \
        .agg(F.count("date_id").alias(f"days_count_in_the_same_district")) \
        .groupBy(key_col) \
        .agg(F.max("days_count_in_the_same_district").alias("max_day_count_by_district_when_stay_in_same_district"))

    key_col_upper = [item.upper() for item in key_col]

    return sdf.select([F.col(col).alias(col.upper()) for col in sdf.columns]) \
        .select(*key_col_upper, Float.MAX_DAY_COUNT_BY_DISTRICT_WHEN_STAY_IN_SAME_DISTRICT)


def rating_max_day_count_in_the_same_district(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    """
    Create maximumn day count the subscribers stay at the same district.
    This feature/ ratings for static location in district

    Args:
        spark (SparkSession): _description_
        run_date (datetime): _description_

    Returns:
        DataFrame: _description_
    """
    num_of_days = 30
    dates = [(run_date - timedelta(days=i + 2)).strftime('%Y-%m-%d')
             for i in range(num_of_days)]
    geo_full_day_district = spark.read.parquet(
        *[f"{geolocation_full_day_stay_in_one_district_record}/date_id={date}" for date in dates])

    return _max_day_count_in_the_same_district_feature(district_days_count_count=geo_full_day_district)


def _max_round_trip_day_count_feature(round_trip_record: DataFrame):
    key_col = ["cust_num", "subr_num"]

    sdf = round_trip_record.filter(F.col("max_grouping") <= 4) \
        .select("date_id", *key_col, "mid_point_district", "end_point_district") \
        .drop_duplicates(subset=["date_id", *key_col, "mid_point_district", "end_point_district"]) \
        .withColumn("i_th_day_round_trip",
                    F.dense_rank().over(
                        Window.partitionBy([*key_col, "mid_point_district", "end_point_district"]).orderBy("date_id")
                    )
                    ) \
        .groupBy(key_col) \
        .agg(F.max("i_th_day_round_trip").alias("max_day_count_by_trip_when_round_trip"))
    key_col_upper = [item.upper() for item in key_col]

    return sdf.select([F.col(col).alias(col.upper()) for col in sdf.columns]) \
        .select(*key_col_upper, Float.MAX_DAY_COUNT_BY_TRIP_WHEN_ROUND_TRIP)


def rating_max_round_trip_day_count(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    """
    Create maximumn round trip day count for Mobility (fixed location).
    Fixed location visited in district level but no staying at one district (e.g. Office worker)

    Args:
        spark (SparkSession): _description_
        run_date (datetime): _description_

    Returns:
        DataFrame: _description_
    """

    num_of_days = 30
    dates = [(run_date - timedelta(days=i + 2)).strftime('%Y-%m-%d')
             for i in range(num_of_days)]
    round_trip_record = spark.read.parquet(
        *[f"{geolocation_round_trip_record}/date_id={date}" for date in dates])

    return _max_round_trip_day_count_feature(round_trip_record=round_trip_record)


def _mid_point_district_distribution_entropy_feature(round_trip_record: DataFrame):
    key_col = ["cust_num", "subr_num"]

    sdf = round_trip_record.select("date_id", *key_col, "mid_point_district") \
        .drop_duplicates(["date_id", *key_col, "mid_point_district"]) \
        .groupBy([*key_col, "mid_point_district"]) \
        .agg(F.count("mid_point_district").alias(f"day_count_mid_point_district")) \
        .withColumn(f"sum_mid_point_district",
                    F.sum(f"day_count_mid_point_district").over(
                        Window.partitionBy(key_col).orderBy(key_col).rowsBetween(Window.unboundedPreceding,
                                                                                 Window.unboundedFollowing))) \
        .withColumn("probability",
                    F.col("day_count_mid_point_district") / F.col("sum_mid_point_district")) \
        .groupBy(key_col) \
        .agg(
        F.sum(-1 * F.col("probability") * F.log2(F.col("probability"))).alias("round_trip_mid_point_entropy")
    ) \
        .withColumn("round_trip_mid_point_entropy", F.round("round_trip_mid_point_entropy", scale=5))

    key_col_upper = [item.upper() for item in key_col]

    return sdf.select([F.col(col).alias(col.upper()) for col in sdf.columns]) \
        .select(*key_col_upper, Float.ROUND_TRIP_MID_POINT_ENTROPY)


def rating_mid_point_district_distribution_entropy(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    """
    Extract mid-point districts (if round trip pattern happens) for one person in 30 days
    For example, in one day, A district -> B district -> A district happens and extract B district.
    In 30 days, it may contain 22 times round trip pattern.

    Create a table:
    | cust_num | subr_num | mid_point_district | day_count_mid_point_district |
    | 99999999 | 00000002 | Sha Tin District| 2 |
    | 99999999 | 00000002 | Tuen Mun District| 20 |

    Taking entropy function on {2,20} ->
    | cust_num | subr_num | entropy |
    | 99999999 | 00000002 | 0.2762 |

    # See what entropy is https://apgitscpl01/ds_datascience_grp/ds_internal/wikis/CDP/feature_docs/geolocation_mobility#appendix
    :param spark: SparkSession
    :param run_date: run_date
    :return:
    """

    num_of_days = 30
    dates = [(run_date - timedelta(days=i + 2)).strftime('%Y-%m-%d')
             for i in range(num_of_days)]
    round_trip_record = spark.read.parquet(
        *[f"{geolocation_round_trip_record}/date_id={date}" for date in dates])

    return _mid_point_district_distribution_entropy_feature(round_trip_record=round_trip_record)


def _many_districts_visited_day_count_feature(stat_district_count: DataFrame, district_count_threshold: int):
    key_col = ["cust_num", "subr_num"]

    sdf = stat_district_count.withColumn("is_gt_than_thres",
                                         F.when(F.col(f"count_district") >= district_count_threshold,
                                                F.lit(1)
                                                )
                                         .otherwise(F.lit(0))
                                         ) \
        .groupBy(key_col) \
        .agg(F.sum("is_gt_than_thres").alias("day_count_when_travel_4_plus_districts"))

    key_col_upper = [item.upper() for item in key_col]

    return sdf.select([F.col(col).alias(col.upper()) for col in sdf.columns]) \
        .select(*key_col_upper, Float.DAY_COUNT_WHEN_TRAVEL_4_PLUS_DISTRICTS)


def rating_many_districts_visited_day_count(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    """
    Set a number to define "many" districts
    By count_of_districts_threshold variables, if the subscribers visited equal or more than the threshold, it count one day.
    Rolling 30 days and create a statistic to show how many days the subscribers exceed the threshold.
    For geolocation mobility (Many districts visited Tag)

    :param spark: SparkSession
    :param run_date: run_date
    :return DataFrame:
    """
    num_of_days = 30
    count_of_districts_threshold_daily = 4
    dates = [(run_date - timedelta(days=i + 2)).strftime('%Y-%m-%d')
             for i in range(num_of_days)]
    district_count = spark.read.parquet(
        *[f"{geolocation_count_of_district_record}/date_id={date}" for date in dates])

    return _many_districts_visited_day_count_feature(stat_district_count=district_count,
                                                     district_count_threshold=count_of_districts_threshold_daily)

def _get_mtr_day_count_by_duration(mtr_records: DataFrame):
    """Main function to calculate how many days for one subr_num and cust_num travel by MTR in range of duration.
        Generate Noraml use MTR and Heavy use MTR day count. 
        definition is controlled by heavy_use_duration_range and normal_use_duration_range

    Args:
        mtr_records (DataFrame): A MTR records generated in geolocation. (Filtered null value in cut_num and subr_num out)
    """
    key_col = ["CUST_NUM", "SUBR_NUM"]
    normal_use_duration_lower_bound = 30*60 # 1800 to infinity seconds for the noraml use definition (include heavy user. filter heavy user in tag)
    heavy_use_duration_lower_bound = 60*60 # starting from 3600 seconds, it is counted as heavy use MTR
    sdf = mtr_records.groupBy(*key_col,"date_id")\
                                .agg(F.sum("total_journey_duration").alias("total_journey_duration"))
    
    return sdf.groupBy(*key_col).agg(
        F.sum(F.when( 
                (F.col("total_journey_duration")>=normal_use_duration_lower_bound), 1).otherwise(0)).alias(Float.DAY_COUNT_MTR_NORMAL_USAGE_30D),
        F.sum(F.when( 
                (F.col("total_journey_duration")>=heavy_use_duration_lower_bound), 1).otherwise(0)).alias(Float.DAY_COUNT_MTR_HEAVY_USAGE_30D),
        )\
        .select(*key_col, Float.DAY_COUNT_MTR_NORMAL_USAGE_30D, Float.DAY_COUNT_MTR_HEAVY_USAGE_30D)

def rating_geolocation_mtr_normal_n_heavy_day_count(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    """It is to create the day count statistics for the mtr station day count ( Noraml and Heavy use case )

    Args:
        spark (SparkSession): SparkSession
        run_date (datetime): _description_
        version (_type_): _description_
    """
    num_of_days = 30
    dates = [(run_date - timedelta(days=i + 2)).strftime('%Y-%m-%d')
             for i in range(num_of_days)]
    mtr_records = spark.read.parquet(geolocation_mtr_record).filter(F.col("date_id").isin(dates))
    # In this dataframe, cust_num and subr_num may be null value.
    mtr_records = mtr_records.filter((F.col("CUST_NUM").isNotNull()) & (F.col("SUBR_NUM").isNotNull()))

    return _get_mtr_day_count_by_duration(mtr_records=mtr_records)

def _get_golden_mtr_stations_visited_day_count(mtr_records: DataFrame):

    """
    -Station (Planned or Completed date/timeline)-
        Tin Hau Station (18 Jun 2024)
        Wan Chai Station (Target by Aug 2024)
        Kowloon Station (Target by Oct 2024)
        Admiralty Station (Target by Dec 2024)
        Causeway Bay (Target by Feb 2025)
        Hong Kong Station (Target by Q1 2025)
        Yau Ma Tei Station (Target by Q2 2025)
        Prince Edward Station (Target by Q2 2025)
        Central Station (Target by Q3 2025)
        Tsim Sha Tsui Station (Target by Q3 2025)
        North Point Station (Target by Q4 2025)
        Quarry Bay Station (Target by Q4 2025)
        Yau Tong Station (Target by Q1 2026)
        Cheung Sha Wan Station (Target by Q1 2026)
        Lai Chi Kwok Station (Target by Q1 2026)
        Mei Foo Station – Kwun Tong Ling (Target by Q2 2026)
        Lai King Station (Target by Q2 2026)
        Tsing Yi Station (Target by Q3 2026)
        Kowloon Tong Station (Target by Q3 2026)
        Lok Fu Station (Target by Q4 2026)
        Wong Tai Sin Station (Target by Q4 2026)
        Diamond Hill Station (Target by Q1 2027)
        Lam Tin Station (Target by Q1 2027)
        Tiu Keng Leng Station (Target by Apr 2027)
    """
    key_col = ["CUST_NUM", "SUBR_NUM"]
    golden_mtr_stations_full = ["Tin Hau",
                                "Wan Chai",
                                "Kowloon",
                                "Admiralty",
                                "Causeway Bay",
                                "Hong Kong",
                                "Yau Ma Tei",
                                "Prince Edward",
                                "Central",
                                "Tsim Sha Tsui",
                                "North Point",
                                "Quarry Bay",
                                "Yau Tong",
                                "Cheung Sha Wan",
                                "Lai Chi Kwok",
                                "Mei Foo",
                                "Lai King",
                                "Tsing Yi",
                                "Kowloon Tong",
                                "Lok Fu",
                                "Wong Tai Sin",
                                "Diamond Hill",
                                "Lam Tin",
                                "Tiu Keng Leng"]

    golden_mtr_stations_2024 = ["Tin Hau",
                                "Wan Chai",
                                "Kowloon",
                                "Admiralty",
                                "Causeway Bay",
                                "Hong Kong"]

    golden_mtr_stations_2025 = ["Tin Hau",
                                "Wan Chai",
                                "Kowloon",
                                "Admiralty",
                                "Causeway Bay",
                                "Hong Kong",
                                "Yau Ma Tei",
                                "Prince Edward",
                                "Central",
                                "Tsim Sha Tsui",
                                "North Point",
                                "Quarry Bay"]
    
    times_visited_golden_mtr_1D_full = 6 # inclusive
    times_visited_golden_mtr_1D_2024 = 2 # inclusive
    times_visited_golden_mtr_1D_2025 = 4 # inclusive

    mtr_records_with_golden_mtr = mtr_records.withColumn("golden_mtr_stations_full", 
                                                         F.array(*map(F.lit, golden_mtr_stations_full)))\
                                            .withColumn("golden_mtr_stations_2024", 
                                                        F.array(*map(F.lit, golden_mtr_stations_2024)))\
                                            .withColumn("golden_mtr_stations_2025", 
                                                        F.array(*map(F.lit, golden_mtr_stations_2025)))\
                                            .withColumn("golden_mtr_stations_visited_full", 
                                                        F.array_intersect(F.col("stations_list"), F.col("golden_mtr_stations_full"))
                                                        )\
                                            .withColumn("golden_mtr_stations_visited_2024", 
                                                        F.array_intersect(F.col("stations_list"), F.col("golden_mtr_stations_2024"))
                                                        )\
                                            .withColumn("golden_mtr_stations_visited_2025", 
                                                        F.array_intersect(F.col("stations_list"), F.col("golden_mtr_stations_2025"))
                                                        )\
                                            .withColumn("size_golden_mtr_stations_full", 
                                                        F.size("golden_mtr_stations_visited_full"))\
                                            .withColumn("size_golden_mtr_stations_2024", 
                                                        F.size("golden_mtr_stations_visited_2024"))\
                                            .withColumn("size_golden_mtr_stations_2025", 
                                                        F.size("golden_mtr_stations_visited_2025"))\
                                            .drop("golden_mtr_stations_full")\
                                            .drop("golden_mtr_stations_2024")\
                                            .drop("golden_mtr_stations_2025")
    
    return mtr_records_with_golden_mtr.groupBy("date_id", *key_col)\
                                        .agg(F.sum("size_golden_mtr_stations_full").alias("size_visited_golden_mtr_stations_full_1D"),
                                             F.sum("size_golden_mtr_stations_2024").alias("size_visited_golden_mtr_stations_2024_1D"),
                                             F.sum("size_golden_mtr_stations_2025").alias("size_visited_golden_mtr_stations_2025_1D"),
                                             )\
                                        .withColumn("is_eq_or_larger_threshold_full_1D", 
                                                    (F.col("size_visited_golden_mtr_stations_full_1D")>=times_visited_golden_mtr_1D_full)\
                                                        .cast(IntegerType()))\
                                        .withColumn("is_eq_or_larger_threshold_2024_1D",
                                                    (F.col("size_visited_golden_mtr_stations_2024_1D")>=times_visited_golden_mtr_1D_2024)\
                                                        .cast(IntegerType()))\
                                        .withColumn("is_eq_or_larger_threshold_2025_1D",
                                                    (F.col("size_visited_golden_mtr_stations_2025_1D")>=times_visited_golden_mtr_1D_2025)\
                                                        .cast(IntegerType()))\
                                        .groupBy(*key_col)\
                                        .agg(F.sum("is_eq_or_larger_threshold_full_1D").alias(Float.DAY_COUNT_VISITED_GOLDEN_MTR_FULL_30D),
                                             F.sum("is_eq_or_larger_threshold_2024_1D").alias(Float.DAY_COUNT_VISITED_GOLDEN_MTR_2024_30D),
                                             F.sum("is_eq_or_larger_threshold_2025_1D").alias(Float.DAY_COUNT_VISITED_GOLDEN_MTR_2025_30D),
                                             )\
                                        .select(*key_col,
                                                Float.DAY_COUNT_VISITED_GOLDEN_MTR_FULL_30D,
                                                Float.DAY_COUNT_VISITED_GOLDEN_MTR_2024_30D,
                                                Float.DAY_COUNT_VISITED_GOLDEN_MTR_2025_30D)
                                    
                                        
def rating_geolocation_mtr_golden_stations(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    """It is to create the day count statistics for the "golden" mtr station day count
    Args:
        spark (SparkSession): SparkSession
        run_date (datetime): _description_
        version (_type_): _description_
    """
    num_of_days = 30
    dates = [(run_date - timedelta(days=i + 2)).strftime('%Y-%m-%d')
             for i in range(num_of_days)]
    mtr_records = spark.read.parquet(geolocation_mtr_record).filter(F.col("date_id").isin(dates))
    # In this dataframe, cust_num and subr_num may be null value.
    mtr_records = mtr_records.filter((F.col("CUST_NUM").isNotNull()) & (F.col("SUBR_NUM").isNotNull()))

    return _get_golden_mtr_stations_visited_day_count(mtr_records=mtr_records)

def _get_disney_stop_stay_disney_last_12m(geolocation_disney_monthly: DataFrame):

    keys = ["CUST_NUM","SUBR_NUM"]
    sdf = geolocation_disney_monthly.withColumn(Float.DAY_COUNT_VISITED_DISNEY_LAST_12_MONTHS, F.col("total_day_disney_weekday") + F.col("total_day_disney_weekend"))\
            .groupBy(keys)\
            .agg(F.sum(F.col(Float.DAY_COUNT_VISITED_DISNEY_LAST_12_MONTHS)).alias(Float.DAY_COUNT_VISITED_DISNEY_LAST_12_MONTHS))

    return sdf.select(

        *keys,
        Float.DAY_COUNT_VISITED_DISNEY_LAST_12_MONTHS
    )

def rating_geolocation_disney_last_12m(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    """It is to how many times the customers reached Disney in geolocation
    Args:
        spark (SparkSession): SparkSession
        run_date (datetime): _description_
        version (_type_): _description_
    """
    nums_month = 12
    latest_month = None
    geolocation_disney_monthly = None
    try:
        latest_month = run_date - relativedelta(months=1)
        latest_str = latest_month.strftime("%Y%m")
        spark.read.parquet(f'{geolocation_feature}/monthly_stop_stay/disney/MONTH_ID={latest_str}')
    except:
        latest_month = run_date - relativedelta(months=2)
        latest_str = latest_month.strftime("%Y%m")
        spark.read.parquet(f'{geolocation_feature}/monthly_stop_stay/disney/MONTH_ID={latest_str}')

    print(f"Reading last geolocation disney month: {latest_str}")

    months = [(latest_month - relativedelta(months=i)).strftime('%Y%m')
            for i in range(nums_month)]
    # transform the months to data paths
    geolocation_disney_monthly = spark.read.parquet(f'{geolocation_feature}/monthly_stop_stay/disney/')\
                            .filter(F.col("MONTH_ID").isin(months))\
                            .withColumnRenamed("subr_num", "SUBR_NUM")\
                            .withColumnRenamed("cust_num", "CUST_NUM")

    return _get_disney_stop_stay_disney_last_12m(geolocation_disney_monthly)