import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StringType
from datetime import datetime, timedelta
from ratings.feature_ratings import BooleanFeatureRatings as Bool
from ratings.feature_ratings import FloatFeatureRatings as Float
from paths import calllog

moving_company_hotlines = [
    '22620635',
    '23371234',
    '23886883',
    '24333177',
    '27020885',
    '28292222',
    '28506666',
    '29581233',
    '37013701',
    '61554499',
    '70743772',
    '97232001'
]

def _moving_company_caller(df) -> DataFrame:
    """
    Calculate
    Bool.CALLLOG_MOVING_COMPANY_CALLER
    """

    callees = "A_NUM"
    dial_type = "CALL_REC_TYPE_CD" # dial in = 30; dial out = 20

    df = df.filter(
            (F.col(callees).isin(moving_company_hotlines)) & 
            (F.col(dial_type)==20)
        ).withColumn(
            Bool.CALLLOG_MOVING_COMPANY_CALLER,
            F.lit(True)
        ).select(
            'CUST_NUM', 'SUBR_NUM',
            Bool.CALLLOG_MOVING_COMPANY_CALLER,
        ).distinct()

    return df


def ratings_moving_company_caller(spark: SparkSession, run_date: datetime, version) -> DataFrame:
    caller = spark.read.parquet(
            *[
                f'{calllog}/CALL_START_DATE='+(run_date - timedelta(days=i+3)).strftime('%Y-%m-%d')
                for i in range(30)
            ]
        )
    return _moving_company_caller(caller)