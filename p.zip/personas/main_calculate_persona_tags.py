from pyspark.sql import SparkSession, DataFrame
from datetime import datetime
from tagging.persona_tags import conditions, PersonaTags
import pyspark.sql.functions as F
from typing import Dict
from pyspark.sql.column import Column
import paths
from pyspark.sql.utils import AnalysisException


def make_personas_df(ratings_df: DataFrame, subscribers: DataFrame, tags_conditions: Dict[PersonaTags, Column]) -> DataFrame:
    """
    Make:
    SUBR_NUM, CUST_NUM, TAG1, TAG2, ..., TAGS
    x         x         True  False ...  ["TAG1", ...]
    ...

    Tags are defined in tagging.persona_tags
    """
    subscribers = subscribers.filter(
        "SUBR_NUM is not null and CUST_NUM is not null and SUBR_NUM != '' and CUST_NUM != ''"
    ).select('SUBR_NUM', 'CUST_NUM', 'CUST_ID', 'ACCT_NUM').distinct().join(
        ratings_df, how='left', on=['SUBR_NUM', 'CUST_NUM']
    )
    
    persona_cols = sorted([k for k in tags_conditions.keys()])

    return subscribers.select(
        
        F.col('SUBR_NUM'), F.col('CUST_NUM'), F.col('CUST_ID'), F.col('ACCT_NUM'),
        *[
            F.when(tags_conditions[persona], F.lit(True)).otherwise(F.lit(False)).alias(persona)
            for persona in persona_cols
        ]
    ).withColumn(
        'TAGS',
        F.array(
            *[F.when(F.col(p), p).otherwise(None) for p in persona_cols]
        )
    ).withColumn(
        'TAGS',
        F.expr("FILTER(tags, x -> x is not null)")
    )


def active_users():
    tables = [
        ('POST_PAID', paths.active_postpaid_mass_market_and_business_market),
        ('POST_PAID_NON_CONTRACT', paths.active_postpaid_non_contract),
        ('HOME_BROADBAND', paths.active_5G_home_broadband),
        ('PREPAID', paths.active_prepaid_normal_barkadahan_sahabat),
    ]

    return spark.read.option('mergeSchema', 'true').parquet(*[path for _, path in tables]).withColumn(
        'src', F.input_file_name()
    ).select(
        'SUBR_NUM', 'CUST_NUM', 'CUST_ID', 'ACCT_NUM',
        *[
            (F.col('src').like(path + '/%.parquet')).alias(product) for product, path in tables
        ]
    )



def run(spark: SparkSession, run_date: datetime, version: str):
    path_date = run_date.strftime('%Y-%m-%d')
    ratings_df = spark.read.parquet(
        paths.all_ratings.format(path_date=path_date, version=version)
    )

    # save a snapshot for reproducibility
    try:
        active_users().write.parquet(paths.active_users.format(path_date=path_date, version=version))
    
    except AnalysisException as e:
        if 'already exists' not in str(e):
            raise e

    personas_df = make_personas_df(
        ratings_df, 
        spark.read.parquet(paths.active_users.format(path_date=path_date, version=version)), 
        conditions()
    )

    personas_df.write.mode('overwrite').parquet(
        paths.tags.format(path_date=path_date, version=version)
    )


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='calculate tags')
    parser.add_argument('run_date', metavar='yyyy-mm-dd', type=str)
    parser.add_argument('version', metavar='v', type=str)
    args = parser.parse_args()

    spark = SparkSession.builder.appName("persona-tags").getOrCreate()
    run_date = datetime.strptime(args.run_date, '%Y-%m-%d')
    _now = datetime.now()

    if (_now - run_date).days > 3:
        raise ValueError(f'now {_now} - run date {run_date} > 3 days, too late')

    run(spark, run_date, args.version)
