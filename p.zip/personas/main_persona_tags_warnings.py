from datetime import datetime, timedelta
import paths
import pyspark.sql.functions as F
from pyspark.sql import SparkSession, DataFrame
import re
from typing import List, Dict
import logging
try:
    from spark_fs_util import FsUtil  # need fs util for spark
except:
    pass

class ValidaitionMessage():
    def __init__(self, valid: bool, msg: str):
        self.valid = valid
        self.msg = msg

def get_path_with_closest_version_by_tag_paths(version:str, files: List[str]) -> str:
    """
    Get the latest version given a list of tag paths of different versions. Assume all version has the format vX.Y.Z
    
    Args:
        version (str): A version string to be compared to find the closest version
        files (list[str]): list of tag paths of different versions
        
    Returns:
        str: tags path with the latest version
    """
    regex = r"version=v(\d+\.\d+\.\d+)$" # force version with format desired.
    reg = re.compile(regex)
    matched_files = list(filter(reg.search, files))
    if not matched_files:
        return None
    # filter equal or older version
    filter_files = list(filter(
                        lambda element: (compare_version(version, element) == 0) or (compare_version(version, element) == 1),
                        matched_files)
                       )
    if not filter_files:
        return None
    # find the newest version after filtering
    files_path_with_sorted_version = sorted(filter_files, key=get_main_version_from_string)
    return files_path_with_sorted_version[-1]
    

def compare_version(version:str, to_be_compared_string:str):
    """
    - (Same Version) Equal to: == -> return 0
    - (Older Version) Greater than: > -> return -1
    - (Newer Version) Less than: < -> return 1
    - Cannot compare -> return None
    """
    main_version = get_main_version_from_string(version)
    compared_main_version = get_main_version_from_string(to_be_compared_string)
    
    if compared_main_version is None:
        return ValueError("Cannot get main version in 'to_be_compared_string' argument.")
    # split to three parts
    pattern = r"v(\d+\.\d+\.\d+)"

    match = re.match(pattern, main_version)
    compared_match = re.match(pattern, compared_main_version)

    if (not match) or (not compared_match):
        raise Exception("Cannot compare version as Not desired regex pattern found in version string")
    
    major, minor, patch = map(int, match.group(1).split('.'))
    compared_major, compared_minor, compared_patch = map(int, compared_match.group(1).split('.'))

    if compared_major == major and compared_minor == minor and compared_patch == patch:
        return 0
    elif compared_major < major or (compared_major == major and compared_minor < minor) or (compared_major == major and compared_minor == minor and compared_patch < patch):
        return 1
    else:
        return -1

def get_main_version_from_string(version: str):

    """Suppose getting version/path, this function is to getting main function for that string
    For example:
        You got version="v1.1.1-rc" -> return "v1.1.1"
        or "dtap://TenantStorage/version=v111.1.2" -> return "v111.1.2"

    Args:
        version (str): string which is path or version string with prefix "v"

    Returns:
        string: if exist regex, return the main version string. Otherwise, return None
    """
    regex = r"v(\d+\.\d+\.\d+)"
    reg = re.compile(regex)

    filter_files = reg.search(version)
    if filter_files is None:
        return None
    else:
        return filter_files.group()
    
        
def get_past_7_days(run_date: datetime) -> List[datetime]:
    """
    Computes the past 7 days from the given date string in the format "YYYY-MM-DD".
    
    Args:
        date_str (str): The date string in the format "YYYY-MM-DD".
        
    Returns:
        list: A list of date strings in the format "YYYY-MM-DD" for the past 7 days.
    """
    past_7_days = [
        run_date - timedelta(days=i)
        for i in range(7, 0, -1)
    ]
    return past_7_days


def get_path_before_version(tags_str: str) -> str:
    """
    Extracts the part of the input string before the "/version=" substring.
    
    Args:
        tags_str (str): The input string in the format
            "dtap://TenantStorage/personas/tags/run_date={path_date}/version={version}".
    
    Returns:
        str: The part of the input string before the "/version=" substring.
    """
    version_index = tags_str.find("/version=")
    if version_index != -1:
        return tags_str[:version_index]
    else:
        return tags_str


def compute_true_counts(df: DataFrame) -> dict:
    """
    Computes the number of True counts for each boolean variable in the given Spark DataFrame and returns the results as a dictionary.
    
    Args:
        df (pyspark.sql.DataFrame): The Spark DataFrame with the given schema.
        
    Returns:
        dict: A dictionary where the keys are the boolean variable names and the values are the number of True counts for each variable.
    """
    boolean_cols = [col for col, dtype in df.dtypes if dtype == 'boolean']
    true_counts = {}
    
    for col in boolean_cols:
        true_counts[col] = df.where(df[col]).count()
    
    return true_counts


def compute_avg_for_each_key(data: List[dict]) -> dict:
    """
    Computes the average values of each key-value pair in a list of dictionaries.
    
    Args:
        data (list): A list of dictionaries.
        
    Returns:
        dict: A dictionary where the keys are the keys from the input dictionaries,
        and the values are the average of the corresponding values.
    """
    avg_dict = {}
    
    # Get the set of all unique keys across the input dictionaries
    all_keys = set()
    for d in data:
        all_keys.update(d.keys())
    
    # Compute the average for each key
    for key in all_keys:
        values = [d.get(key, 0) for d in data]
        count_non_zero = len([value for value in values if value != 0])
        avg_dict[key] = float(sum(values)) / count_non_zero
    return avg_dict


def get_abnormal_dict_values_diff(dict1: dict, dict2: dict, threshold: float) -> List[tuple]:
    """
    Return the keys where the corresponding values in the two dictionaries differ by more than 10%.
    
    Args:
        dict1 (dict): The first dictionary.
        dict2 (dict): The second dictionary.
    """
    diff_keys = []
    for key in set(dict1.keys()) | set(dict2.keys()):
        if key in dict1 and key in dict2:
            diff_count = abs(dict1[key] - dict2[key])
            if diff_count / max(dict1[key], dict2[key]) > threshold:
                # logging.warning(f"[Warning] Key '{key}' has a value difference of more than {threshold*100}%, diff count: {diff_count}")
                diff_keys.append((
                    key,
                    diff_count
                ))
    return diff_keys

def check_dict_values_diff(abnormal_diff_keys: dict, threshold: float) -> Dict[bool, str]:
    """
    Return boolean to show dict_values_diff pass or not.

    Args:
        abnormal_diff_keys (dict): output from get_abnormal_dict_values_diff
        threshold (float): threshold which is to show in the warning or exception messages

    Returns:
        Dictionary: "valid" showed if True, it is normal. Otherwise, we should create exception or warning.
                    "msg" is the output messages.
    """
    msg = ""
    if abnormal_diff_keys:
        msgs = []
        for key_dict_values_diff in abnormal_diff_keys:
            msgs.append(
                "{key} has a value difference of more than {threshold}%, diff count: {diff_count}".format(
                    key=key_dict_values_diff[0],
                    threshold=threshold*100,
                    diff_count=key_dict_values_diff[1]
                )
            )
        msg = "\n".join(msgs)

        return ValidaitionMessage(valid=False, msg=msg)
    else:
        return ValidaitionMessage(valid=True, msg=msg)


def run(spark: SparkSession, run_date: datetime, version: str):
    """
    check persona tags, send out warning if fail
    """
    
    # fs_util to check the latest version of file
    fs_util = FsUtil(spark, "dtap://TenantStorage/")
    
    # read and compute tag counts of persona result of run_date
    personas_df = spark.read.parquet(
        paths.tags.format(path_date=run_date.strftime('%Y-%m-%d'), version=version)
    )
    true_counts = compute_true_counts(personas_df)
    
    # read and compute average count of persona result of past 7 days
    true_counts_of_past_7_days = []
    past_dates = get_past_7_days(run_date)
    for past_date in past_dates:
        
        # version is dummy
        path = get_path_before_version(paths.tags).format(path_date=past_date.strftime('%Y-%m-%d'))
        if not fs_util.is_exist(path):
            continue

        files = fs_util.ls(path)
        # only use the latest version if multiple versions exist
        path_of_latest_version = get_path_with_closest_version_by_tag_paths(version, files)
        df = spark.read.parquet(path_of_latest_version)
        true_counts_of_past_7_days.append(compute_true_counts(df))
    
    avg_counts_of_past_7_days = compute_avg_for_each_key(true_counts_of_past_7_days)

    # compare the difference of each tag between run_date and the average of past 7 days
    diff_threshold = 0.15
    diff_tags = get_abnormal_dict_values_diff(true_counts, avg_counts_of_past_7_days, diff_threshold)
    
    # list all warnings functions here
    all_check_functions = {
        "check_dict_values_diff": check_dict_values_diff(abnormal_diff_keys=diff_tags, threshold=diff_threshold),

    }
    
    for func_name, details in all_check_functions.items():
        if details.valid is False:
            raise Exception("{function} is invalid. \n \
                            Message: {message}".format(
                                                        function=func_name,
                                                        message=details.msg))
            


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='validate tags')
    parser.add_argument('run_date', metavar='yyyy-mm-dd', type=str)
    parser.add_argument('version', metavar='v', type=str)
    args = parser.parse_args()

    spark = SparkSession.builder.appName("persona-warnings").getOrCreate()
    run_date = datetime.strptime(args.run_date, '%Y-%m-%d')

    run(spark, run_date, args.version)