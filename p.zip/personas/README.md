# personas

For calculating persona tags.


### Mains
- `main_calculate_ratings.py`: To calculate all ratings.
- `main_calculate_persona_tags.py`: To calculate all tags.
- `main_validate_persona_tags.py`: Validate all tags according to rules, uploads data to final destination only if tag data passes validation.
- `main_persona_tags_warnings.py`: Produces warnings that needs attention but not necessarily catastropic to releasing the tags.
- `main_calculate_observability.py`: Calculates monitoring metrics to be uploaded to dashboards.
- `pytest tests/`: Run all tests.

### Development Guide
All tags are defined based on "Ratings" columns, see `tagging.persona_tags.py`, e.g.
```
PersonaTags.UNIVERSITY_STUDENT: (
        (F.col(Float.AGE) >= 18) & (F.col(Float.AGE) <= 25) &
        (F.col(Float.UNI_DOMAINS_VISIT_DAYS_CNT_180D_PERCENTILE_WITHIN_AGE_18_25) >= 0.70) &
        (F.col(Bool.UNI_GEOLOCATION_AT_LEAST_3_DAYS_30D_ANY_6M))
    ),
```
These are calculated per subscriber.

1. Add or reuse ratings columns in `ratings.feature_ratings.py`.
2. Add spark function to calculate said ratings in `ratings` module.
3. Add call to function in `main_calculate_ratings.py`.
4. Define your tag in `tagging.persona_tags.py`.
5. Add tests in `tests` module.


### Add Release Candidate (RC) Versions
1. Make `v\d+\.\d+\.\d+-rc\d+` (`v1.1.12-rc1`) tag in `dev` or `prod` branch for testing future production releases.
2. Add the newly created RC tag to [airflow DAG](https://apgitscpl01.smartone.com/ds_datascience_grp/hpe_airflow/-/blob/dev/subscriber_features/personas_tagging.py?ref_type=heads)
3. Merge airflow `dev` -> `master`.


### Airflow
Airflow DAG:
https://apgitscpl01.smartone.com/ds_datascience_grp/hpe_airflow/-/blob/dev/subscriber_features/personas_tagging.py


### Add Production Versions
1. Merge `dev` -> `prod`.
2. Create new tag on `prod` branch (only `v\d+\.\d+\.\d+`, e.g. `v1.1.12`). Add release notes.
3. Add the newly created tag to [airflow DAG](https://apgitscpl01.smartone.com/ds_datascience_grp/hpe_airflow/-/blob/dev/subscriber_features/personas_tagging.py?ref_type=heads), preferrably to parallel run with at least 1 older production version (e.g. `v1.1.12` and `v1.1.11`).
4. Remove older versions or release candidates versions  from airflow DAG if needed.
5. Merge airflow `dev` -> `master`.
6. Create new Release on Gitlab Release page using the tag created on step 2, with Release Title same as tag name.