import logging
from datetime import datetime
import paths
import pyspark.sql.functions as F
from pyspark.sql import SparkSession, DataFrame
import re


def validate_personas_df(df: DataFrame) -> bool:
    ok = df.select('SUBR_NUM', 'CUST_NUM').distinct().count() == df.count()
    if not ok:
        logging.info('SUBR_NUM CUST_NUM not distinct')

    return ok


def is_prod_version(version: str) -> bool:
    p = r'^v\d+\.\d+\.\d+$'
    return re.search(p, version) is not None


def run(spark: SparkSession, run_date: datetime, version: str):
    """
    Validate persona table, and then copies to ext_mapr_persona
    """
    path_date = run_date.strftime('%Y-%m-%d')
    personas_df = spark.read.parquet(
        paths.tags.format(path_date=path_date, version=version)
    )

    if validate_personas_df(personas_df):

        if not is_prod_version(version):
            return

        personas_df.select(
            'CUST_NUM', 'SUBR_NUM', 'CUST_ID', 'ACCT_NUM', F.array_join('TAGS', delimiter=',').alias('TAGS')
        ).write.mode('overwrite').csv(
            f'dtap://ext_mapr_persona/personas/tags/run_date={path_date}/version={version}',
            header=True
        )
    else:
        raise Exception('Did not pass validation.')


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='validate tags')
    parser.add_argument('run_date', metavar='yyyy-mm-dd', type=str)
    parser.add_argument('version', metavar='v', type=str)
    args = parser.parse_args()

    spark = SparkSession.builder.appName("persona-validate").getOrCreate()
    run_date = datetime.strptime(args.run_date, '%Y-%m-%d')
    _now = datetime.now()

    if (_now - run_date).days > 3:
        raise ValueError(f'now {_now} - run date {run_date} > 3 days, too late')

    run(spark, run_date, args.version)
