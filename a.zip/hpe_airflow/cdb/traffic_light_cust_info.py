import json
from datetime import datetime

from airflow import DAG
from airflow.decorators import dag, task
from airflow.models.param import ParamsDict
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from utils.git_utils import git_clone_init_container, GitRepositories, get_branch_by_k8s_namespace
from kubernetes.client import models as k8s
from airflow.utils.dates import days_ago
# try work around as without it, i cannot get it working
# import os, sys
# sys.path.append("/usr/local/airflow/dags/gitdags/dags")
from utils.airflow_utils import k8s_namespace, get_registry_proxy
from utils.email_utils import send_email
from datetime import timedelta
def ds_arg(offset):
    template = "macros.ds_format( macros.ds_add(ds, " + str(offset) + "), '%Y-%m-%d', '%Y%m%d' ) if params.run_date == 'yyyymmdd' else params.run_date"
    return '{{ ' + template + ' }}'

def add_arg(cmd:str, arg: str, value):
    return " ".join([cmd, f"{arg}={value}"])

def convert_list_to_args(arg_name, target_list: list):
    cmd = ""
    if len(target_list) != 0:
        for table in target_list:
            cmd = " ".join([cmd, arg_name + table])
    return cmd

def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["airtable", "trafficlight"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(2),
        "doc_md": """
                    # airtable data staging
                  """,
        'on_failure_callback': send_email
    }
def execute(task_id: str,args: list):
# git sync into empty directory
    volume_name = "workdir"
    volume = k8s.V1Volume(name=volume_name,empty_dir=k8s.V1EmptyDirVolumeSource())
    git_env = {
        'GIT_SYNC_REPO': GitRepositories.COMMON_DATABASE.value,
        'GIT_SYNC_USERNAME': "dw_dwsup_04@smartone.com",
        'GIT_SYNC_PERMISSIONS': "0755",
        'GIT_SYNC_PASSWORD_FILE': '/etc/secret-volume/git-password-file',
        'GIT_SYNC_DEST': "cdb",
        'GIT_SYNC_ROOT': f"/workdir" + "/airflow-working-dir/",
        'GIT_SYNC_BRANCH': get_branch_by_k8s_namespace(),
        'GIT_SYNC_ONE_TIME': 'true',
        "GIT_SYNC_GIT_CONFIG": "http.sslVerify:false",
        }

    git_env = [k8s.V1EnvVar(name=k, value=v) for k, v in git_env.items()]

    # secret key
    git_env.append(k8s.V1EnvVar(
        name = "GIT_SYNC_PASSWORD",
        value_from = k8s.V1EnvVarSource (
            secret_key_ref = k8s.V1SecretKeySelector(
                            name="airflow-gitrepo-password",
                            key="password"
            )
        )
    ))

    git_sync_init_container = k8s.V1Container(
            name =  "git-sync",
            image= "{domain}/git-sync/git-sync:v3.3.4".format(domain = get_registry_proxy()["k8s.gcr.io"]),
            resources=k8s.V1ResourceRequirements(
                limits={
                    "cpu": "500m", "memory": "600Mi"
                },
                requests={
                    "cpu": "400m", "memory": "600Mi"
                }
            ),
            volume_mounts=[
                k8s.V1VolumeMount(
                    mount_path=f"/workdir",
                    name=volume_name,
                ),
            ],
            env=git_env

        )
    # makes the dtap process show up in `ps`
    additional_pod_spec = k8s.V1Pod(
        spec=k8s.V1PodSpec(
            share_process_namespace=True,
            containers=[]
            )
        )
    
    # set the bash/command after the pods has establish
    arg = args

    
    args = ' && '.join(arg)
    return KubernetesPodOperator(
                    namespace=k8s_namespace(),
                    image="{domain}/smtds/smt-omms-python:1.0.2".format(domain=get_registry_proxy()["dockerhub"]),
                    cmds=['/bin/bash','-c'],
                    arguments=[args],
                    labels={"hpecp.hpe.com/dtap": "hadoop2-job"},
                    name=task_id,
                    task_id=task_id,
                    get_logs=True,
                    volumes=[volume],
                    image_pull_secrets= 'regcred', # for access to private registry
                    volume_mounts = [k8s.V1VolumeMount(
                                                    name = volume_name,
                                                    mount_path = f"/workdir"
                                                    )
                                    ],
                    init_containers = [git_sync_init_container],
                    is_delete_operator_pod =True,
                    full_pod_spec=additional_pod_spec,
                    resources=k8s.V1ResourceRequirements(
                        limits={"cpu": "1000m", "memory": "16Gi"},
                        requests={"cpu": "1000m", "memory": "16Gi"}
                    ),
                    env_vars=[
                                k8s.V1EnvVar(name='ORACLE_USENAME',
                                             value="BAANAUSR"),
                                k8s.V1EnvVar(name='ORACLE_PASSWORD', value_from=k8s.V1EnvVarSource(
                                    secret_key_ref=k8s.V1SecretKeySelector(
                                        key="password", 
                                        name="oracle-secret")
                                ))
                            ],
                    retries=1,
                    retry_delay=timedelta(minutes=10),
                    dag=dag
                )
with DAG(
    dag_id = 'cdb_traffic_light_cust_info', 
    default_args=get_default_args(),
    schedule_interval=None,
    catchup=False,
    user_defined_macros = {
        "convert_list_to_args": convert_list_to_args
    },
    params={
        'RUN_MONTH': 'yyyymm',
        'SINGLE_OM_OFFER_SCORING_ID': '', # use single sim notebook 3 output
        'ENV': 'hpe',
        '__RUN_MONTH__': "RUN_MONTH is denoted as ce0 month in cohort refresh. For example, CE0 month is 202403, then RUN_MONTH is 202403",
        '__SINGLE_OM_OFFER_SCORING_ID__': "Use single sim notebook 3 output! only the ID but not he path"

    }
)as dag:

    python_extract_table_file_path = "python3 /workdir/airflow-working-dir/cdb/pipeline_extract_tables.py"
    python_cmd_extract_table = add_arg(python_extract_table_file_path, "--RUN_MONTH", '{{ params.RUN_MONTH }}')
    python_cmd_extract_table = add_arg(python_cmd_extract_table, "--ENV", 'hpe')

    python_cust_info_etl_path = "python3 /workdir/airflow-working-dir/cdb/main_traffic_light_cust_info_etl.py"
    python_cmd_cust_info_etl = add_arg(python_cust_info_etl_path, "--RUN_MONTH", '{{ params.RUN_MONTH }}')

    python_offer_assignment_file_path = "python3 /workdir/airflow-working-dir/cdb/main_offer_assignment_netprice.py"
    python_cmd_offer_assignment = add_arg(python_offer_assignment_file_path, "--RUN_MONTH", '{{ params.RUN_MONTH }}')
    python_cmd_offer_assignment = add_arg(python_cmd_offer_assignment, "--SINGLE_OM_OFFER_SCORING_ID", '{{ params.SINGLE_OM_OFFER_SCORING_ID }}')

    python_combine_file_path = "python3 /workdir/airflow-working-dir/cdb/main_combine_trafiic_light_cust_info.py"
    python_cmd_combine = add_arg(python_combine_file_path, "--RUN_MONTH", '{{ params.RUN_MONTH }}')


    
    extract_table = execute(task_id="tl_extract_table",
                                args=["sleep 20s", # wait for dtap sidecar to become ready
                                python_cmd_extract_table
                                ])
    cust_info_etl = execute(task_id="tl_cust_info_etl",
                                args=["sleep 20s", # wait for dtap sidecar to become ready
                                python_cmd_cust_info_etl
                                ])
    offer_assignment_netprice = execute(task_id="tl_offer_assignment_netprice",
                                args=["sleep 20s", # wait for dtap sidecar to become ready
                                python_cmd_offer_assignment
                                ])
    combine = execute(task_id="tl_combine",
                                args=["sleep 20s", # wait for dtap sidecar to become ready
                                python_cmd_combine
                                ])
    
    extract_table >> cust_info_etl
    extract_table >> offer_assignment_netprice

    offer_assignment_netprice >> combine
    cust_info_etl >> combine