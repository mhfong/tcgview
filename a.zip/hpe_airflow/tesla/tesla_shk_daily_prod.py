from airflow import DAG
from airflow.utils.dates import days_ago
# try work around as without it, i cannot get it working
#sys.path.append("/usr/local/airflow/dags/gitdags/dags")
from utils.spark_spec_utils import EmptyVolume, GitSyncInitContainer, SparkDriver, SparkExecutor, SparkApplication
from utils.git_utils import GitRepositories, get_branch_by_k8s_namespace
#from utils.executor_utils import override_executor_config
from utils.airflow_utils import user_defined_filters, spark_task_group
from utils import airflow_utils

def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["tesla", "shk", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(1),
        "doc_md": """
                    # SHK Tesla data pipeline
                  """,
    }

def define_spec(path_to_py, task_word):
    
    EMPTYVOLUME = EmptyVolume("emptydir") # create empty volume called "emptydir"
    mount_path = "/workdir"
    VOLUMEMOUNT={"name": "emptydir", # let emptydir mount on /workdir folder
                "mountPath": mount_path}
    
    INITCONTIANER = GitSyncInitContainer(name="git-sync-tesla",
                                        repo=GitRepositories.TESLA_SHKP,
                                        destination="tesla",
                                        branch="{{ params.git_branch }}",
                                        volume_mount_name="emptydir")
    
    DRIVER = SparkDriver(core=2,
                        memory="15g",
                        env = [
                        {"name": "ENVIRONMENT", "value": "{{ params.env }}"},
                        {"name": "TARGET_DATE","value": "{{ params.target_date if params.target_date != '' else ds_nodash }}"}
                        ],
                        volumeMounts=[VOLUMEMOUNT],
                        initcontainer=[INITCONTIANER]
                        )
    
    EXECUTOR = SparkExecutor(core=2, memory="40g", instances=3, env=[], volumeMounts=[VOLUMEMOUNT])
    sparkapplication = SparkApplication(driver=DRIVER, executor=EXECUTOR, volumes=[EMPTYVOLUME])
    app_spec=sparkapplication.get_spec(path_to_py=f"{mount_path}/{INITCONTIANER.source_folder_path}/{path_to_py}", generateName=task_word)

    return spark_task_group(
        dag=dag,
        spark_app_name=task_word,
        spark_app_spec=app_spec
    )

with DAG(
        dag_id='tesla_to_shk_daily_prod',
        default_args=get_default_args(),
        params={
            "git_branch": get_branch_by_k8s_namespace(),
            "target_date": "", 
            "env": "hpe",
        },
        catchup=False,
        schedule_interval="40 13 * * *", # do it at night, run after geolocation raw data is copied to mapr
        user_defined_filters=user_defined_filters()
) as dag:

    # time of execution
    # DagRun.execution_date is Column(UtcDateTime, default=timezone.utcnow) from official docs
    task_g = define_spec("scripts/spark_main_pipeline.py", "main")
    
    task_g
    
