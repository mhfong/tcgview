from datetime import datetime
from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group
from utils.git_utils import git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace
from utils.airflow_utils import k8s_namespace
from segmentation_platform.subscriber_domain_visit_dag import django_command_task
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "tags": [],
        "start_date": datetime(2024, 1, 26),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """""",
        'on_failure_callback': send_email
    }


def spark_app(path_to_py, args):
    init_container = git_clone_init_container_dict(
        repo=GitRepositories.SEGMENTATION_WORKER,
        branch=get_branch_by_k8s_namespace()
    )
    img = 'smtds/spark-py-2.4.7-oracle:20231103commonutil'
    _spec = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "discover-domain",
            "namespace": "c360-project"
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "image": img,
            "imagePullPolicy": "Always",
            "mainApplicationFile": "/home/git/" + GitRepositories.SEGMENTATION_WORKER.repo_name() + path_to_py,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": ["imagepull",
                "smtds-dockerhub-secret"],

            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "20g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": [init_container],
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "shareProcessNamespace": True,
                "env": [
                    {
                        "name": "ENV_NAME",
                        "value": get_branch_by_k8s_namespace()
                    },
                    {
                        "name": "SEGMENTATION_WEB_HOST",
                        "value": 'http://segmentation-web.' + k8s_namespace() + '.svc.cluster.local:8000'
                    },
                    {
                        "name": "SEGMENTATION_API_TOKEN",
                        "valueFrom": {
                            "secretKeyRef": {
                                "key": "SEGMENTATION_API_TOKEN",
                                "name": "segmentation-scheduler-secrets"
                            }
                        }
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 4,
                "memory": "50g",
                "initContainers": [init_container],
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }

    return _spec


filters = user_defined_filters()


with DAG(
    dag_id='segmentation_domain_daily',
    default_args=get_default_args(),
    params={
    },
    user_defined_filters=filters,
    schedule_interval='0 12 * * *', 
    catchup=False,
) as dag:
    
    domain_daily = spark_task_group(
        dag=dag,
        spark_app_name='discoverer-daily',
        spark_app_spec=spark_app(
            '/domain_usage.py',
            ['{{ ds }}']
        )
    )

    insert = django_command_task(
        'seg-insert-domain-daily',
        'python manage.py insert_domain_metrics {{ ds }}'
    )

    domain_daily >> insert