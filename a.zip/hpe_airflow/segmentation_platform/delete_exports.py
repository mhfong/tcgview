from datetime import datetime
from airflow import DAG
from utils.airflow_utils import user_defined_filters
from segmentation_platform.subscriber_domain_visit_dag import django_command_task
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "tags": [],
        "start_date": datetime(2024, 2, 17),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """""",
        'on_failure_callback': send_email
    }


with DAG(
        dag_id='segmentation_delete_exports',
        default_args=get_default_args(),
        params={
        },
        user_defined_filters=user_defined_filters(),
        catchup=False,
        schedule_interval='30 0 * * *'
) as dag:

    django_command_task('seg-delete-exports', 'python manage.py delete_exports')
