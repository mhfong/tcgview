from datetime import datetime
from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group, airflow_job_labels
from utils.git_utils import git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace, git_clone_init_container
from utils.airflow_utils import k8s_namespace
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from datetime import timedelta
from airflow.hooks.base import BaseHook
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "tags": [],
        "start_date": datetime(2024, 1, 25),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """""",
        'on_failure_callback': send_email
    }


def spark_app(path_to_py, args):
    init_container = git_clone_init_container_dict(
        repo=GitRepositories.SEGMENTATION_WORKER,
        branch=get_branch_by_k8s_namespace()
    )
    img = 'smtds/spark-py-2.4.7-oracle:20231103commonutil'
    _spec = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "seg-subr-domain-visit",
            "namespace": "c360-project"
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "image": img,
            "imagePullPolicy": "Always",
            "mainApplicationFile": "/home/git/" + GitRepositories.SEGMENTATION_WORKER.repo_name() + path_to_py,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": ["imagepull",
                "smtds-dockerhub-secret"],

            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": [init_container],
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "shareProcessNamespace": True,
                "env": [
                    {
                        "name": "ENV_NAME",
                        "value": get_branch_by_k8s_namespace()
                    },
                    {
                        "name": "SEGMENTATION_WEB_HOST",
                        "value": 'http://segmentation-web.' + k8s_namespace() + '.svc.cluster.local:8000'
                    },
                    {
                        "name": "SEGMENTATION_API_TOKEN",
                        "valueFrom": {
                            "secretKeyRef": {
                                "key": "SEGMENTATION_API_TOKEN",
                                "name": "segmentation-scheduler-secrets"
                            }
                        }
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "32g",
                "initContainers": [init_container],
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }

    return _spec


def django_command_task(task_id, django_command):
    """
    Runs a django command in a pod
    @param task_id:
    @param django_command:
    @return:
    """
    repo_name = GitRepositories.SEGMENTATION_WEB.repo_name()
    init_container = git_clone_init_container(
        repo=GitRepositories.SEGMENTATION_WEB, branch=get_branch_by_k8s_namespace()
    )
    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        f'cd /home/git/{repo_name}/segmentationsite',
        django_command
    ]
    args = ' && '.join(arg)
    mysql_username = BaseHook.get_connection('segmentation_mysql').login
    labels = airflow_job_labels()
    labels['hpecp.hpe.com/dtap'] = 'hadoop2-job'
    return KubernetesPodOperator(
        task_id=task_id,
        labels=labels,
        namespace=k8s_namespace(),
        image='smtds/segmentation-web:latest',
        image_pull_secrets='smtds-dockerhub-secret',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        env_from=[k8s.V1EnvFromSource(
            secret_ref=k8s.V1SecretEnvSource(
                name='segmentation-web-secrets'
            )
        )],
        env_vars=[
            k8s.V1EnvVar(name='ENV_NAME', value=get_branch_by_k8s_namespace()),
            k8s.V1EnvVar(name='MYSQL_USER', value=mysql_username),
            k8s.V1EnvVar(name='CLASSPATH', value_from=k8s.V1EnvVarSource(
                config_map_key_ref=k8s.V1ConfigMapKeySelector(
                    key='CLASSPATH',
                    name='segmentation-hadoop-classpath'
                )
            )),
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "8", "memory": '16Gi'
            },
            requests={
                "cpu": "8", "memory": '16Gi'
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        execution_timeout=timedelta(minutes=60)
    )


with DAG(
        dag_id='segmentation_subr_domain_visit',
        default_args=get_default_args(),
        params={
        },
        user_defined_filters=user_defined_filters(),
        catchup=False,
        schedule_interval='30 6 * * *'
) as dag:

    spark_subr_domain_visit = spark_task_group(
        dag=dag,
        spark_app_name='calc',
        spark_app_spec=spark_app(
            '/subscriber_domain_visit.py',
            ['{{ ds }}']
        )
    )

    block_ad_domain = spark_task_group(
        dag=dag,
        spark_app_name='adblock',
        spark_app_spec=spark_app(
            '/subscriber_domain_visit_adblock.py',
            ['{{ ds }}']
        )
    )

    ingest = django_command_task(
        'seg-ingest-subr-domain-visit',
        'python manage.py insert_subscriber_domain_visit {{ ds }}'
    )

    spark_subr_domain_visit >> block_ad_domain >> ingest
