
from datetime import datetime

from airflow import DAG
from utils.git_utils import GitRepositories, git_clone_init_container_dict, get_branch_by_k8s_namespace
from utils.airflow_utils import user_defined_filters, spark_task_group
from utils.airflow_utils import k8s_namespace
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "network exp",
        "start_date": datetime(2023, 3, 1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        'on_failure_callback': send_email
    }


def clean_s11_spark_app():
    image = 'smtds/spark-py-2.4.7-oracle:20230328'
    main_file = '/src/clean_raw_network_data.py'

    ns = k8s_namespace()
    customer_list = 'dtap://ext_mapr/ws_jayson/CNSS/storage_subr_num_list/subr_num_list_for_storage.csv'

    init_containers = [git_clone_init_container_dict(
        GitRepositories.NETWORK_DATA_ANALYSIS,
        get_branch_by_k8s_namespace()
    )]
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "namespace": ns
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": '/home/git/' + GitRepositories.NETWORK_DATA_ANALYSIS.repo_name() + main_file,
            "arguments": [
                "{{ ds if params.start_date == 'yyyy-mm-dd' else params.start_date }}",
                "{{ ds if params.end_date == 'yyyy-mm-dd' else params.end_date }}",
                'dtap://TenantStorage/network_data_analysis/cnss_s11',
                '-c', customer_list
            ],
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 3,
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


with DAG(
    dag_id='network_exp_raw_data',
    default_args=get_default_args(),
    params={
        'start_date': 'yyyy-mm-dd',
        'end_date': 'yyyy-mm-dd'
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 0 * * *',
    catchup=False,
) as dag:

    spark_task = spark_task_group(
        dag=dag,
        spark_app_name='network-exp-s11',
        spark_app_spec=clean_s11_spark_app()
    )
