from datetime import datetime 
from airflow import DAG 
from airflow.operators.email import EmailOperator 
import os
from utils.email_utils import send_email
from airflow.utils.dates import days_ago
# Set the SMTP configuration
os.environ['AIRFLOW__SMTP__SMTP_HOST'] = 'smtp-server-mail'
os.environ['AIRFLOW__SMTP__SMTP_PORT'] = '587'
os.environ['AIRFLOW__SMTP__SMTP_STARTTLS'] = 'False'
os.environ['AIRFLOW__SMTP__SMTP_SSL'] = 'False'
os.environ['AIRFLOW__SMTP__SMTP_MAIL_FROM'] = 'dsteam@dsmlworker.hksmartone.com'
def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["humanstop", "shk", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(1),
        # "email": "walter_sin@smartone.com",
        "doc_md": """
                    # Human stop data pipeline
                  """,
        'on_failure_callback': send_email
    }

with DAG(dag_id='email_operator_dag',
         params={
            "email": "walter_sin@smartone.com",
        },
        start_date=datetime(2023, 1, 1),default_args=get_default_args(), schedule_interval=None) as dag:

    task1 = EmailOperator( 
        task_id='send_email_task',
        to="{{ params.email }}",
        subject='[Airflow Test] From DS Team', 
        html_content='This is a test email. Please do not Reply!' 
    )