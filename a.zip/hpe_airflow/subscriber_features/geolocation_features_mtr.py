from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group, spark_task
from utils.git_utils import k8s_namespace, git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace
from subscriber_features.geolocation_features import geo_spark_job_stop_features, ds_arg
from utils.email_utils import send_email
from airflow.sensors.external_task import ExternalTaskSensor


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2024, 3, 10),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }


with DAG(
    dag_id='geolocation_features_mtr',
    default_args=get_default_args(),
    params={
        'run_date': 'yyyy-mm-dd',
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 20 * * *',
    catchup=False,
) as dag:

    spark_task_1 = spark_task(
        dag=dag,
        spark_app_name=f'mtr-path',
        spark_app_spec=geo_spark_job_stop_features(main_file='/pipeline_mtr_footprint.py', args=[ds_arg(0)])
    )