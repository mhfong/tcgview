from datetime import datetime
from datetime import timedelta

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from airflow.sensors.external_task import ExternalTaskSensor
from kubernetes.client import models as k8s

from utils.airflow_utils import (
    user_defined_filters, spark_task, airflow_job_labels, k8s_namespace,
    SmartPodOperator, log_url
)
from utils.email_utils import send_email
from utils.git_utils import (
    git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace,
    git_clone_init_container
)


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2024, 4, 1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }


def persona_task(
        main_file,
        args: list,
        version: str,
        image='docker.io/smtds/spark-py-2.4.7:202202161825P150'
) -> dict:
    """
    Makes SparkApplication
    @return:
    """
    repo_name = GitRepositories.PERSONAS.repo_name()
    repo_dir = '/'.join([
        '/home/git',
        repo_name
    ])
    main_app_file = repo_dir + main_file
    init_containers = [git_clone_init_container_dict(
        GitRepositories.PERSONAS,
        get_branch_by_k8s_namespace(),
        tag=version
    )]

    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/oracle-jdbc/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "10g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 6,
                "memory": "20g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


def prod_versions():
    v = ['v0.0.17','v0.0.18']
    if get_branch_by_k8s_namespace() == 'prod':
        return v


def args(version: str):
    version = 'dev' if version is None else version
    run_date = f"ds if params.run_date == 'yyyy-mm-dd' else params.run_date"
    a = ['{{ ' + run_date + ' }}', version]
    return a


def load_dashboard_data(task_id, django_commands: list):
    repo_name = GitRepositories.DASHBOARD.repo_name()
    init_container = git_clone_init_container(
        repo=GitRepositories.DASHBOARD,
        branch=get_branch_by_k8s_namespace()
    )
    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        f'cd /home/git/{repo_name}/dashboarddata',
    ] + django_commands

    args = ' && '.join(arg)
    labels = airflow_job_labels()
    labels['hpecp.hpe.com/dtap'] = 'hadoop2-job'
    namespace = k8s_namespace()
    
    return SmartPodOperator(
        task_id=task_id,
        labels=labels,
        namespace=namespace,
        image='smtds/segmentation-web:latest',
        image_pull_secrets='smtds-dockerhub-secret',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        env_vars=[
            k8s.V1EnvVar(name='ENV_NAME', value=get_branch_by_k8s_namespace()),
            k8s.V1EnvVar(name='CLASSPATH', value_from=k8s.V1EnvVarSource(
                config_map_key_ref=k8s.V1ConfigMapKeySelector(
                    key='CLASSPATH',
                    name='segmentation-hadoop-classpath'
                )
            )),
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "8", "memory": '16Gi'
            },
            requests={
                "cpu": "8", "memory": '16Gi'
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        execution_timeout=timedelta(minutes=60)
    )


def tasks(dag, task_suffix='', version: str = None):
    arg_list = args(version)
    ratings = spark_task(
        dag=dag,
        spark_app_name=f'ratings{task_suffix}',
        spark_app_spec=persona_task(
            main_file='/main_calculate_ratings.py',
            args=arg_list,
            version=version
        )
    )
    tagging = spark_task(
        dag=dag,
        spark_app_name=f'tagging{task_suffix}',
        spark_app_spec=persona_task(
            main_file='/main_calculate_persona_tags.py',
            args=arg_list,
            version=version
        )
    )

    validate = spark_task(
        dag=dag,
        spark_app_name=f'validate{task_suffix}',
        spark_app_spec=persona_task(
            main_file='/main_validate_persona_tags.py',
            args=arg_list,
            version=version
        )
    )

    observability = spark_task(
        dag=dag,
        spark_app_name=f'observe{task_suffix}',
        spark_app_spec=persona_task(
            main_file='/main_calculate_observability.py',
            args=arg_list,
            version=version
        )
    )

    warning = spark_task(
        dag=dag,
        spark_app_name=f'warning{task_suffix}',
        spark_app_spec=persona_task(
            main_file='/main_persona_tags_warnings.py',
            args=arg_list,
            version=version,
            image="smtds/spark-py-2.4.7-oracle:20231103commonutil"
        )
    )

    dashboard = load_dashboard_data(
        f'dashboard{task_suffix}',
        ['chmod 777 insert_personasdata.sh', './insert_personasdata.sh ' + ' '.join(arg_list)]
    )

    ratings >> tagging >> validate
    tagging >> observability >> dashboard
    tagging >> warning
    return ratings


with DAG(
    dag_id='personas_tagging',
    default_args=get_default_args(),
    params={
        'run_date': 'yyyy-mm-dd',
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='30 2 * * *',
    catchup=False,
) as dag:

    # 0 2 * * *
    check_geolocation = ExternalTaskSensor(
        task_id="check-geolocation",
        external_dag_id='geolocation_features',
        external_task_id='spark-roaming-trip.monitor_spark',
        timeout=100,
        execution_delta=timedelta(seconds=30*60)
    )

    # allow to run multiple versions at the same time
    PROD_VERSIONS = prod_versions()
    if PROD_VERSIONS:
        for i, v in enumerate(PROD_VERSIONS):
            _tasks = tasks(dag, task_suffix=str(i), version=v)
            check_geolocation >> _tasks

    else:
        _tasks = tasks(dag)
        check_geolocation >> _tasks
