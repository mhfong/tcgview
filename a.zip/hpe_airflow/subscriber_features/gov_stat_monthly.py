
from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task, k8s_namespace
from utils.git_utils import k8s_namespace, git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace
from utils.email_utils import send_email
from airflow.sensors.external_task import ExternalTaskSensor
from datetime import timedelta


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2024, 1, 8),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }


def gov_stat_task(
        main_file,
        args: list,
        image='docker.io/smtds/spark-py-2.4.7:202202161825P150'
) -> dict:
    """
    Makes SparkApplication
    @return:
    """
    repo_name = GitRepositories.GOV_STAT.repo_name()
    repo_dir = '/'.join([
        '/home/git',
        repo_name
    ])
    main_app_file = repo_dir + main_file
    init_containers = [git_clone_init_container_dict(
        GitRepositories.GOV_STAT,
        get_branch_by_k8s_namespace()
    )]

    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/oracle-jdbc/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "10g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 6,
                "memory": "20g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


def ds_arg():
    template = f"ds if params.run_month == 'yyyy-mm-dd' else params.run_month"
    return '{{ ' + template + ' }}'


with DAG(
    dag_id='gov_stat',
    default_args=get_default_args(),
    params={
        'run_month': 'yyyy-mm-dd',
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 7 8 * *',
    catchup=True,
) as dag:

    # 0 5 8 * *
    check_table = ExternalTaskSensor(
        task_id="check_c360",
        external_dag_id='c360_data_staging_monthly_append',
        external_task_id='backup',
        timeout=100,
        execution_delta=timedelta(hours=2)
    )

    # 0 11 5 * *
    check_table2 = ExternalTaskSensor(
        task_id="check_geolocation",
        external_dag_id='human_stop_monthly_feature',
        external_task_id='spark-livingandworking.monitor_spark',
        timeout=100,
        execution_delta=timedelta(days=2, hours=20)
    )

    task = spark_task(
        dag=dag,
        spark_app_name=f'gov-stat',
        spark_app_spec=gov_stat_task(main_file='/main.py', args=[ds_arg()])
    )
    check_table >> check_table2 >> task