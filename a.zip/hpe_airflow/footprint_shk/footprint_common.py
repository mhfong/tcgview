from utils.airflow_utils import k8s_namespace
def get_branch_by() -> str:
    """
    get the correct git sync branch using the k8s namespace, dev / prod environment is separated by k8s namespace.
    """
    current_airflow_namespace = k8s_namespace()
    return {
        'smt-apps': 'dev',
        'c360-project': 'hpe',
    }[current_airflow_namespace]

def get_env() -> str:
    """
    get the correct git sync branch using the k8s namespace, dev / prod environment is separated by k8s namespace.
    """
    current_airflow_namespace = k8s_namespace()
    return {
        'smt-apps': 'hpe_dev',
        'c360-project': 'hpe',
    }[current_airflow_namespace]