import json
from datetime import datetime

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import SparkKubernetesOperator
from airflow.providers.cncf.kubernetes.sensors.spark_kubernetes import SparkKubernetesSensor
from airflow.utils.dates import days_ago
from airflow.sensors.external_task import ExternalTaskSensor
# try work around as without it, i cannot get it working
# import os, sys
# sys.path.append("/usr/local/airflow/dags/gitdags/dags")
from datetime import timedelta
from utils.spark_spec_utils import EmptyVolume, GitSyncInitContainer, SparkDriver, SparkExecutor, SparkApplication
from utils.git_utils import GitRepositories
from utils.email_utils import send_email
from stop.stop_common import get_branch_by, get_env
from utils.airflow_utils import user_defined_filters, spark_task_group
from utils import airflow_utils
from utils.email_utils import send_email

def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["footprint", "shk", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(1),
        "doc_md": """
                    # SHK Footprint data pipeline
                  """,
        'on_failure_callback': send_email,

        
    }

def run_footprint_with_custom_spark(path_to_py, task_word, raw_data_source = "", affinity:list = None):
    
    EMPTYVOLUME = EmptyVolume("emptydir") # create empty volume called "emptydir"
    mount_path = "/workdir"
    VOLUMEMOUNT={"name": "emptydir", # let emptydir mount on /workdir folder
                "mountPath": mount_path}
    
    INITCONTIANER = GitSyncInitContainer(name="git-sync-footprint",
                                        repo=GitRepositories.FOOTPRINT_SHKP,
                                        destination="footprint",
                                        branch="{{ params.branch }}",
                                        volume_mount_name="emptydir")
    
    DRIVER = SparkDriver(core=2,
                        memory="18g",
                        env = [
                        {"name": "ENVIRONMENT", "value": "{{ params.env }}"},
                        {"name": "TARGET_DATE","value": "{{ params.target_date if params.target_date != '' else ds_nodash }}"},
                        {"name": "DELTA","value": "{{ params.delta }}"},
                        {"name": "DEBUG","value": "{{ params.debug }}"},
                        {"name": "RAW_DATA_SOURCE","value": raw_data_source}
                        ],
                        volumeMounts=[VOLUMEMOUNT],
                        initcontainer=[INITCONTIANER],
                        affinity=affinity
                        )
    
    EXECUTOR = SparkExecutor(core=4, memory="45g", instances=5, env=[], volumeMounts=[VOLUMEMOUNT], affinity=affinity)
    sparkapplication = SparkApplication(driver=DRIVER, executor=EXECUTOR, volumes=[EMPTYVOLUME])
    app_spec=sparkapplication.get_spec(path_to_py=f"{mount_path}/{INITCONTIANER.source_folder_path}/{path_to_py}", generateName=task_word)

    return spark_task_group(
        dag=dag,
        spark_app_name=task_word,
        spark_app_spec=app_spec
    )

def run_save_single_with_custom_spark(path_to_py, task_word):
    
    EMPTYVOLUME = EmptyVolume("emptydir") # create empty volume called "emptydir"
    mount_path = "/workdir"
    VOLUMEMOUNT={"name": "emptydir", # let emptydir mount on /workdir folder
                "mountPath": mount_path}
    
    INITCONTIANER = GitSyncInitContainer(name="git-sync-footprint",
                                        repo=GitRepositories.FOOTPRINT_SHKP,
                                        destination="footprint",
                                        branch="{{ params.branch }}",
                                        volume_mount_name="emptydir")
    
    DRIVER = SparkDriver(core=1,
                        memory="800m",
                        env = [
                        {"name": "ENVIRONMENT", "value": "{{ params.env }}"},
                        {"name": "TARGET_DATE","value": "{{ params.target_date if params.target_date != '' else ds_nodash }}"},
                        {"name": "DELTA","value": "{{ params.delta }}"},
                        {"name": "DEBUG","value": "{{ params.debug }}"}
                        ],
                        volumeMounts=[VOLUMEMOUNT],
                        initcontainer=[INITCONTIANER],
                        )
    
    EXECUTOR = SparkExecutor(core=1, memory="800m", instances=1, env=[], volumeMounts=[VOLUMEMOUNT])
    sparkapplication = SparkApplication(driver=DRIVER, executor=EXECUTOR, volumes=[EMPTYVOLUME])
    app_spec=sparkapplication.get_spec(path_to_py=f"{mount_path}/{INITCONTIANER.source_folder_path}/{path_to_py}", generateName=task_word)

    return spark_task_group(
        dag=dag,
        spark_app_name=task_word,
        spark_app_spec=app_spec
    )

with DAG(
        dag_id='footprint_to_shk_daily_prod',
        default_args=get_default_args(),
        params={
            "debug": "",
            "delta": "0",
            "target_date": "",
            "branch": get_branch_by(), # prod
            "env": get_env()
        },
        catchup=False,
        schedule_interval="00 07 * * *", 
        user_defined_filters=user_defined_filters()
) as dag:
    
    check_geolocation_data_smf_raw_staging = ExternalTaskSensor(
        task_id="check_geolocation_smf",
        external_dag_id='geolocation_smf_n_epg_raw_generate',
        external_task_id='spark-raw-smf.monitor_spark',
        timeout=1800,
        execution_delta=timedelta(minutes=50)
    )

    check_geolocation_data_epg_raw_staging = ExternalTaskSensor(
        task_id="check_geolocation_epg",
        external_dag_id='geolocation_smf_n_epg_raw_generate',
        external_task_id='spark-raw-epg.monitor_spark',
        timeout=1800,
        execution_delta=timedelta(minutes=50)
    )

    old_epg_fp_task = run_footprint_with_custom_spark(
        "scripts/pipeline.py",
        'old-epg',
        raw_data_source="old_epg_data"
    )
    smf_fp_task = run_footprint_with_custom_spark(
        "scripts/pipeline.py",
        '5g-smf',
        raw_data_source="5g_smf_data",
    )

    combine_smf_epg_task = run_footprint_with_custom_spark(
        "scripts/combine_data.py",
        'combine-data'
    )
    create_unhashed_version_task = run_footprint_with_custom_spark(
        "scripts/scripts_save_unhashed_version.py",
        'daily-unhashed'
    )

    to_single_csv_task= run_save_single_with_custom_spark(
        "scripts/transfer_spark_to_single.py",
        'to-single-csv'
    )

    check_geolocation_data_smf_raw_staging >> old_epg_fp_task
    check_geolocation_data_smf_raw_staging >> smf_fp_task

    check_geolocation_data_epg_raw_staging >> old_epg_fp_task
    check_geolocation_data_epg_raw_staging >> smf_fp_task

    old_epg_fp_task >> combine_smf_epg_task
    smf_fp_task >> combine_smf_epg_task
    combine_smf_epg_task >> create_unhashed_version_task >> to_single_csv_task
    

