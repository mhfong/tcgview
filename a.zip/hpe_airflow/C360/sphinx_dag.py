from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import \
    KubernetesPodOperator
from kubernetes.client import models as k8s
from utils.airflow_utils import spark_task_group, user_defined_filters, k8s_namespace
from utils.git_utils import (GitRepositories, get_branch_by_k8s_namespace,
                             git_clone_init_container,
                             git_clone_init_container_dict)


def get_default_args():
    return {
        "owner": "C360 sphinx doc server update",
        "tags": ["C360", "sphinx"],
        "start_date": datetime(2023, 2, 3, 1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
                    # C360 sphinx doc server
                  """,
    }


def c360_pipeline_spark_spec(path_to_py, args):
    init_container = git_clone_init_container_dict(
        repo=GitRepositories.C360,
        branch="bugfix/sphinx-v4"
    )
    transform_spec = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "sphinx-gen-feature-",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "image": "smtds/spark-py-2.4.7-oracle:20230328",
            "imagePullPolicy": "Always",
            "mainApplicationFile": "/home/git/C360" + path_to_py,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": [init_container],
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    },
                    {
                        "name": "sphinx-pvc-vol",
                        "mountPath": "/home/sphinx-pvc-volume"
                    }
                ],
                "shareProcessNamespace": True,
                "env": [
                    {
                        "name": "TARGET_MONTH",
                        "value": "{{ params.target_month }}"
                    },
                    {
                        "name": "DERIVED_FEATURES_OUTPUT_DIR",
                        "value": "{{ params.derived_features_output_dir }}"
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "32g",
                "initContainers": [init_container],
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    },
                    {
                        "name": "sphinx-pvc-vol",
                        "mountPath": "/home/sphinx-pvc-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                },
                {
                    "name": 'sphinx-pvc-vol',
                    'persistentVolumeClaim': {
                        'claimName': 'sphinx-pvc'
                    }
                }
            ]
        }
    }

    return transform_spec

def create_task(dag, task_id, target_month):
    """
    Runs a python command in a pod
    @param dag: dag object
    @param task_id: task id
    @param target_month: for feature list file version
    @return:
    """
    init_container = git_clone_init_container(repo=GitRepositories.C360, branch='bugfix/sphinx-v4')
    # makes the dtap process show up in `ps`
    additional_pod_spec = k8s.V1Pod(
        spec=k8s.V1PodSpec(
            share_process_namespace=True,
            containers=[]
        )
    )
    
    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        '/root/build_c360_airflow.sh'
    ]
    args = ' && '.join(arg)

    return KubernetesPodOperator(
        task_id=task_id,
        labels={
            'hpecp.hpe.com/dtap': 'hadoop2-job',
        },
        namespace=k8s_namespace(),
        image='smtds/sphinx:0.13.1',
        init_containers=[init_container],
        image_pull_secrets='smtds-dockerhub-secret',
        arguments=[args],
        cmds=[
            '/bin/bash', '-c'
        ],
        # need to set this env if using pyarrow
        env_vars=[
            k8s.V1EnvVar(name='ARROW_LIBHDFS_DIR', value='/root/hadoop/lib/native'),
            k8s.V1EnvVar(name='TARGET_MONTH', value=target_month)
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "2", "memory": "2Gi"
            },
            requests={
                "cpu": "2", "memory": "2Gi"
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            ),
            k8s.V1Volume(
                name="sphinx-pvc-volume",
                persistent_volume_claim=k8s.V1PersistentVolumeClaimVolumeSource(
                    claim_name="sphinx-pvc"
                )
            ),
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/tmp/git',
                name="git-volume",
            ),
            k8s.V1VolumeMount(
                mount_path='/home/sphinx-pvc-volume',
                name="sphinx-pvc-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        full_pod_spec=additional_pod_spec,
        execution_timeout=timedelta(minutes=30),
        dag=dag
    )

default_derived_features_output_dir = "dtap://ext_mapr/c360-pipeline/derived"
if k8s_namespace() == "smt-apps":
    default_derived_features_output_dir = "dtap://ext_mapr_ro/c360-pipeline/derived"


with DAG(
        dag_id='c360_sphinx',
        default_args=get_default_args(),
        params={
            "target_month": "2023-08",
            "derived_features_output_dir": default_derived_features_output_dir
        },
        user_defined_filters=user_defined_filters(),
        schedule_interval=None,
        catchup=False,
) as dag:

    gen_feature_list = spark_task_group(
        dag=dag,
        spark_app_name='featurelist',
        spark_app_spec=c360_pipeline_spark_spec(
            '/docs/source/generate_feature_csv.py',
            args=[
                '{{ params.target_month }}',
                '{{ params.derived_features_output_dir }}'
            ]
        )
    )
    
    gen_sphinx_docs = create_task(
        dag=dag,
        task_id="sphinx-docs",
        target_month='{{ params.target_month }}'
    )

    gen_feature_list >>  gen_sphinx_docs
