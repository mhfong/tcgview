import json
from datetime import datetime

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import SparkKubernetesOperator
from airflow.providers.cncf.kubernetes.sensors.spark_kubernetes import SparkKubernetesSensor
from airflow.utils.dates import days_ago
# try work around as without it, i cannot get it working
# import os, sys
# sys.path.append("/usr/local/airflow/dags/gitdags/dags")
from utils.spark_spec_utils import EmptyVolume, GitSyncInitContainer, SparkDriver, SparkExecutor, SparkApplication
from utils.git_utils import GitRepositories, get_branch_by_k8s_namespace
from utils.email_utils import send_email
from utils.airflow_utils import user_defined_filters
from utils import airflow_utils

def get_default_args():
    return {
        "owner": "C360 Team",
        "tags": ["C360", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(45), 
        "email": "walter_sin@smartone.com",
        "doc_md": """
                    # C360 data drift
                  """,
        'on_failure_callback': send_email
    }

def run_data_drift_with_custom_spark(path_to_py, task_word, partition = None):
    if not isinstance(partition, str):
        raise ValueError("partition args should be string data type.")
    current_airflow_namespace = airflow_utils.k8s_namespace()
    env = {
        'smt-apps': 'dev',
        'c360-project': 'prod',
    }[current_airflow_namespace]
    EMPTYVOLUME = EmptyVolume("emptydir") # create empty volume called "emptydir"
    mount_path = "/workdir"
    VOLUMEMOUNT={"name": "emptydir", # let emptydir mount on /workdir folder
                "mountPath": mount_path}
    
    INITCONTIANER = GitSyncInitContainer(name="git-sync-c360-data-drift",
                                        repo=GitRepositories.TEST_DATA_DRIFT,
                                        destination="datadrift",
                                        branch="{{ params.git_branch }}",
                                        volume_mount_name="emptydir")
    
    DRIVER = SparkDriver(core=2,
                        memory="25g",
                        env = [
                        {"name": "TARGET_MONTH","value": "{{ params.target_month if params.target_month != '' else (dag_run.logical_date - macros.timedelta(days=20)).strftime('%Y-%m') }}"},
                        {"name": "FEATURE_PARTITION","value": partition}, # set which part is processing (1,2,3,4)
                        {"name": "KEDRO_ENV","value": env} # set env to load data
                        ],
                        volumeMounts=[VOLUMEMOUNT],
                        initcontainer=[INITCONTIANER]
                        )
    
    EXECUTOR = SparkExecutor(core=5, memory="30g", instances=2, env=[], volumeMounts=[VOLUMEMOUNT])
    sparkapplication = SparkApplication(driver=DRIVER, executor=EXECUTOR, volumes=[EMPTYVOLUME])
    app_spec=sparkapplication.get_spec(path_to_py=f"{mount_path}/{INITCONTIANER.source_folder_path}/{path_to_py}", generateName=f"airflow-c360-data-drift-{task_word}-")

    submit_app = SparkKubernetesOperator(
        task_id='submit_spark_' + task_word,
        namespace=airflow_utils.k8s_namespace(),
        application_file=json.dumps(app_spec, indent=4),
        do_xcom_push=True,
        api_group="sparkoperator.hpe.com",
        enable_impersonation_from_ldap_user=False
    )

    sensor_app = SparkKubernetesSensor(
        task_id='monitor_spark_' + task_word,
        namespace=airflow_utils.k8s_namespace(),
        application_name="{{ task_instance.xcom_pull(task_ids='submit_spark_%s')['metadata']['name'] }}"%task_word,
        api_group="sparkoperator.hpe.com",
        attach_log=True
    )
    return submit_app,sensor_app


with DAG(
        dag_id='c360_monthly_data_drift',
        default_args=get_default_args(),
        params={
            "git_branch": 'master',
            "target_month": "", #20230612
            
        },
        catchup=False,
        schedule_interval= "0 11 17 * *" , # do it at night, run after geolocation raw data is copied to mapr
        user_defined_filters=user_defined_filters()
) as dag:

    submit_app_part1, sensor_app_part1 = run_data_drift_with_custom_spark(
        "data_validation/run.py",
        'monthly-part1',
        partition = "1"
    )

    submit_app_part2, sensor_app_part2 = run_data_drift_with_custom_spark(
        "data_validation/run.py",
        'monthly-part2',
        partition = "2"
    )

    submit_app_part3, sensor_app_part3 = run_data_drift_with_custom_spark(
        "data_validation/run.py",
        'monthly-part3',
        partition = "3"
    )

    submit_app_part4, sensor_app_part4 = run_data_drift_with_custom_spark(
        "data_validation/run.py",
        'monthly-part4',
        partition = "4"
    )


    submit_app_part2 >> sensor_app_part2 >> submit_app_part1 >> sensor_app_part1
    submit_app_part3 >> sensor_app_part3 >> submit_app_part4 >> sensor_app_part4