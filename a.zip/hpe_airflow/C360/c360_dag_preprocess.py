from datetime import datetime
from dateutil.relativedelta import relativedelta
from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group
from C360.c360_dag import c360_pipeline_spark_spec


def get_default_args():
    return {
        "owner": "C360 Team",
        "tags": ["C360", "dev", "pong"],
        "start_date": datetime(2022, 1, 1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
                    # C360 pipeline
                    You can find the source code on [GitLab](https://apgitscpl01.smartone.com/C360_DS_GRP/C360).
                  """,
    }


# compute the default target_month_id
default_month_id = (datetime.now() - relativedelta(months=1)).strftime("%Y-%m")


# dag which only do the derived features part
with DAG(
        dag_id='c360_pipeline_preprocess',
        default_args=get_default_args(),
        params={
            "target_month_id": default_month_id
        },
        user_defined_filters=user_defined_filters(),
        catchup=False,
        schedule_interval=None
) as dag:

    preprocess = spark_task_group(
        dag=dag,
        spark_app_name='preprocess',
        spark_app_spec=c360_pipeline_spark_spec(
            '/airflow_run_pipeline_preprocess.py',
            args=[
                '{{ params.target_month_id }}'
            ]
        )
    )

