
from datetime import datetime

from airflow import DAG
from utils.git_utils import GitSyncOperator, GitSynCleanUpOperator, GitRepositories, GitPvc
from utils.airflow_utils import user_defined_filters, spark_task_group


def get_default_args():
    return {
        "owner": "C360 Team",
        "tags": ["C360"],
        "start_date": datetime(2023, 4, 10),
        "wait_for_downstream ": True,
        # "executor_config": get_pod_spec_mounting_c360_airflow_dependencies(),
        "do_xcom_push": False,
        "doc_md": """
                    # C360 pipeline
                    You can find the source code on [GitLab](https://apgitscpl01.smartone.com/C360_DS_GRP/C360).
                  """,
    }


def c360_pipeline_spark_spec(path_to_py):
    transform_spec = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "airflow-c360-pipeline-spark-",
            "namespace": "c360-project"
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "image": "smtds/spark-py-2.4.7-oracle:20230328",
            "imagePullPolicy": "Always",
            "mainApplicationFile": "/c360-airflow-dependencies-vol/airflow-working-dir/{{ dag.dag_id }}_{{ run_id | sanitize }}/C360" + path_to_py,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "volumeMounts": [
                    {
                        "name": "c360-airflow-dependencies-vol",
                        "mountPath": "/c360-airflow-dependencies-vol"
                    }
                ],
                "shareProcessNamespace": True,
                "env": [
                    {
                        "name": "TARGET_MONTH_ID",
                        "value": "{{ params.target_month_id }}"
                    },
                    {
                        "name": "DERIVED_MODULES",
                        "value": "{{ params.derived_modules }}"
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                }
            },
            "volumes": [
                {
                    "name": "c360-airflow-dependencies-vol",
                    "persistentVolumeClaim": {
                        "claimName": "c360-airflow-dependencies-pvc",
                        "readOnly": True
                    }
                }
            ]
        }
    }

    return transform_spec


with DAG(
    dag_id='c360_pipeline_test',
    default_args=get_default_args(),
    params={
        "git_checkout_target": "dev",
        "target_month_id": '',
        'derived_modules': ''
    },
    user_defined_filters=user_defined_filters(),
    catchup=False
) as dag:

    git_clone_once_for_whole_dag_run = GitSyncOperator(
        repo=GitRepositories.C360,
        branch="{{ params.git_checkout_target }}",
        pvc=GitPvc.C360,
        task_id='git_sync_task'
    )

    git_cleanup_after_whole_dag_run = GitSynCleanUpOperator(
        pvc=GitPvc.C360,
        task_id='git_cleanup_task'
    )

    features_task = spark_task_group(
        dag=dag,
        spark_app_name='derived',
        spark_app_spec=c360_pipeline_spark_spec(
            '/airflow_run_pipeline_derived.py'
        )
    )

    # join_features_task = spark_task_group(
    #     dag=dag,
    #     spark_app_name='bigjoin',
    #     spark_app_spec=c360_pipeline_spark_spec(
    #         '/airflow_run_pipeline_big_join.py'
    #     )
    # )

    git_clone_once_for_whole_dag_run >> features_task >> git_cleanup_after_whole_dag_run
    # git_clone_once_for_whole_dag_run >> join_features_task >> git_cleanup_after_whole_dag_run
