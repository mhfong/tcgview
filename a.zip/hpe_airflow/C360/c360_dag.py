
from datetime import datetime
from dateutil.relativedelta import relativedelta
from airflow import DAG
from utils.git_utils import git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace
from utils.airflow_utils import user_defined_filters, spark_task_group


def get_default_args():
    return {
        "owner": "C360 Team",
        "tags": ["C360"],
        "start_date": datetime(2022, 1, 1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
                    # C360 pipeline
                    You can find the source code on [GitLab](https://apgitscpl01.smartone.com/C360_DS_GRP/C360).
                  """,
    }


def c360_pipeline_spark_spec(path_to_py, args):
    init_container = git_clone_init_container_dict(
        repo=GitRepositories.C360,
        branch=get_branch_by_k8s_namespace()
    )
    transform_spec = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "airflow-c360-pipeline-",
            "namespace": "c360-project"
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "image": "smtds/spark-py-2.4.7-oracle:20230328",
            "imagePullPolicy": "Always",
            "mainApplicationFile": "/home/git/C360" + path_to_py,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": [init_container],
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "shareProcessNamespace": True,
                "env": [
                    {
                        "name": "TARGET_MONTH_ID",
                        "value": "{{ params.target_month_id }}"
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "32g",
                "initContainers": [init_container],
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }

    return transform_spec


# compute the default target_month_id
default_month_id = (datetime.now() - relativedelta(months=1)).strftime("%Y-%m")


with DAG(
    dag_id='c360_pipeline',
    default_args=get_default_args(),
    params={
        "target_month_id": default_month_id,
        'derived_modules': ''
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval=None,
    catchup=False
) as dag:
    preprocess = spark_task_group(
        dag=dag,
        spark_app_name='preprocess',
        spark_app_spec=c360_pipeline_spark_spec(
            '/airflow_run_pipeline_preprocess.py',
            args=[
                '{{ params.target_month_id }}'
            ]
        )
    )

    features_task = spark_task_group(
        dag=dag,
        spark_app_name='derived',
        spark_app_spec=c360_pipeline_spark_spec(
            '/airflow_run_pipeline_derived.py',
            args=[
                '{{ params.target_month_id }}',
                '--derived_modules',
                '{{ params.derived_modules }}'
            ]
        )
    )

    join_features_task = spark_task_group(
        dag=dag,
        spark_app_name='bigjoin',
        spark_app_spec=c360_pipeline_spark_spec(
            '/airflow_run_pipeline_big_join.py',
            args=[
                '{{ params.target_month_id }}',
                'v3_docstring_test'
            ]
        )
    )

    join_features_task_v4 = spark_task_group(
        dag=dag,
        spark_app_name='bigjoin-v4',
        spark_app_spec=c360_pipeline_spark_spec(
            '/airflow_run_pipeline_big_join.py',
            args=[
                '{{ params.target_month_id }}',
                'v4'
            ]
        )
    )

    check_schema = spark_task_group(
        dag=dag,
        spark_app_name='check-schema',
        spark_app_spec=c360_pipeline_spark_spec(
            '/airflow_run_pipeline_check_schema.py',
            args=[
                '{{ params.target_month_id }}'
            ]
        )
    )

    preprocess >> features_task >> join_features_task >> check_schema
    features_task >> join_features_task_v4 >> check_schema
