import re
from datetime import datetime

import pandas as pd
from airflow import DAG
from airflow.utils.dates import days_ago
from utils.airflow_utils import spark_task_group
from utils.git_utils import (GitPvc, GitRepositories, GitSynCleanUpOperator,
                             GitSyncOperator)

from c360_data_staging.spark_spec import great_expectations_spark_spec


def get_default_args():
    return {
        "owner": "C360 Team",
        "tags": ["C360", "great_expectations", "ge"],
        "start_date": days_ago(1),
        "wait_for_downstream ": True,
        # "executor_config": get_pod_spec_mounting_c360_airflow_dependencies(),
        "do_xcom_push": False,
        "doc_md": """
                    # C360 great expectations pipeline
                    You can find the source code on [GitLab](https://apgitscpl01.smartone.com/C360_DS_GRP/C360).
                  """,
    }


# compute the default target_month_id
default_month_id = (datetime.now() - pd.DateOffset(months=1)).strftime("%Y-%m")

with DAG(
        dag_id='c360_great_expectations_gen_suite',
        default_args=get_default_args(),
        params={
            "git_checkout_target": "feature/ge",
            "table_to_validate": "", # keep this value as "" if you want to use module_func_list instead
        },
        user_defined_filters=dict(sanitize=lambda x: re.sub(r'([^-_a-zA-Z0-9])', "_", x)),
        catchup=False,
) as dag:
    
    # git_clone_once_for_whole_dag_run = GitSyncOperator(
    #     repo=GitRepositories.C360,
    #     branch='{{ params.git_checkout_target }}',
    #     pvc=GitPvc.C360_GE,
    #     task_id="git_sync_task"
    # )

    # git_cleanup_after_whole_dag_run = GitSynCleanUpOperator(
    #     pvc=GitPvc.C360_GE,
    #     task_id="git_cleanup_task"
    # )

    spark_task = spark_task_group(
        dag=dag,
        spark_app_name="gen-suite",
        spark_app_spec=great_expectations_spark_spec(
            table_to_validate="{{ params.table_to_validate }}",
            task="profile_datasets",
        )
    )

    spark_task
    # git_clone_once_for_whole_dag_run >> spark_task >> git_cleanup_after_whole_dag_run