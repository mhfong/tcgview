from datetime import datetime

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from utils.git_utils import git_clone_init_container, GitRepositories, get_branch_by_k8s_namespace
from utils.airflow_utils import k8s_namespace, user_defined_filters
from utils.email_utils import send_email
from kubernetes.client import models as k8s
from datetime import datetime, timedelta


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2024, 4, 18),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }

def create_task(task_id, sh_command):
    """
    Runs a python command in a pod
    @param task_id:
    @param python_command:
    @param git_sync_branch: dev or prod
    @return:
    """
    repo_name = GitRepositories.BIRDIE.repo_name()
    init_container = git_clone_init_container(
        repo=GitRepositories.BIRDIE,
        branch=get_branch_by_k8s_namespace()
    )
    arg = [ 
        'sleep 20',
        f'cd /home/git/{repo_name}',
        sh_command
    ]
    args = ' && '.join(arg)

    return KubernetesPodOperator(
        task_id=task_id,
        labels={
            'hpecp.hpe.com/dtap': 'hadoop2-job'
        },
        namespace=k8s_namespace(),
        image='smtds/smt-omms-python:birdie',
        image_pull_secrets='smtds-dockerhub-secret',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        # need to set this env if using pyarrow
        env_vars=[
            k8s.V1EnvVar(name='ENVIRONMENT', value='hpe'),
            k8s.V1EnvVar(name='MODE', value='predict'),
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "8", "memory": "16Gi"
            },
            requests={
                "cpu": "8", "memory": "16Gi"
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=False,
        execution_timeout=timedelta(minutes=60),
    )


def main_task_pod(task_id):

    return create_task(
        task_id,
        f'python predict.py'
    )


with DAG(
        dag_id='birdie_step3',
        default_args=get_default_args(),
        params={
            'run_month': 'yyyymm',
        },
        user_defined_filters=user_defined_filters(),
        schedule_interval='0 10 3 * *',
        catchup=False,
) as dag:

    main_task = main_task_pod('birdie-predict')
    main_task
