from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group
from utils.git_utils import git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace, k8s_namespace
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2024, 4, 18),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }


def birdie_spark_app(
        main_file,
        args: list,
        image='smtds/spark-py-2.4.7-oracle:202104231822AN2'
) -> dict:
    """
    Make SparkApplication for birdie/main.py
    """
    repo_name = GitRepositories.BIRDIE.repo_name()
    repo_dir = '/'.join([
        '/home/git',
        repo_name
    ])
    main_app_file = repo_dir + main_file
    init_containers = [git_clone_init_container_dict(
        GitRepositories.BIRDIE,
        branch=get_branch_by_k8s_namespace()
    )]
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.rpc.message.maxSize": "512"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/oracle-jdbc/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": [
                    {
                        "name": "ORACLE_PASS",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-secret",
                                "key": "password"
                            }
                        }
                    },
                    {
                        "name": "ENVIRONMENT",
                        "value": "hpe"
                    },
                    {
                        "name": "MODE",
                        "value": "snapshot"
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 4,
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": [
                    {
                        "name": "ENVIRONMENT",
                        "value": "hpe"
                    },
                    {
                        "name": "MODE",
                        "value": "snapshot"
                    }
                ]
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app

ds_arg = "{{ ds if params.run_month == 'yyyymm' else params.run_month  }}"

with DAG(
    dag_id='birdie_step1',
    default_args=get_default_args(),
    params={
        'run_month': 'yyyymm',
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='30 6 1 * *',
    catchup=False,
) as dag:

    snapshot = spark_task_group(
        dag=dag,
        spark_app_name='snapshot',
        spark_app_spec=birdie_spark_app(main_file='/main.py', args=[ds_arg])
    )
