
from airflow import DAG
from utils.git_utils import GitSyncOperator, GitSynCleanUpOperator, GitRepositories, GitPvc, get_branch_by_k8s_namespace
from utils.airflow_utils import user_defined_filters, spark_task_group
from c360_data_staging.spark_spec import extract_oracle_main_spark_spec
from c360_data_staging.python_pod_task import create_task
from airflow.utils.dates import days_ago
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["data_staging"],
        "start_date": days_ago(1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """# General path for data staging at date = ds - 2""",
        'on_failure_callback': send_email
    }


DAILY_APPEND_EXTRACT_AT_DS_MINUS_2_DAYS_TABLES = ','.join(['VW_BM_LIS_ROAM_COUNT'])

# airflow templates
start = "{{ params.date_start if params.date_start != '' else macros.ds_add(ds, -2) }}"
end = "{{ params.date_end if params.date_end != '' else macros.ds_add(ds, -2) }}"
daily_tables = "{{ params.table_filter if params.table_filter != '' else '" + DAILY_APPEND_EXTRACT_AT_DS_MINUS_2_DAYS_TABLES + "' }}"


def backup_task_pod(
        task_id, 
        date_start, date_end,
        extract_strategy, 
        table_filter=None
):
    cmd = f'python -m backup_oracle_extracts_main {date_start} {date_end} -s {extract_strategy} -d GENERAL'
    if table_filter:
         cmd += f' -t {table_filter}'
    return create_task(
        task_id,
        cmd,
        git_sync_branch=get_branch_by_k8s_namespace()
    )


def validate_task_pod(
        task_id, 
        date_start, date_end,
        extract_strategy, 
        table_filter=None
):
    cmd = f'python -m validate_oracle_extracts_main {date_start} {date_end} -s {extract_strategy} -d GENERAL'
    if table_filter:
         cmd += f' -t {table_filter}'
    return create_task(
        task_id,
        cmd,
        git_sync_branch=get_branch_by_k8s_namespace()
    )


with DAG(
    dag_id='general_data_staging_daily',
    default_args=get_default_args(),
    params={
        "date_start": "",
        "date_end": "",
        "table_filter": ""
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 0 * * *',
    catchup=False,
) as dag:

    git_clone_once_for_whole_dag_run = GitSyncOperator(
        repo=GitRepositories.C360_DATA_STAGING,
        branch=get_branch_by_k8s_namespace(),
        pvc=GitPvc.C360_STAGING,
        task_id='git_sync_task'
    )

    git_cleanup_after_whole_dag_run = GitSynCleanUpOperator(
        pvc=GitPvc.C360_STAGING,
        task_id='git_cleanup_task',
    )
    spark_task = spark_task_group(
        dag=dag,
        spark_app_name='stg-overwrite',
        spark_app_spec=extract_oracle_main_spark_spec(
            date_start=start,
            date_end=end,
            extract_strategy='OVERWRITE',
            table_filter="",
            destination_filter="GENERAL"
        )
    )
    validate = validate_task_pod(
        'validate-overwrite',
        start, end,
        extract_strategy='OVERWRITE'
    )
    backup = backup_task_pod(
        'backup-overwrite',
        start, end,
        extract_strategy='OVERWRITE'
    )
    git_clone_once_for_whole_dag_run >> spark_task >> validate >> backup >> git_cleanup_after_whole_dag_run

    daily_append = spark_task_group(
        dag=dag,
        spark_app_name='stg-daily-append',
        spark_app_spec=extract_oracle_main_spark_spec(
            date_start=start,
            date_end=end,
            extract_strategy='DAILY_APPEND',
            table_filter=daily_tables,
            destination_filter="GENERAL"
        )
    )
    daily_append_validate = validate_task_pod(
        'validate-daily', 
        start, end,
        extract_strategy='DAILY_APPEND', table_filter=daily_tables
    )
    daily_append_backup = backup_task_pod(
        'backup-daily', 
        start, end,
        extract_strategy='DAILY_APPEND', table_filter=daily_tables
    )
    git_clone_once_for_whole_dag_run >> daily_append >> daily_append_validate >> daily_append_backup >> git_cleanup_after_whole_dag_run

