import json
from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import (
    SparkKubernetesOperator,
)
from airflow.providers.cncf.kubernetes.sensors.spark_kubernetes import (
    SparkKubernetesSensor,
)
from airflow.utils.dates import days_ago
from utils.git_utils import GitRepositories
from utils.airflow_utils import user_defined_filters, spark_task_group
from utils.spark_spec_utils import (
    EmptyVolume,
    GitSyncInitContainer,
    SparkDriver,
    SparkExecutor,
    SparkApplication,
)
from stop.stop_common import get_branch_by, get_env
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["humanstop", "shk", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(45),
        "doc_md": """
                    # Human stop data pipeline
                  """,
        'on_failure_callback': send_email
    }


def run_humanstop_with_custom_spark(path_to_py: str, task_word: str, mode: str):
    EMPTYVOLUME = EmptyVolume("emptydir")  # create empty volume called "emptydir"
    mount_path = "/workdir"
    VOLUMEMOUNT = {
        "name": "emptydir",  # let emptydir mount on /workdir folder
        "mountPath": mount_path,
    }

    INITCONTIANER = GitSyncInitContainer(
        name="git-sync-humanstop",
        repo=GitRepositories.GEOLOCATION_STOP,
        destination="humanstop",
        branch="{{ params.git_branch }}",
        volume_mount_name="emptydir",
    )

    DRIVER = SparkDriver(
        core=2,
        memory="4g",
        env=[
        ],
        volumeMounts=[VOLUMEMOUNT],
        initcontainer=[INITCONTIANER],
    )

    EXECUTOR = SparkExecutor(
        core=1, memory="22g", instances=3, env=[], volumeMounts=[VOLUMEMOUNT]
    )
    sparkapplication = SparkApplication(
        driver=DRIVER, executor=EXECUTOR, volumes=[EMPTYVOLUME]
    )
    app_spec = sparkapplication.get_spec(
        path_to_py=f"{mount_path}/{INITCONTIANER.source_folder_path}/{path_to_py}",
        generateName=f"airflow-humanstop-feature-m-{task_word}",
        args=[
            "--target_month","{{ params.target_month if params.target_month != '' else (dag_run.logical_date).strftime('%Y%m') }}",
            "--maintask", "human",
            "--mode", mode,
            "--environment", "{{ params.env }}"
        ]
    )
    spark_task = spark_task_group(
        dag=dag, spark_app_name=task_word, spark_app_spec=app_spec
    )
    return spark_task


with DAG(
    dag_id="human_stop_monthly_feature",
    default_args=get_default_args(),
    params={
        "git_branch": get_branch_by(),
        "target_month": "",  # 202306
        "env": get_env(),
    },
    catchup=False,
    schedule_interval="0 11 5 * *",  # do it in the evening
    user_defined_filters=user_defined_filters(),
) as dag:

    spark_task_travel = run_humanstop_with_custom_spark(
        "scripts/pipeline_feature.py", "travel", "MONTHLY_DISTANCE_TRAVEL"
    )
    spark_task_stay = run_humanstop_with_custom_spark(
        "scripts/pipeline_feature.py", "stay", "MONTHLY_STAY"
    )
    spark_task_living_and_working = run_humanstop_with_custom_spark(
        "scripts/pipeline_feature.py", "livingandworking", "MONTHLY_LIVING_WORKING"
    )
    spark_task_days_stay_at_hk = run_humanstop_with_custom_spark(
        "scripts/pipeline_feature.py", "daysstayathk", "MONTHLY_STAY_AT_HK"
    )
    spark_task_movementcount = run_humanstop_with_custom_spark(
        "scripts/pipeline_feature.py", "movementcount", "MONTHLY_MOVEMENTCOUNT"
    )
    spark_task_movementratio_out_of_living_district = run_humanstop_with_custom_spark(
        "scripts/pipeline_feature.py", "movementratio", "MonthlyStopRatioOutsideLivingDistirct"
    )
    spark_task_travel >> spark_task_stay >> spark_task_living_and_working >> spark_task_days_stay_at_hk \
        >> spark_task_movementcount >> spark_task_movementratio_out_of_living_district
