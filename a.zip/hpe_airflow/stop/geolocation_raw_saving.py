import json
from datetime import datetime

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import SparkKubernetesOperator
from airflow.providers.cncf.kubernetes.sensors.spark_kubernetes import SparkKubernetesSensor
from airflow.utils.dates import days_ago
# try work around as without it, i cannot get it working
# import os, sys
# sys.path.append("/usr/local/airflow/dags/gitdags/dags")
from utils.spark_spec_utils import EmptyVolume, GitSyncInitContainer, SparkDriver, SparkExecutor, SparkApplication
from utils.git_utils import GitRepositories
from utils.email_utils import send_email
from stop.stop_common import get_branch_by, get_env
from utils.airflow_utils import user_defined_filters, spark_task_group
from utils import airflow_utils

def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["humanstop", "shk", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(1),
        "doc_md": """
                    # geolocation raw grouping data pipeline
                  """,
        'on_failure_callback': send_email
    }

def run_geogroup_with_custom_spark(path_to_py, task_word):
    
    EMPTYVOLUME = EmptyVolume("emptydir") # create empty volume called "emptydir"
    mount_path = "/workdir"
    VOLUMEMOUNT={"name": "emptydir", # let emptydir mount on /workdir folder
                "mountPath": mount_path}
    
    INITCONTIANER = GitSyncInitContainer(name="git-sync-geolocation-raw",
                                        repo=GitRepositories.GEOLOCATION_STOP,
                                        destination="geolocation_raw",
                                        branch="{{ params.git_branch }}",
                                        volume_mount_name="emptydir")
    
    DRIVER = SparkDriver(core=2,
                        memory="10g",
                        env = [
                        ],
                        volumeMounts=[VOLUMEMOUNT],
                        initcontainer=[INITCONTIANER]
                        )
    
    EXECUTOR = SparkExecutor(core=2, memory="45g", instances=2, env=[], volumeMounts=[VOLUMEMOUNT])
    sparkapplication = SparkApplication(driver=DRIVER, executor=EXECUTOR, volumes=[EMPTYVOLUME])
    app_spec=sparkapplication.get_spec(path_to_py=f"{mount_path}/{INITCONTIANER.source_folder_path}/{path_to_py}", generateName=task_word,
                                       args=[
                                           "--target_date", "{{ params.target_date if params.target_date != '' else ds_nodash }}",
                                            "--maintask", "human",
                                            "--mode", "{{ params.mode }}",
                                            "--environment", "{{ params.env }}"
                                        ]
                                       )

    return spark_task_group(
        dag=dag,
        spark_app_name=task_word,
        spark_app_spec=app_spec
    )


with DAG(
        dag_id='geolocation_raw_grouping',
        default_args=get_default_args(),
        params={
            "git_branch": get_branch_by(),
            "target_date": "", #20230612
            "env": get_env(),
            "mode": "SaveGroupedRawTask"
            
        },
        catchup=False,
        schedule_interval= "45 10 * * *" , # do it at night, run after geolocation raw data is copied to mapr
        user_defined_filters=user_defined_filters()
) as dag:

    geolocation_daily_grouping = run_geogroup_with_custom_spark(
        "scripts/pipeline_main.py",
        'raw-grouping',
    )

    geolocation_daily_grouping