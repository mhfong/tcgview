import json
from datetime import datetime

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import SparkKubernetesOperator
from airflow.providers.cncf.kubernetes.sensors.spark_kubernetes import SparkKubernetesSensor
from airflow.utils.dates import days_ago
# try work around as without it, i cannot get it working
# import os, sys
# sys.path.append("/usr/local/airflow/dags/gitdags/dags")
from utils.spark_spec_utils import EmptyVolume, GitSyncInitContainer, SparkDriver, SparkExecutor, SparkApplication
from utils.git_utils import GitRepositories
from utils.email_utils import send_email
from stop.stop_common import get_branch_by, get_env
from utils.airflow_utils import user_defined_filters, spark_task_group, spark_task
from utils import airflow_utils

def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["humanstop", "shk", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(1),
        "doc_md": """
                    # Human stop data pipeline
                  """,
        'on_failure_callback': send_email
    }

def run_humanstop_with_custom_spark(path_to_py, task_word):
    
    EMPTYVOLUME = EmptyVolume("emptydir") # create empty volume called "emptydir"
    mount_path = "/workdir"
    VOLUMEMOUNT={"name": "emptydir", # let emptydir mount on /workdir folder
                "mountPath": mount_path}
    
    INITCONTIANER = GitSyncInitContainer(name="git-sync-humanstop",
                                        repo=GitRepositories.GEOLOCATION_STOP,
                                        destination="humanstop",
                                        branch="{{ params.git_branch }}",
                                        volume_mount_name="emptydir")
    
    DRIVER = SparkDriver(core=2,
                        memory="13g",
                        env = [
                        ],
                        volumeMounts=[VOLUMEMOUNT],
                        initcontainer=[INITCONTIANER]
                        )
    
    EXECUTOR = SparkExecutor(core=2, memory="35g", instances=3, env=[], volumeMounts=[VOLUMEMOUNT])
    sparkapplication = SparkApplication(driver=DRIVER, executor=EXECUTOR, volumes=[EMPTYVOLUME])
    app_spec=sparkapplication.get_spec(path_to_py=f"{mount_path}/{INITCONTIANER.source_folder_path}/{path_to_py}",
                                       generateName=task_word,
                                       args=[
                                           "--target_date", "{{ params.target_date if params.target_date != '' else ds_nodash }}",
                                            "--maintask", "human",
                                            "--mode", "{{ params.mode }}",
                                            "--environment", "{{ params.env }}",
                                            "--must_read_oracle_db", "{{ params.must_read_db }}"])

    return spark_task(
        dag=dag,
        spark_app_name=task_word,
        spark_app_spec=app_spec
    )


with DAG(
        dag_id='human_stop_prod',
        default_args=get_default_args(),
        params={
            "git_branch": get_branch_by(),
            "target_date": "", #20230612
            "env": get_env(),
            "mode": "FULL",
            "must_read_db": "true"
            
        },
        catchup=False,
        schedule_interval= "40 14 * * *" , # do it at night, run after geolocation raw data is copied to mapr
        user_defined_filters=user_defined_filters()
) as dag:

    humanstop_daily = run_humanstop_with_custom_spark(
        "scripts/pipeline_main.py",
        'daily',
    )

    humanstop_daily