import json

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import SparkKubernetesOperator
from airflow.providers.cncf.kubernetes.sensors.spark_kubernetes import SparkKubernetesSensor
from airflow.utils.dates import days_ago

from utils import airflow_utils
# try work around as without it, i cannot get it working
# import os, sys
# sys.path.append("/usr/local/airflow/dags/gitdags/dags")
from utils.airflow_utils import user_defined_filters


def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["churnmodel", "sunny"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(1),
        "doc_md": """
                    # churn model test
                  """,
    }

def run_churn_model_data_etl(task_word):

    app_spec = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "airflow-churn-mdoel",
            "namespace": "{{ params.namespace }}"
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "image": "smtds/spark-py-2.4.7-oracle:202104231822AN3",
            "imagePullPolicy": "Always",
            "mainApplicationFile": "/workdir/git-repo/notebook/data_etl_main.py",
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 1,
                "coreLimit": "1000m",
                "memory": "10g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "volumeMounts": [
                    {
                        "name": "git-pvc-churn-model-volume",
                        "mountPath": "/workdir"
                    }
                ],
                "env": [
                   {
                        "name": "ENVIRONMENT",
                        "value": "hpe"
                   }
                ]
            },
            "executor": {
                "cores": 2,
                "coreLimit": "2000m",
                "instances": 2,
                "memory": "10g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "volumeMounts": [
                    {
                        "name": "git-pvc-churn-model-volume",
                        "mountPath": "/workdir"
                    }
                ]
            },
            "volumes": [
                {
                    "name": "git-pvc-churn-model-volume",
                    "persistentVolumeClaim": {
                        "claimName": "git-pvc-churn-model"
                     }
                }
            ]
        }
    }
    
    submit_app = SparkKubernetesOperator(
        task_id='submit_spark_' + task_word,
        namespace=airflow_utils.k8s_namespace(),
        application_file=json.dumps(app_spec, indent=4),
        do_xcom_push=True,
        api_group="sparkoperator.hpe.com",
        enable_impersonation_from_ldap_user=False
    )

    sensor_app = SparkKubernetesSensor(
        task_id='monitor_spark_' + task_word,
        namespace=airflow_utils.k8s_namespace(),
        application_name="{{ task_instance.xcom_pull(task_ids='submit_spark_%s')['metadata']['name'] }}"%task_word,
        api_group="sparkoperator.hpe.com",
        attach_log=True
    )
    return submit_app,sensor_app

with DAG(
        dag_id='churn_model_data_etl',
        default_args=get_default_args(),
        params={
            "namespace": airflow_utils.k8s_namespace(),
            "git_branch": "hpe",
            "target_date": "", #20230612
            "env": "hpe",
            "mode": "FULL"
        },
        catchup=False,
        schedule_interval= "40 14 * * *" , # do it at night, run after geolocation raw data is copied to mapr
        user_defined_filters=user_defined_filters()
) as dag:

    submit_app, sensor_app = run_churn_model_data_etl(
        'test'
    )

    submit_app >> sensor_app
    
