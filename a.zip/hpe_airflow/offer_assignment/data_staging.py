
from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark3_task, k8s_namespace
from airflow.utils.dates import days_ago
from utils.email_utils import send_email
from utils.git_utils import (
    git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace
)
from typing import Optional


def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["data_staging"],
        "start_date": days_ago(1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """# Data staging for offer assignment jobs""",
        # 'on_failure_callback': send_email
    }


def git_tag_name():
    v = ''
    if get_branch_by_k8s_namespace() == 'prod':
        return v



def offer_assignment_jobs_spark_task(
        main_file: str,
        args: list,
        version: Optional[str],
        image='docker.io/smtds/spark-py-3.1.2:202202161825P150'
) -> dict:
    """
    Makes SparkApplication
    @return:
    """
    repo_name = GitRepositories.OFFER_ASSIGNMENT_JOBS.repo_name()
    repo_dir = 'local://' + '/'.join([
        '/home/git',
        repo_name
    ])
    main_app_file = repo_dir + main_file
    init_containers = [git_clone_init_container_dict(
        GitRepositories.OFFER_ASSIGNMENT_JOBS,
        get_branch_by_k8s_namespace(),
        tag=version
    )]

    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "3.1.2",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/mapr/spark/spark-3.1.2/external_jars/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "10g",
                "labels": {
                    "version": "3.1.2",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "work-dir",
                        "mountPath": "/home/work"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": [
                    {
                        "name": "ORACLE_PASSWORD",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-secret",
                                "key": "password"
                            }
                        }
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 3,
                "memory": "10g",
                "labels": {
                    "version": "3.1.2",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "work-dir",
                        "mountPath": "/home/work"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "work-dir",
                    "persistentVolumeClaim": {
                        # TODO make a new PVC
                        "claimName": 'llama-test-pvc',
                        "readOnly": False
                    }
                },
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


with DAG(
    dag_id='offer_assignment_data_staging',
    default_args=get_default_args(),
    params={
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 4 1 * *',
    catchup=False,
) as dag:

    stage = spark3_task(
        dag=dag,
        spark_app_name='stage',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_oracle_tables.py',
            args=['--partition_month {{ ds }}'],
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )

    stage2 = spark3_task(
        dag=dag,
        spark_app_name='stage2',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_oracle_tables.py',
            args=['--snapshot_date {{ next_ds }}'],
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )