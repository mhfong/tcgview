
from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark3_task, k8s_namespace, airflow_job_labels
from airflow.utils.dates import days_ago
from offer_assignment.data_staging import offer_assignment_jobs_spark_task
from utils.git_utils import get_branch_by_k8s_namespace
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from utils.git_utils import GitRepositories, get_branch_by_k8s_namespace, git_clone_init_container
from utils.airflow_utils import k8s_namespace
from airflow.hooks.base import BaseHook
from datetime import timedelta


def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["data_staging"],
        "start_date": days_ago(1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """# Generate plans for offer assignment""",
        # 'on_failure_callback': send_email
    }


def git_tag_name():
    v = 'todo replace'
    if get_branch_by_k8s_namespace() == 'prod':
        return v


def spark_pipeline_args():
    tag = git_tag_name()
    version = tag if tag else 'dev'
    return [
        version
    ]


def django_command_task(task_id, django_command, product_version = 'dev'):
    """
    Runs a django command in a pod
    @param task_id:
    @param django_command:
    @return:
    """
    repo_name = GitRepositories.OFFER_ASSIGNMENT_WEB.repo_name()
    init_container = git_clone_init_container(
        repo=GitRepositories.OFFER_ASSIGNMENT_WEB, branch=get_branch_by_k8s_namespace()
    )
    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        f'cd /home/git/{repo_name}/offerassignmentsite',
        django_command
    ]
    args = ' && '.join(arg)
    mysql_username = BaseHook.get_connection('offer_assignment_mysql').login
    labels = airflow_job_labels()
    labels['hpecp.hpe.com/dtap'] = 'hadoop2-job'
    return KubernetesPodOperator(
        task_id=task_id,
        labels=labels,
        namespace=k8s_namespace(),
        image='smtds/offer-assignment-web:latest',
        image_pull_secrets='smtds-dockerhub-secret',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        env_from=[k8s.V1EnvFromSource(
            secret_ref=k8s.V1SecretEnvSource(
                name='offer-assignment-web-secrets'
            )
        )],
        env_vars=[
            k8s.V1EnvVar(name='ENV_NAME', value=get_branch_by_k8s_namespace()),
            k8s.V1EnvVar(name='PIPELINE_VERSION_PLAN_GENERATION', value=product_version),
            k8s.V1EnvVar(name='PIPELINE_VERSION_OFFER_ASSIGNMENT', value='dev'),
            k8s.V1EnvVar(name='MYSQL_USER', value=mysql_username),
            k8s.V1EnvVar(name='CLASSPATH', value_from=k8s.V1EnvVarSource(
                config_map_key_ref=k8s.V1ConfigMapKeySelector(
                    key='CLASSPATH',
                    name='offer-assignment-hadoop-classpath'
                )
            )),
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "8", "memory": '16Gi'
            },
            requests={
                "cpu": "8", "memory": '16Gi'
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        execution_timeout=timedelta(minutes=60)
    )


with DAG(
    dag_id='offer_assignment_gen_plans',
    default_args=get_default_args(),
    params={

    },
    user_defined_filters=user_defined_filters(),
    schedule_interval=None,
    catchup=False,
) as dag:
    web_show_this_product_version = 'dev'

    stage = spark3_task(
        dag=dag,
        spark_app_name='base-plans',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_base_plans.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )

    cms_import = django_command_task(
        'import-base-plans',
        'python manage.py import_base_plans',
        web_show_this_product_version
    )
    
    stage_for_coupon_n_gifts = spark3_task(
        dag=dag,
        spark_app_name='coupon-gifts',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_coupon_n_gifts.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )

    import_gifts_coupons = django_command_task(
        'import-gifts-coupons',
        'python manage.py import_gifts_coupons',
        web_show_this_product_version
    )

    stage_for_extra_data = spark3_task(
        dag=dag,
        spark_app_name='extra-data',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_extra_local_data.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )
    import_extra_local_data = django_command_task(
        'import-extra-data',
        'python manage.py import_extra_local_data',
        web_show_this_product_version
    )

    stage_for_vas = spark3_task(
        dag=dag,
        spark_app_name='vas',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_vas.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )
    import_vas = django_command_task(
        'import-vas',
        'python manage.py import_value_added_service',
        web_show_this_product_version
    )

    stage_for_roaming = spark3_task(
        dag=dag,
        spark_app_name='roaming',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_roaming.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )
    import_roaming = django_command_task(
        'import-roaming',
        'python manage.py import_roaming',
        web_show_this_product_version
    )

    gen = spark3_task(
        dag=dag,
        spark_app_name='gen-plans',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_generate_plans.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )
    import_plans = django_command_task(
        'import-plans',
        'python manage.py import_plans',
        web_show_this_product_version
    )
    import_choices = django_command_task(
        'import-choice',
        'python manage.py import_choices',
        web_show_this_product_version
    )

    stage >> cms_import
    stage_for_coupon_n_gifts >> import_gifts_coupons
    stage_for_extra_data >> import_extra_local_data
    stage_for_vas >> import_vas
    stage_for_roaming >> import_roaming
    gen >> import_plans
    gen >> import_choices
    
    stage >> gen
    stage_for_coupon_n_gifts >> gen
    stage_for_extra_data >> gen
    stage_for_vas >> gen