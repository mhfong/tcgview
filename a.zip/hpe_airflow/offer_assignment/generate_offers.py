
from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark3_task, k8s_namespace, airflow_job_labels
from airflow.utils.dates import days_ago
from offer_assignment.data_staging import offer_assignment_jobs_spark_task
from offer_assignment.generate_plans import django_command_task
from utils.git_utils import get_branch_by_k8s_namespace
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from utils.git_utils import GitRepositories, get_branch_by_k8s_namespace, git_clone_init_container
from utils.airflow_utils import k8s_namespace
from airflow.hooks.base import BaseHook
from datetime import timedelta


def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["data_staging"],
        "start_date": days_ago(1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """# Generate plans for offer assignment""",
        # 'on_failure_callback': send_email
    }


def git_tag_name():
    v = 'todo replace'
    if get_branch_by_k8s_namespace() == 'prod':
        return v


def spark_pipeline_args():
    tag = git_tag_name()
    version = tag if tag else 'dev'
    return [
        "{{ dag_run.start_date.isoformat() }}",
        '{{ params.run_name }}',
        '{{ params.contract_month_ends }}',
        version,
    ]


def django_pipeline_args() -> list:
    tag = git_tag_name()
    version = tag if tag else 'dev'
    return [
        version
    ]


with DAG(
    dag_id='offer_assignment_gen_offers',
    default_args=get_default_args(),
    params={
        "contract_month_ends": "",
        "run_name": ""
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval=None,
    catchup=False,
) as dag:
    
    ass = spark3_task(
        dag=dag,
        spark_app_name='rec',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_recommend_plans.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )

    import_ass = django_command_task(
        'import-ass',
        'python manage.py import_assignment_run'
    )

    ass >> import_ass
