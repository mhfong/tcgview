
from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark3_task, k8s_namespace, airflow_job_labels
from airflow.utils.dates import days_ago
from offer_assignment.data_staging import offer_assignment_jobs_spark_task
from utils.git_utils import get_branch_by_k8s_namespace
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from utils.git_utils import GitRepositories, get_branch_by_k8s_namespace, git_clone_init_container
from utils.airflow_utils import k8s_namespace
from airflow.hooks.base import BaseHook
from datetime import timedelta
from offer_assignment.generate_plans import spark_pipeline_args, git_tag_name, django_command_task


def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["data_staging"],
        "start_date": days_ago(1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """# Generate plans for offer assignment""",
        # 'on_failure_callback': send_email
    }


with DAG(
    dag_id='offer_assignment_gen_plans_demo',
    default_args=get_default_args(),
    params={

    },
    user_defined_filters=user_defined_filters(),
    schedule_interval=None,
    catchup=False,
) as dag:
    web_show_this_product_version = 'dev'

    stage = spark3_task(
        dag=dag,
        spark_app_name='base-plans',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_base_plans.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )

    cms_import = django_command_task(
        'import-base-plans',
        'python manage.py import_base_plans',
        web_show_this_product_version
    )
    
    stage_for_coupon_n_gifts = spark3_task(
        dag=dag,
        spark_app_name='coupon-gifts',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_coupon_n_gifts.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )

    import_gifts_coupons = django_command_task(
        'import-gifts-coupons',
        'python manage.py import_gifts_coupons',
        web_show_this_product_version
    )

    stage_for_extra_data = spark3_task(
        dag=dag,
        spark_app_name='extra-data',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_extra_local_data.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )
    import_extra_local_data = django_command_task(
        'import-extra-data',
        'python manage.py import_extra_local_data',
        web_show_this_product_version
    )

    stage_for_roaming = spark3_task(
        dag=dag,
        spark_app_name='roaming',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_get_roaming.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )
    import_roaming = django_command_task(
        'import-roaming',
        'python manage.py import_roaming',
        web_show_this_product_version
    )

    gen = spark3_task(
        dag=dag,
        spark_app_name='gen-plans',
        spark_app_spec=offer_assignment_jobs_spark_task(
            main_file='/pipeline_generate_plans.py',
            args=spark_pipeline_args(),
            version=git_tag_name(),
            image='smtds/spark-py-3.1.2-oracle:20230330b'
        )
    )
    import_plans = django_command_task(
        'import-plans',
        'python manage.py import_plans',
        web_show_this_product_version
    )
    import_choices = django_command_task(
        'import-choice',
        'python manage.py import_choices',
        web_show_this_product_version
    )

    stage >> cms_import
    stage_for_coupon_n_gifts >> import_gifts_coupons
    stage_for_extra_data >> import_extra_local_data
    stage_for_roaming >> import_roaming
    gen >> import_plans
    gen >> import_choices
    
    stage >> gen
    stage_for_coupon_n_gifts >> gen
    stage_for_extra_data >> gen