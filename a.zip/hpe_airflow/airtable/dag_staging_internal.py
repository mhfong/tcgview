import json
from datetime import datetime

from airflow import DAG
from airflow.decorators import dag, task
from airflow.models.param import ParamsDict
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from utils.git_utils import git_clone_init_container, GitRepositories, get_branch_by_k8s_namespace
from kubernetes.client import models as k8s
from airflow.utils.dates import days_ago
# try work around as without it, i cannot get it working
# import os, sys
# sys.path.append("/usr/local/airflow/dags/gitdags/dags")
from utils.airflow_utils import user_defined_filters, spark_task_group, spark_task, airflow_job_labels, k8s_namespace, get_registry_proxy
from utils.email_utils import send_email
from datetime import timedelta
def ds_arg(offset):
    template = "macros.ds_format( macros.ds_add(ds, " + str(offset) + "), '%Y-%m-%d', '%Y%m%d' ) if params.run_date == 'yyyymmdd' else params.run_date"
    return '{{ ' + template + ' }}'

def add_arg(cmd:str, arg: str, value):
    return " ".join([cmd, f"{arg}={value}"])

def convert_list_to_args(arg_name, target_list: list):
    cmd = ""
    if len(target_list) != 0:
        for table in target_list:
            cmd = " ".join([cmd, arg_name + table])
    return cmd

def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["airtable", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(2),
        "doc_md": """
                    # airtable data staging
                  """,
        'on_failure_callback': send_email
    }
def get_staging_pod(task_id: str,args: list):
# git sync into empty directory
    volume_name = "workdir"
    python_file_path = "main.py"
    volume = k8s.V1Volume(name=volume_name,empty_dir=k8s.V1EmptyDirVolumeSource())
    git_env = {
        'GIT_SYNC_REPO': GitRepositories.AIRTABLE_DATA_STAGING.value,
        'GIT_SYNC_USERNAME': "dw_dwsup_04@smartone.com",
        'GIT_SYNC_PERMISSIONS': "0755",
        'GIT_SYNC_PASSWORD_FILE': '/etc/secret-volume/git-password-file',
        'GIT_SYNC_DEST': "airtable",
        'GIT_SYNC_ROOT': f"/workdir" + "/airflow-working-dir/",
        'GIT_SYNC_BRANCH': get_branch_by_k8s_namespace(),
        'GIT_SYNC_ONE_TIME': 'true',
        "GIT_SYNC_GIT_CONFIG": "http.sslVerify:false",
        }

    git_env = [k8s.V1EnvVar(name=k, value=v) for k, v in git_env.items()]

    # secret key
    git_env.append(k8s.V1EnvVar(
        name = "GIT_SYNC_PASSWORD",
        value_from = k8s.V1EnvVarSource (
            secret_key_ref = k8s.V1SecretKeySelector(
                            name="airflow-gitrepo-password",
                            key="password"
            )
        )
    ))

    git_sync_init_container = k8s.V1Container(
            name =  "git-sync",
            image= "{domain}/git-sync/git-sync:v3.3.4".format(domain = get_registry_proxy()["k8s.gcr.io"]),
            resources=k8s.V1ResourceRequirements(
                limits={
                    "cpu": "500m", "memory": "600Mi"
                },
                requests={
                    "cpu": "400m", "memory": "600Mi"
                }
            ),
            volume_mounts=[
                k8s.V1VolumeMount(
                    mount_path=f"/workdir",
                    name=volume_name,
                ),
            ],
            env=git_env

        )
    # makes the dtap process show up in `ps`
    additional_pod_spec = k8s.V1Pod(
        spec=k8s.V1PodSpec(
            share_process_namespace=True,
            containers=[]
            )
        )
    
    # set the bash/command after the pods has establish
    arg = args

    
    args = ' && '.join(arg)
    return KubernetesPodOperator(
                    namespace=k8s_namespace(),
                    image="{domain}/smtds/python-airtable-dtap:v0.0.3".format(domain=get_registry_proxy()["dockerhub"]),
                    cmds=['/bin/bash','-c'],
                    arguments=[args],
                    labels={"hpecp.hpe.com/dtap": "hadoop2-job"},
                    name=task_id,
                    task_id=task_id,
                    get_logs=True,
                    volumes=[volume],
                    image_pull_secrets= 'regcred', # for access to private registry
                    volume_mounts = [k8s.V1VolumeMount(
                                                    name = volume_name,
                                                    mount_path = f"/workdir"
                                                    )
                                    ],
                    init_containers = [git_sync_init_container],
                    is_delete_operator_pod =True,
                    full_pod_spec=additional_pod_spec,
                    resources=k8s.V1ResourceRequirements(
                        limits={"cpu": "1000m", "memory": "8Gi"},
                        requests={"cpu": "1000m", "memory": "8Gi"}
                    ),
                    env_vars=[
                                k8s.V1EnvVar(name='AIRTABLE_EXTERNAL_PERSONAL_TOKEN', value_from=k8s.V1EnvVarSource(
                                    secret_key_ref=k8s.V1SecretKeySelector(
                                        key="AIRTABLE_ACCESS_TOKEN", 
                                        name="airtable-external-tables-secret")
                                )),
                                k8s.V1EnvVar(name='AIRTABLE_OFFER_PACK_PERSONAL_TOKEN', value_from=k8s.V1EnvVarSource(
                                    secret_key_ref=k8s.V1SecretKeySelector(
                                        key="AIRTABLE_ACCESS_TOKEN", 
                                        name="airtable-offer-pack-secret")
                                ))
                            ],
                    retries=1,
                    retry_delay=timedelta(minutes=10),
                    dag=dag
                )
with DAG(
    dag_id = 'airtable_data_staging_internal', 
    default_args=get_default_args(),
    schedule_interval="0 23 * * *",
    catchup=False,
    user_defined_macros = {
        "convert_list_to_args": convert_list_to_args
    },
    params={
        'run_date': 'yyyymmdd',
        'target_tables': []
    }
)as dag:

    python_file_path = "python3 /workdir/airflow-working-dir/airtable/main.py"
    python_cmd = add_arg(python_file_path, "--RUN_DATE", ds_arg(2))
    python_cmd = add_arg(python_cmd, "--SERVE_FOR_WHO", "internal")
    python_cmd += " " + "{{ convert_list_to_args('--SPECIFIC_AIRTABLE_LOAD=', params.target_tables) }}"
    print(python_cmd)
    call_image = get_staging_pod(task_id="extract-tables",
                                args=["sleep 20s", # wait for dtap sidecar to become ready
                                python_cmd
                                ])
    call_image