from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from kubernetes.client import models as k8s
from utils.git_utils import git_clone_init_container, GitRepositories, get_branch_by_k8s_namespace
from utils.airflow_utils import k8s_namespace, get_registry_proxy
from utils.email_utils import send_email

def get_default_args():
    return {
        "owner": "GZ EDM team",
        "start_date": datetime(2025, 1, 21),
        "wait_for_downstream": True,
        "do_xcom_push": False,
        "doc_md": "# airtable data staging"
       # 'on_failure_callback': send_email
    }

def get_staging_pod(task_id: str, command: str) -> KubernetesPodOperator:
    volumes = [
        k8s.V1Volume(name="git-volume", empty_dir=k8s.V1EmptyDirVolumeSource()),
        k8s.V1Volume(name='secret-volume', secret=k8s.V1SecretVolumeSource(secret_name="git-password-secret"))
    ]


    REPO_NAME = GitRepositories.LOAD_AIRTABLE_DATA_TO_ADW.repo_name()
    SCRIPT_REPO_PATH = f"/home/git/{REPO_NAME}/src"
    
    git_sync_init_container = git_clone_init_container(
        repo=GitRepositories.LOAD_AIRTABLE_DATA_TO_ADW,
        branch=get_branch_by_k8s_namespace()
    )
    
    return KubernetesPodOperator(
        namespace=k8s_namespace(),
        image="{domain}/smtds/smt-omms-python:1.0.2".format(domain=get_registry_proxy()["dockerhub"]),
        cmds=['/bin/bash', '-c'],
        arguments=[command],
        labels={"hpecp.hpe.com/dtap": "hadoop2-job"},
        name=task_id,
        task_id=task_id,
        get_logs=True,
        volumes=volumes,
        image_pull_secrets='regcred',
        volume_mounts = [k8s.V1VolumeMount(name = 'git-volume',mount_path = '/home/git')],
        init_containers=[git_sync_init_container],
        is_delete_operator_pod=True,
        resources=k8s.V1ResourceRequirements(
            limits={"cpu": "1000m", "memory": "8Gi"},
            requests={"cpu": "1000m", "memory": "8Gi"}
        ),
        env_vars=[
            k8s.V1EnvVar(name='ORACLE_USERNAME', value_from=k8s.V1EnvVarSource(
                secret_key_ref=k8s.V1SecretKeySelector(
                    key="username",
                    name="dw-oracle-secret")
            )),
            k8s.V1EnvVar(name='ORACLE_PASSWORD', value_from=k8s.V1EnvVarSource(
                secret_key_ref=k8s.V1SecretKeySelector(
                    key="password",
                    name="dw-oracle-secret")
            )),
            k8s.V1EnvVar(name='ORACLE_DSN', value_from=k8s.V1EnvVarSource(
                secret_key_ref=k8s.V1SecretKeySelector(
                    key="dsn",
                    name="dw-oracle-secret")
            )),
            k8s.V1EnvVar(name='PUBLIC_PATH', value=f"{SCRIPT_REPO_PATH}") 
        ],
        retries=1,
        retry_delay=timedelta(minutes=10),
        dag=dag
    )

with DAG(
    dag_id='dw_load_airtable',
    default_args=get_default_args(),
    schedule_interval="30 00 * * *",
    catchup=False,
    params={
        'run_date': 'yyyymmdd',
    }
) as dag:
    
    REPO_NAME = GitRepositories.LOAD_AIRTABLE_DATA_TO_ADW.repo_name()
    SCRIPT_REPO_PATH = f"/home/git/{REPO_NAME}/src"

    python_files = [
        f"python3 {SCRIPT_REPO_PATH}/ext_cdb_mapping/ext_cdb_mapping.py",
        f"python3 {SCRIPT_REPO_PATH}/ext_hs_class_ref/ext_hs_class_ref.py",
        f"python3 {SCRIPT_REPO_PATH}/ext_offerpack/ext_offerpack.py"
    ]

    task1 = get_staging_pod(task_id="dw_cdb_mapping", command=python_files[0])
    task2 = get_staging_pod(task_id="dw_hs_class_ref", command=python_files[1])
    task3 = get_staging_pod(task_id="dw_offerpack", command=python_files[2])