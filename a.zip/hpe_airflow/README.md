# hpe_airflow

DAGs for Airflow on HPE

Dev: https://dsecp-gateway.hksmartone.com:10217/home

Prod: https://dsecp-gateway.hksmartone.com:10216/home

## Development Guide
1. Checkout a feature branch from the `dev` branch in this repo.
2. Add your changes to the feature branch, create an MR to merge your features to `dev`.
3. Test DAG on dev airflow.
4. Create MR to merge to `prod`.


### Operators
Only use these 2 operators inside your DAGs, defined in `utils.airflow_utils.py`:
- `SmartSparkK8sOperator` for launching SparkApplication (CRD) on k8s. 

> Do not use directly, use via `spark_task(...)` function.

- `SmartPodOperator` for launching k8s Pods.

### Logs
In order for us to easily find logs in elastic search, you must apply airflow specific labels to your airflow k8s resources. Use this function `utils.airflow_utils.airflow_job_labels`.


Check the Rendenered Template page on task pages to access logs in EFK.

### Git Sync
k8s resources launched by `SmartSparkK8sOperator` and `SmartPodOperator` will need a [Git sync init container](https://github.com/kubernetes/git-sync) to download code from your Git project before the main container executes, use the following functions in `utils.git_utils.py` to generate the init containers needed:
- `git_clone_init_container`
- `git_clone_init_container_as_dict`

1. All Git projects your DAG uses must have branches named `dev` or `prod` for development and production environment.
2. Add new Git projects in `utils.git_utils.py`.


### Sample DAG
- `SmartPodOperator`: https://apgitscpl01.smartone.com/ds_datascience_grp/hpe_airflow/-/blob/dev/backup_project_repo.py

- `SmartSparkK8sOperator`: https://apgitscpl01.smartone.com/ds_datascience_grp/hpe_airflow/-/blob/dev/subscriber_features/gov_stat_monthly.py
