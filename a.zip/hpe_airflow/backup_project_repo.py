from datetime import datetime
from airflow import DAG
from utils.airflow_utils import user_defined_filters, SmartPodOperator, airflow_job_labels
from utils.airflow_utils import k8s_namespace
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from datetime import timedelta
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "tags": [],
        "start_date": datetime(2024, 1, 25),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """""",
        'on_failure_callback': send_email
    }


def backup(task_id):

    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        'cd /home',

        "find /bd-fs-mnt/project_repo \( -name '*.py' -o -name '*.ipynb' \) -and -not -path '*/.ipynb_checkpoints/*' | tar -zcf backup.tar.gz -T -",
        'hdfs dfs -copyFromLocal -f backup.tar.gz dtap://TenantStorage/backup/project_repo/{{ ds }}_backup.tar.gz',
        'rm backup.tar.gz'
    ]
    args = ' && '.join(arg)

    labels = airflow_job_labels()
    labels['hpecp.hpe.com/dtap'] = 'hadoop2-job'
    return SmartPodOperator(
        task_id=task_id,
        labels=labels,
        namespace=k8s_namespace(),
        image='smtds/segmentation-web:latest',
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        env_vars=[
            k8s.V1EnvVar(name='CLASSPATH', value_from=k8s.V1EnvVarSource(
                config_map_key_ref=k8s.V1ConfigMapKeySelector(
                    key='CLASSPATH',
                    name='segmentation-hadoop-classpath'
                )
            )),
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "8", "memory": '16Gi'
            },
            requests={
                "cpu": "8", "memory": '16Gi'
            }
        ),
        volumes=[
            k8s.V1Volume(
                name='project-repo',
                host_path=k8s.V1HostPathVolumeSource(
                    path=f'/opt/bluedata/share/{k8s_namespace()}',
                    type='DirectoryOrCreate'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/bd-fs-mnt',
                name="project-repo",
                mount_propagation='HostToContainer'
            ),
        ],

        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        execution_timeout=timedelta(minutes=20)
    )


with DAG(
        dag_id='backup_project_repo',
        default_args=get_default_args(),
        params={
        },
        user_defined_filters=user_defined_filters(),
        catchup=False,
        schedule_interval='0 4,10 * * *'
) as dag:
    backup(task_id='backup')
