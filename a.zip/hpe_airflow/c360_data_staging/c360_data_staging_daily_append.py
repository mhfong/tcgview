
from datetime import datetime

from airflow import DAG
from utils.git_utils import GitSyncOperator, GitSynCleanUpOperator, GitRepositories, GitPvc, get_branch_by_k8s_namespace
from utils.airflow_utils import user_defined_filters, spark_task_group
from c360_data_staging.spark_spec import extract_oracle_main_spark_spec
from c360_data_staging.python_pod_task import create_task
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "C360 data staging Team",
        "tags": ["C360", "data_staging", "dev", "pong"],
        "start_date": datetime(2023, 3, 1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
                    # C360 data staging pipeline
                  """,
        'on_failure_callback': send_email
    }


# TABLE_FILTER = ','.join([
#     'VW_BILLED_CALL_RECS',
#     'VW_USER_LOCATION_LOG_DTL',
#     'VW_END_USER_MSC_CALL_DTL',
#     'VW_OM_CHG_PLAN',
#     'VW_BM_LIS_ROAM_COUNT'
# ])

def backup_task_pod(task_id):
    start = "{{ params.date_start if params.date_start != '' else macros.ds_add(ds, -2) }}"
    end = "{{ params.date_end if params.date_end != '' else macros.ds_add(ds, -2) }}"
    destination = "{{ params.destination_filter if params.destination_filter != '' else '' }}"

    return create_task(
        task_id,
        f'python -m backup_oracle_extracts_main {start} {end} -s DAILY_APPEND -d {destination}',
        git_sync_branch=get_branch_by_k8s_namespace()
    )


def validate_task_pod(task_id):
    start = "{{ params.date_start if params.date_start != '' else macros.ds_add(ds, -2) }}"
    end = "{{ params.date_end if params.date_end != '' else macros.ds_add(ds, -2) }}"
    destination = "{{ params.destination_filter if params.destination_filter != '' else '' }}"
    
    return create_task(
        task_id,
        f'python -m validate_oracle_extracts_main {start} {end} -s DAILY_APPEND -d {destination}',
        git_sync_branch=get_branch_by_k8s_namespace()
    )


with DAG(
    dag_id='c360_data_staging_daily_append',
    default_args=get_default_args(),
    params={
        "date_start": "",
        "date_end": "",
        "table_filter": "",
        "destination_filter": "C360"
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 0 * * *',
    catchup=False,
) as dag:

    git_clone_once_for_whole_dag_run = GitSyncOperator(
        repo=GitRepositories.C360_DATA_STAGING,
        branch=get_branch_by_k8s_namespace(),
        pvc=GitPvc.C360_STAGING,
        task_id='git_sync_task'
    )

    git_cleanup_after_whole_dag_run = GitSynCleanUpOperator(
        pvc=GitPvc.C360_STAGING,
        task_id='git_cleanup_task'
    )
    spark_task = spark_task_group(
        dag=dag,
        spark_app_name='staging',
        spark_app_spec=extract_oracle_main_spark_spec(
            date_start="{{ params.date_start if params.date_start != '' else macros.ds_add(ds, -2) }}",
            date_end="{{ params.date_end if params.date_end != '' else macros.ds_add(ds, -2) }}",
            extract_strategy='DAILY_APPEND',
            table_filter="{{ params.table_filter if params.table_filter != '' else '' }}",
            destination_filter="{{ params.destination_filter if params.destination_filter != '' else '' }}",
        )
    )
    validate = validate_task_pod('validate')
    backup = backup_task_pod('backup')
    
    git_clone_once_for_whole_dag_run >> spark_task >> git_cleanup_after_whole_dag_run >> validate >> backup