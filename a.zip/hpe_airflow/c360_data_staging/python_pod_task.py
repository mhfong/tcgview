

from utils.git_utils import git_clone_init_container, GitRepositories
from utils.airflow_utils import airflow_job_labels
from utils.airflow_utils import k8s_namespace
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from datetime import timedelta
from airflow.utils.trigger_rule import TriggerRule


def create_task(task_id, python_command, git_sync_branch):
    """
    Runs a python command in a pod
    @param task_id:
    @param python_command:
    @param git_sync_branch: dev or prod
    @return:
    """
    repo_name = GitRepositories.C360_DATA_STAGING.repo_name()
    init_container = git_clone_init_container(repo=GitRepositories.C360_DATA_STAGING, branch=git_sync_branch)
    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        f'cd /home/git/{repo_name}',
        python_command
    ]
    args = ' && '.join(arg)
    # makes the dtap process show up in `ps`
    additional_pod_spec = k8s.V1Pod(
        spec=k8s.V1PodSpec(
            share_process_namespace=True,
            containers=[]
        )
    )
    labels = airflow_job_labels()
    labels['hpecp.hpe.com/dtap'] = 'hadoop2-job'
    return KubernetesPodOperator(
        task_id=task_id,
        labels=labels,
        namespace=k8s_namespace(),
        image='smtds/python310-hadoop2102-dtap:latest',
        image_pull_secrets='smtds-dockerhub-secret',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        # need to set this env if using pyarrow
        env_vars=[
            k8s.V1EnvVar(name='ARROW_LIBHDFS_DIR', value='/root/hadoop/lib/native')
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "1", "memory": "1Gi"
            },
            requests={
                "cpu": "1", "memory": "1Gi"
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        full_pod_spec=additional_pod_spec,
        execution_timeout=timedelta(minutes=30),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS
    )
