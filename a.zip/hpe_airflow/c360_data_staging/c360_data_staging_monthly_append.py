
from datetime import datetime

from airflow import DAG
from utils.git_utils import GitSyncOperator, GitSynCleanUpOperator, GitRepositories, GitPvc, get_branch_by_k8s_namespace
from utils.airflow_utils import user_defined_filters, spark_task_group, get_str_list_chunk, user_defined_macros
from c360_data_staging.spark_spec import extract_oracle_main_spark_spec
from c360_data_staging.python_pod_task import create_task
from airflow.operators.python import BranchPythonOperator
from utils.email_utils import send_email

def get_default_args():
    return {
        "owner": "C360 data staging Team",
        "tags": ["C360", "data_staging", "dev", "pong"],
        "start_date": datetime(2023, 3, 8, 5),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
                    # C360 data staging pipeline
                  """,
        'on_failure_callback': send_email
    }


# monthly append batch #1
TABLE_FILTER1 = ','.join([
    'VW_MYACCT_SERVICE_LOG',
    'VW_NETFLIX_DCB_USG',
    'VW_PRO_CUST_OFFER_STATUS',
    'VW_SHK_POSTPAID_MASTER_SUMM',
    'VW_SHKDS_PROFILE_H',
    'VW_SMC_CARE_LOG',
    'VW_TICKET_CALL_RECS',
    'VW_IDP_CRD_TOTAL_ML',
    'VW_USUBR_HS_ALL_SUMM',
    'VW_PREPD_POST_MOVE',
    'VW_BM_LIS_ROAM_COUNT',
    'VW_FULLDS_SUMM_SUBR_CE6'
])

# monthly append batch #2
TABLE_FILTER2 = ','.join([
    'VW_SUBR_LOYALTY_MARKER_HIST',
    'VW_EDM_ACTION_LOG',
    'VW_FES_CONTACT_HIST_DTL',
    'VW_FES_CONTACT_HIST_HEADER',
    'VW_GOOGLE_DCB_USG',
    'VW_BILL_SERVS',
    'VW_IDP_CUST_COMPLAINT_HIST',
    'VW_IDP_CUST_ENQUIRY_HIST',
    'VW_IDP_PORTIN_DETAILS',
    'VW_ITUNE_DCB_USG',
    'VW_MPS_MKTPGM_EDM_URL',
    'VW_CDB_TRX_ALLPRICE_HIST'
])


def branch_spark_tasks(user_provided_table_filter):
    """
    Splits the table filter lists between two spark tasks if table filter is provided through params.
    @param user_provided_table_filter:
    @return:
    """
    if user_provided_table_filter != '' and user_provided_table_filter is not None:
        chunk1 = get_str_list_chunk(user_provided_table_filter, num_chunks=2, chunk_index=0)
        chunk2 = get_str_list_chunk(user_provided_table_filter, num_chunks=2, chunk_index=1)
        tasks = []
        if chunk1 is not None:
            tasks.append('spark-stg-1.submit_spark')

        if chunk2 is not None:
            tasks.append('spark-stg-2.submit_spark')

        return tasks

    else:
        return ['spark-stg-1.submit_spark', 'spark-stg-2.submit_spark']


def backup_task_pod(task_id):
    # month start end
    start = "{{ params.date_start if params.date_start != '' else macros.ds_add(ds, -7) }}"
    end = "{{ params.date_end if params.date_end != '' else macros.ds_add(next_ds, -8) }}"
    destination = "{{ params.destination_filter if params.destination_filter != '' else '' }}"

    return create_task(
        task_id,
        f'python -m backup_oracle_extracts_main {start} {end} -s MONTHLY_APPEND -d {destination}',
        git_sync_branch=get_branch_by_k8s_namespace()
    )


def validate_task_pod(task_id):
    # month start end
    start = "{{ params.date_start if params.date_start != '' else macros.ds_add(ds, -7) }}"
    end = "{{ params.date_end if params.date_end != '' else macros.ds_add(next_ds, -8) }}"
    destination = "{{ params.destination_filter if params.destination_filter != '' else '' }}"

    return create_task(
        task_id,
        f'python -m validate_oracle_extracts_main {start} {end} -s MONTHLY_APPEND -d {destination}',
        git_sync_branch=get_branch_by_k8s_namespace()
    )


with DAG(
    dag_id='c360_data_staging_monthly_append',
    default_args=get_default_args(),
    params={
        "date_start": "",
        "date_end": "",
        "table_filter": "",
        "destination_filter": "C360"
    },
    user_defined_filters=user_defined_filters(),
    user_defined_macros=user_defined_macros(),
    schedule_interval='0 5 8 * *',
    catchup=False,
) as dag:

    git_clone_once_for_whole_dag_run = GitSyncOperator(
        repo=GitRepositories.C360_DATA_STAGING,
        branch=get_branch_by_k8s_namespace(),
        pvc=GitPvc.C360_STAGING,
        task_id='git_sync_task'
    )

    git_cleanup_after_whole_dag_run = GitSynCleanUpOperator(
        pvc=GitPvc.C360_STAGING,
        task_id='git_cleanup_task'
    )
    
    spark_task1 = spark_task_group(
        dag=dag,
        spark_app_name='stg-1',
        spark_app_spec=extract_oracle_main_spark_spec(
            # month start
            date_start="{{ params.date_start if params.date_start != '' else macros.ds_add(ds, -7) }}",
            # month end
            date_end="{{ params.date_end if params.date_end != '' else macros.ds_add(next_ds, -8) }}",
            extract_strategy='MONTHLY_APPEND',
            table_filter="{{ get_str_list_chunk(params.table_filter, num_chunks=2, chunk_index=0) if params.table_filter != '' else '" + TABLE_FILTER1 + "' }}",
            destination_filter="{{ params.destination_filter if params.destination_filter != '' else '' }}",
        )
    )
    spark_task2 = spark_task_group(
        dag=dag,
        spark_app_name='stg-2',
        spark_app_spec=extract_oracle_main_spark_spec(
            # month start
            date_start="{{ params.date_start if params.date_start != '' else macros.ds_add(ds, -7) }}",
            # month end
            date_end="{{ params.date_end if params.date_end != '' else macros.ds_add(next_ds, -8) }}",
            extract_strategy='MONTHLY_APPEND',
            table_filter="{{ get_str_list_chunk(params.table_filter, num_chunks=2, chunk_index=1) if params.table_filter != '' else '" + TABLE_FILTER2 + "' }}",
            destination_filter="{{ params.destination_filter if params.destination_filter != '' else '' }}",
        )
    )

    branch_op = BranchPythonOperator(
        task_id='branch_spark_tasks',
        python_callable=branch_spark_tasks,
        op_kwargs={
            'user_provided_table_filter': '{{ params.table_filter }}'
        }
    )

    validate = validate_task_pod('validate')
    backup = backup_task_pod('backup')
    git_clone_once_for_whole_dag_run >> branch_op
    branch_op >> [spark_task1, spark_task2] >> git_cleanup_after_whole_dag_run
    git_cleanup_after_whole_dag_run >> validate >> backup