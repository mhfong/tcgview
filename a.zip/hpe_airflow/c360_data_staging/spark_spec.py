
from utils.git_utils import GitRepositories, GitPvc, MOUNT_PATHS, k8s_namespace


def extract_oracle_main_spark_spec(
        date_start,
        date_end,
        table_filter,
        extract_strategy,
        destination_filter,
        image='smtds/spark-py-2.4.7-oracle:20230614'
) -> dict:
    """
    Makes SparkApplication for c360_data_staging/extract_oracle_main.py
    @param date_start:
    @param date_end:
    @param table_filter:
    @param extract_strategy:
    @return:
    """
    repo_name = GitRepositories.C360_DATA_STAGING.repo_name()
    repo_dir = '/'.join([
        MOUNT_PATHS[GitPvc.C360_STAGING],
        "airflow-working-dir",
        "{{ dag.dag_id }}_{{ run_id | sanitize }}",
        repo_name
    ])
    main_app_file = repo_dir + '/extract_oracle_main.py'
    # spark + pyarrow + dateutil + ojdbc8-21.9.0.0.jar + cx-Oracle
    # image = 'smtds/spark-py-2.4.7-oracle:20230328'
    # image = 'smtds/spark-py-2.4.7-oracle:20230614'
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/oracle-jdbc/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "volumeMounts": [
                    {
                        "name": "c360-airflow-dependencies-vol",
                        "mountPath": MOUNT_PATHS[GitPvc.C360_STAGING]
                    }
                ],
                "env": [
                    {
                        "name": "DATE_START",
                        "value": date_start
                    },
                    {
                        "name": "DATE_END",
                        "value": date_end
                    },
                    {
                        "name": "TABLE_FILTER",
                        "value": table_filter
                    },
                    {
                        "name": "EXTRACT_STRATEGY",
                        "value": extract_strategy
                    },
                    {
                        "name": "DESTINATION_FILER",
                        "value": destination_filter
                    },
                    {
                        "name": "ORACLE_PASS",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-secret",
                                "key": "password"
                            }
                        }
                    },
                    {
                        "name": "CNSS_ORACLE_PASS",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-cnss-secret",
                                "key": "password"
                            }
                        }
                    },
                    {
                        "name": "TEMP_CSV_WORKDIR",
                        "value": repo_dir
                    },
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "volumeMounts": [
                    {
                        "name": "c360-airflow-dependencies-vol",
                        "mountPath": MOUNT_PATHS[GitPvc.C360_STAGING]
                    }
                ]
            },
            "volumes": [
                {
                    "name": "c360-airflow-dependencies-vol",
                    "persistentVolumeClaim": {
                        "claimName": GitPvc.C360_STAGING.value,
                        "readOnly": False
                    }
                }
            ]
        }
    }
    return spark_app


def great_expectations_spark_spec(
    table_to_validate,
    module_func_list=None, 
    target_month_id=None,
    task="run_checkpoint"
) -> dict:
    """
    Makes SparkApplication for c360/great_expectation run checkpoint
    @param module_func_list:
    @param table_to_validate:
    @param target_month_id:
    @return:
    """
    repo_name = GitRepositories.C360.repo_name()
    repo_dir = '/'.join([
        MOUNT_PATHS[GitPvc.C360_GE],
        "git-sync-root",
        repo_name
        # "airflow-working-dir",
        # "{{ dag.dag_id }}_{{ run_id | sanitize }}",
        # repo_name
    ])
    main_app_file = repo_dir + f'/great_expectations/hpe/dev_smt_apps/{task}/{task}_dev.py'
    image = 'gcr.io/mapr-252711/spark-py-2.4.7:202104010902C'
    
    # env list
    env_list = [
            {
                "name": "MAIN_VOLUME_PATH",
                "value": MOUNT_PATHS[GitPvc.C360_GE]
            },
            {
                "name": "DATA_DOCS_SITES_DIR",
                "value":  MOUNT_PATHS[GitPvc.C360_GE] + "/great_expectations_data_docs/local_site/"
            },
            {
                "name": "VALIDATIONS_STORE_DIR",
                "value": MOUNT_PATHS[GitPvc.C360_GE] + "/great_expectations_validations_store/"
            },
            {
                "name": "DTAP_TABLE_PATH",
                "value": table_to_validate
            },
        ]

    if module_func_list:
        env_list.append(
            {
                "name": "MODULE_FUNC_LIST",
                "value": module_func_list
            }
        )
    if target_month_id:
        env_list.append(
            {
                "name": "TARGET_MONTH_ID",
             "value": target_month_id
            }
        )

    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "volumeMounts": [
                    {
                        "name": "great-expectations-pvc-vol",
                        "mountPath": MOUNT_PATHS[GitPvc.C360_GE]
                    }
                ],
                "shareProcessNamespace": True,
                "env": env_list,
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                }
            },
            "volumes": [
                {
                    "name": "great-expectations-pvc-vol",
                    "persistentVolumeClaim": {
                        "claimName": GitPvc.C360_GE.value
                    }
                }
            ]
        }
    }

    return spark_app
