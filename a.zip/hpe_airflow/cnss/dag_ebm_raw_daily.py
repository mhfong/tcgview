from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group
from utils.git_utils import git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace, k8s_namespace
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2025, 1, 1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }


def ebm_raw_daily(
        main_file,
        args: list,
        image='smtds/spark-py-2.4.7-oracle:20231103airtable'
) -> dict:
    """
    Make SparkApplication for CNSS/pipeline_ebm_for_persona.py
    """
    repo_name = GitRepositories.CNSS.repo_name()
    repo_dir = '/'.join([
        '/home/git',
        repo_name
    ])
    main_app_file = repo_dir + main_file
    init_containers = [git_clone_init_container_dict(
        GitRepositories.CNSS,
        branch=get_branch_by_k8s_namespace()
    )]
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/oracle-jdbc/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "20g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": [
                    {
                        "name": "ORACLE_SECRET",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-secret",
                                "key": "password"
                            }
                        }
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 5,
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": [
                    {
                        "name": "ENVIRONMENT",
                        "value": "hpe"
                    },
                    {
                        "name": "MODE",
                        "value": "feature"
                    }
                ]
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app

ds_arg = "{{ macros.ds_add(ds, -2) if params.run_date == 'yyyymmdd' else params.run_date  }}"

with DAG(
    dag_id='ebm_raw_daily',
    default_args=get_default_args(),
    params={
        'run_date': 'yyyymmdd',
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 2 * * *',
    catchup=False,
) as dag:

    ebm = spark_task_group(
        dag=dag,
        spark_app_name='ebm-raw-daily',
        spark_app_spec=ebm_raw_daily(main_file='/pipeline_raw.py', args=[ds_arg])
    )

    ebm