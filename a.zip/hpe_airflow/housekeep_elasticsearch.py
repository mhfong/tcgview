from utils.git_utils import git_clone_init_container, GitRepositories, get_branch_by_k8s_namespace
from utils.airflow_utils import k8s_namespace, user_defined_filters
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from datetime import datetime, timedelta
from airflow.utils.trigger_rule import TriggerRule
from airflow import DAG

def create_task(task_id, sh_command):
    """
    Runs a python command in a pod
    @param task_id:
    @param python_command:
    @param git_sync_branch: dev or prod
    @return:
    """
    repo_name = GitRepositories.HPE_CUSTOM.repo_name()
    init_container = git_clone_init_container(repo=GitRepositories.HPE_CUSTOM, branch="master")
    arg = [ 
        f'cd /home/git/{repo_name}',
        sh_command
    ]
    args = ' && '.join(arg)
    # makes the dtap process show up in `ps`
    additional_pod_spec = k8s.V1Pod(
        spec=k8s.V1PodSpec(
            share_process_namespace=True,
            containers=[]
        )
    )
    return KubernetesPodOperator(
        task_id=task_id,
        labels={
            'hpecp.hpe.com/dtap': 'hadoop2-job'
        },
        namespace=k8s_namespace(),
        image_pull_secrets='smtds-dockerhub-secret',
        image='smtds/python310-hadoop2102-dtap:latest',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        # need to set this env if using pyarrow
        env_vars=[
            k8s.V1EnvVar(name='ARROW_LIBHDFS_DIR', value='/root/hadoop/lib/native'),
            k8s.V1EnvVar(name='ELASTIC_USERNAME', value='elastic'),
            k8s.V1EnvVar(name='ELASTIC_PASSWORD', value_from=k8s.V1EnvVarSource(secret_key_ref=k8s.V1SecretKeySelector(key="ELASTIC_PASSWORD", name="elasticsearch-master-credientials")))
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "1", "memory": "400Mi"
            },
            requests={
                "cpu": "1", "memory": "400Mi"
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        full_pod_spec=additional_pod_spec,
        execution_timeout=timedelta(minutes=60),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS
    )


def get_default_args():
    return {
        "owner": "Elasticsearch Team",
        "tags": ["Elasticsearch", "dev", "pong"],
        "start_date": datetime(2023, 2, 3, 1),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
                    # Elasticsearch housekeeping pipeline
                  """
    }


def main_task_pod(task_id):

    return create_task(
        task_id,
        f'/bin/bash efk/housekeep_k8s_logs.sh'
    )


with DAG(
        dag_id='elasticsearch_housekeeping',
        default_args=get_default_args(),
        params={
            "snapshot_date": "",
            "table_filter": "",
            "destination_filter": "smt-apps"
        },
        user_defined_filters=user_defined_filters(),
        schedule_interval='0 5 * * *',
        catchup=False,
) as dag:

    main_task = main_task_pod('Housekeeping')
    main_task
