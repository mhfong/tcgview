from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group, k8s_namespace
from utils.git_utils import k8s_namespace, git_clone_init_container_dict, get_branch_by_k8s_namespace, GitRepositories
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2023, 2, 3),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }


def make_run_id(dag_run_id):
    return dag_run_id[:dag_run_id.index('T') + 8]


def run_month_id_template():
    return """{{ 
        params.run_month_id if params.run_month_id != 'yyyy-mm' 
        else (macros.datetime.now() - macros.dateutil.relativedelta.relativedelta(months=1)).strftime('%Y-%m') 
    }}""".replace('\n', '')


def create_5ghbb_spark_app(
        main_file,
        image='smtds/spark-py-2.4.7-oracle:20231103commonutil'
) -> dict:
    """
    Makes SparkApplication for 5GHBB
    @return:
    """
    run_month_id = run_month_id_template()
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"

    init_containers = [git_clone_init_container_dict(
        GitRepositories.WEBLOG_5GHBB,
        branch=get_branch_by_k8s_namespace()
    )]

    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/oracle-jdbc/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": '/home/git/' + GitRepositories.WEBLOG_5GHBB.repo_name() + main_file,
            "arguments": [run_month_id, run_id],
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": [
                    {
                        "name": "ORACLE_PASS",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-secret",
                                "key": "password"
                            }
                        }
                    },
                    {
                        "name": "CNSS_ORACLE_PASS",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-cnss-secret",
                                "key": "password"
                            }
                        }
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


filters = user_defined_filters()
filters['make_run_id'] = make_run_id

with DAG(
    dag_id='monthly-5ghbb',
    default_args=get_default_args(),
    params={
        'run_month_id': 'yyyy-mm',
        "pipeline_run_id": "prod",
    },
    user_defined_filters=filters,
    schedule_interval='0 7 5 * *',
    catchup=False,
) as dag:
    tag_level = spark_task_group(
        dag=dag,
        spark_app_name='taglv',
        spark_app_spec=create_5ghbb_spark_app(main_file='/step1_tag_level_weblog_data.py')
    )
    subr_level = spark_task_group(
        dag=dag,
        spark_app_name='subrlv',
        spark_app_spec=create_5ghbb_spark_app(main_file='/step2_subr_level_weblog_data.py')
    )
    persona_subr_list = spark_task_group(
        dag=dag,
        spark_app_name='result',
        spark_app_spec=create_5ghbb_spark_app(main_file='/step3_persona_subr_list.py')
    )

    tag_level >> subr_level >> persona_subr_list