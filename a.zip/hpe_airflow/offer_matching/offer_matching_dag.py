
from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group, k8s_namespace
from offer_matching.python_pod_task import create_offer_matching_task
from utils.git_utils import GitRepositories, git_clone_init_container_dict


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2023, 2, 3),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        # Offer Matching DAG 
        """,
    }


def make_run_id(dag_run_id):
    return dag_run_id[:dag_run_id.index('T') + 8]


def retention_report(task_id):
    # dates are not needed for overwrite, use ds
    run_month_id = "{{ params.run_month_id }}"
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"
    return create_offer_matching_task(
        task_id,
        f'python -m scripts.01a_training_data {run_month_id} {run_id}',
        git_sync_branch='feature/kubeflow'
    )


def training_data(task_id, type_of_model):
    # dates are not needed for overwrite, use ds
    run_month_id = "{{ params.run_month_id }}"
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"
    return create_offer_matching_task(
        task_id,
        f'python -m scripts.01b_training_data {run_month_id} {run_id} {type_of_model}',
        git_sync_branch='feature/kubeflow',
        memory='32Gi'
    )


def offer_pack_airtable(task_id):
    run_month_id = "{{ params.run_month_id }}"
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"
    return create_offer_matching_task(
        task_id,
        f'python -m scripts.03a_export_airtables {run_month_id} {run_id}',
        git_sync_branch='feature/kubeflow'
    )


def make_scoring_data(task_id, type_of_model):
    run_month_id = "{{ params.run_month_id }}"
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"
    return create_offer_matching_task(
        task_id,
        f'python -m scripts.03b_make_scoring_data {run_month_id} {run_id} {type_of_model}',
        git_sync_branch='feature/kubeflow'
    )


def prepare_business_rules_data(task_id):
    run_month_id = "{{ params.run_month_id }}"
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"
    return create_offer_matching_task(
        task_id,
        f'python -m scripts.05e_prepare_data {run_month_id} {run_id}',
        git_sync_branch='feature/kubeflow'
    )


def apply_business_rules(task_id, ce_status):
    run_month_id = "{{ params.run_month_id }}"
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"
    return create_offer_matching_task(
        task_id + ce_status,
        f'python -m scripts.05_apply_business_rules {run_month_id} {run_id} {ce_status}',
        git_sync_branch='feature/kubeflow',
        memory='120Gi'
    )


def train_spark_app(type_of_model):
    image = 'smtds/uplift-engine-kubeflow-spark:latest'
    main_file = '/scripts/02_training.py'

    ns = k8s_namespace()
    run_month_id = "{{ params.run_month_id }}"
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"

    init_containers = [git_clone_init_container_dict(
        GitRepositories.OFFER_MATCHING,
        'feature/kubeflow',
        more_memory=True
    )]
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "namespace": ns
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": '/home/git/' + GitRepositories.OFFER_MATCHING.repo_name() + main_file,
            "arguments": [run_month_id, run_id, type_of_model],
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


def score_spark_app(type_of_model):
    image = 'smtds/uplift-engine-kubeflow-spark:latest'
    main_file = '/scripts/04_score.py'

    ns = k8s_namespace()
    run_month_id = "{{ params.run_month_id }}"
    run_id = "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"

    init_containers = [git_clone_init_container_dict(
        GitRepositories.OFFER_MATCHING,
        'feature/kubeflow',
        more_memory=True
    )]
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "namespace": ns
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": '/home/git/' + GitRepositories.OFFER_MATCHING.repo_name() + main_file,
            "arguments": [run_month_id, run_id, type_of_model],
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


filters = user_defined_filters()
filters['make_run_id'] = make_run_id


with DAG(
    dag_id='offer_matching_dag',
    default_args=get_default_args(),
    params={
        'run_month_id': 'yyyy-mm',
        "pipeline_run_id": "",

        'closing_bullet': '',
        'before_price': '',
        'pricing_guideline': '',
        'in_scope_offer_speedcap': '',
        'in_scope_offer_supercare': '',
    },
    user_defined_filters=filters,
    schedule_interval=None,
    catchup=False,
) as dag:

    train_super_care = spark_task_group(
        dag=dag,
        spark_app_name='train-super-care',
        spark_app_spec=train_spark_app(type_of_model='SUPER_CARE')
    )
    train_speed_cap = spark_task_group(
        dag=dag,
        spark_app_name='train-speed-cap',
        spark_app_spec=train_spark_app(type_of_model='SPEED_CAP')
    )
    download_offer_pack_airtable = offer_pack_airtable('download_offer_pack_airtable')
    retention_report_step = retention_report('retention_report')
    speed_cap = training_data('speed_cap_training_data', 'SPEED_CAP')
    super_care = training_data('super_care_training_data', 'SUPER_CARE')

    make_scoring_data_super_care = make_scoring_data('scoring_data_super_care', 'SUPER_CARE')
    make_scoring_data_speed_cap = make_scoring_data('scoring_data_speed_cap', 'SPEED_CAP')

    retention_report_step >> speed_cap >> train_speed_cap >> make_scoring_data_speed_cap
    retention_report_step >> super_care >> train_super_care >> make_scoring_data_super_care

    download_offer_pack_airtable >> make_scoring_data_super_care
    download_offer_pack_airtable >> make_scoring_data_speed_cap

    score_super_care = spark_task_group(
        dag=dag,
        spark_app_name='score-super-care',
        spark_app_spec=score_spark_app('SUPER_CARE')
    )
    make_scoring_data_super_care >> score_super_care
    score_speed_cap = spark_task_group(
        dag=dag,
        spark_app_name='score-speed-cap',
        spark_app_spec=score_spark_app('SPEED_CAP')
    )
    make_scoring_data_speed_cap >> score_speed_cap

    pre_biz_rule = prepare_business_rules_data('prep-biz-rule')
    score_super_care >> pre_biz_rule

    pre_biz_rule >> apply_business_rules('biz-rule', 'CE0') >> apply_business_rules('biz-rule', 'CE1') >> apply_business_rules('biz-rule', 'CE2') >> apply_business_rules('biz-rule', 'CE3') >> apply_business_rules('biz-rule', 'CE4') >> apply_business_rules('biz-rule', 'CE5')

