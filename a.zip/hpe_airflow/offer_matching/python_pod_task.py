
from enum import Enum
from utils.git_utils import git_clone_init_container, GitRepositories, get_branch_by_k8s_namespace
from utils.airflow_utils import k8s_namespace
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from datetime import timedelta
from airflow.utils.trigger_rule import TriggerRule
from airflow.hooks.base import BaseHook


def create_offer_matching_task(task_id, python_command, git_sync_branch, memory='16Gi'):
    """
    Runs a python command in a pod
    @param task_id:
    @param python_command:
    @param git_sync_branch: dev or prod
    @return:
    """
    repo_name = GitRepositories.OFFER_MATCHING.repo_name()
    init_container = git_clone_init_container(
        repo=GitRepositories.OFFER_MATCHING, branch=git_sync_branch, more_memory=True
    )
    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        f'cd /home/git/{repo_name}',
        python_command
    ]
    args = ' && '.join(arg)
    airtable_access_token = BaseHook.get_connection('airtable_access_token').password
    oracle = BaseHook.get_connection('oracle_db')
    return KubernetesPodOperator(
        task_id=task_id,
        labels={
            'hpecp.hpe.com/dtap': 'hadoop2-job'
        },
        namespace=k8s_namespace(),
        image='smtds/smt-offer-matching-python:latest',
        image_pull_secrets='smtds-dockerhub-secret',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        env_vars=[
            # need to set this env if using pyarrow
            k8s.V1EnvVar(name='ARROW_LIBHDFS_DIR', value='/root/hadoop/lib/native'),
            # for downloading airtable CSVs
            k8s.V1EnvVar(name='AIRTABLE_ACCESS_TOKEN', value=airtable_access_token),

            k8s.V1EnvVar(name='ORACLE_USERNAME', value=oracle.login),
            k8s.V1EnvVar(name='ORACLE_PASSWORD', value=oracle.password),
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "8", "memory": memory
            },
            requests={
                "cpu": "8", "memory": memory
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        execution_timeout=timedelta(minutes=60),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS
    )


def create_offer_matching_multi_sim_task(task_id, python_command, git_sync_branch, memory="180Gi"):
    """
    Runs a python command in a pod
    @param task_id:
    @param python_command:
    @param git_sync_branch: dev or prod
    @return:
    """
    repo_name = GitRepositories.OFFER_MATCHING_MULTI_SIM.repo_name()
    init_container = git_clone_init_container(
        repo=GitRepositories.OFFER_MATCHING_MULTI_SIM, branch=git_sync_branch, more_memory=True
    )
    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        f'cd /home/git/{repo_name}',
        python_command
    ]
    args = ' && '.join(arg)
    oracle = BaseHook.get_connection('oracle_db')
    airtable_access_token = BaseHook.get_connection('airtable_access_token').password

    return KubernetesPodOperator(
        task_id=task_id,
        labels={
            'hpecp.hpe.com/dtap': 'hadoop2-job'
        },
        namespace=k8s_namespace(),
        image='smtds/smt-omms-python:1.0.3',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        env_vars=[
            # need to set this env if using pyarrow
            k8s.V1EnvVar(name='ARROW_LIBHDFS_DIR', value='/root/hadoop/lib/native'),
            # for downloading airtable CSVs
            k8s.V1EnvVar(name='AIRTABLE_ACCESS_TOKEN', value=airtable_access_token),
            k8s.V1EnvVar(name='ORACLE_USERNAME', value=oracle.login),
            k8s.V1EnvVar(name='ORACLE_PASSWORD', value=oracle.password),
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "2", "memory": memory
            },
            requests={
                "cpu": "2", "memory": memory
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        execution_timeout=timedelta(minutes=180),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS
    )


def create_uplift_task(task_id, python_command, git_sync_branch):
    """
    Runs a python command in a pod
    @param task_id:
    @param python_command:
    @param git_sync_branch: dev or prod
    @return:
    """
    repo_name = GitRepositories.OFFER_MATCHING_UPLIFT.repo_name()
    init_container = git_clone_init_container(
        repo=GitRepositories.OFFER_MATCHING_UPLIFT, branch=git_sync_branch, more_memory=True
    )
    arg = [
        'sleep 20',  # wait for dtap sidecar to become ready
        f'cd /home/git/{repo_name}',
        python_command
    ]
    args = ' && '.join(arg)
    oracle = BaseHook.get_connection('oracle_db')
    return KubernetesPodOperator(
        task_id=task_id,
        labels={
            'hpecp.hpe.com/dtap': 'hadoop2-job'
        },
        namespace=k8s_namespace(),
        image='smtds/uplift-engine-kubeflow:latest',
        init_containers=[init_container],
        cmds=[
            '/bin/bash', '-c'
        ],
        arguments=[args],
        env_vars=[
            # need to set this env if using pyarrow
            k8s.V1EnvVar(name='ARROW_LIBHDFS_DIR', value='/root/hadoop/lib/native'),

            k8s.V1EnvVar(name='ORACLE_USERNAME', value=oracle.login),
            k8s.V1EnvVar(name='ORACLE_PASSWORD', value=oracle.password),
        ],
        resources=k8s.V1ResourceRequirements(
            limits={
                "cpu": "2", "memory": "16Gi"
            },
            requests={
                "cpu": "2", "memory": "16Gi"
            }
        ),
        volumes=[
            k8s.V1Volume(
                name="git-volume",
                empty_dir=k8s.V1EmptyDirVolumeSource()
            ),
            k8s.V1Volume(
                name='secret-volume',
                secret=k8s.V1SecretVolumeSource(
                    secret_name='git-password-secret'
                )
            )
        ],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
        ],
        name=task_id,
        reattach_on_restart=False,
        is_delete_operator_pod=True,
        execution_timeout=timedelta(minutes=30),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS
    )
