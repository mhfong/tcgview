"""
Airflow pipeline for offer matching model multi sim

"""
from datetime import datetime

from airflow import DAG

from offer_matching.python_pod_task import create_offer_matching_multi_sim_task
from utils.airflow_utils import k8s_namespace, spark_task_group, user_defined_filters
from utils.email_utils import send_email
from utils.git_utils import (
    GitRepositories,
    git_clone_init_container_dict,
    get_branch_by_k8s_namespace,
)


def get_default_args():
    """
    Default args for the DAG
    """
    return {
        "owner": "smartone ds team",
        "start_date": datetime(2023, 2, 3),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        # Offer Matching Multi Sim DAG
        """,
        "on_failure_callback": send_email,
    }


def make_run_id(dag_run_id):
    """
    Limit the length of the run_id.
    """
    return dag_run_id[: dag_run_id.index("T") + 8]


def ce_to_score_template():
    """
    Generate a list of ce to score

    i.e.  run_month_id = '2021-01',
    ce_to_score = ['ce202101', 'ce202102', 'ce202103', 'ce202104', 'ce202105']
    """

    def ce_month_template(ce_status):
        """
        Create template for the ce month
        ce status -> CEYYYYMM
        """
        month_delta = int(ce_status[2:])
        _template = f"""(
            macros.datetime.strptime(params.run_month_id, '%Y-%m') +
            macros.dateutil.relativedelta.relativedelta(months={month_delta})
        ).strftime('%Y%m')
        """.replace(
            "\n", ""
        )
        _template = "ce{{" + _template + "}}"
        return _template

    num_ce_months = 6
    ce_statuses = ["CE" + str(m) for m in range(num_ce_months)]
    ce_to_score = [ce_month_template(ce_status) for ce_status in ce_statuses]
    return ce_to_score


def run_id_template():
    """
    Any string, standardize by limit string, create if not exist
    """
    return "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"


def run_month_id_template():
    """
    Month of CE0 for each refresh, create if not exist
    """
    return """{{
        params.run_month_id
        if params.run_month_id != ''
        else (ds + macros.dateutil.relativedelta.relativedelta(months=1)).strftime('%Y-%m')
    }}""".replace(
        "\n", ""
    )


def latest_c360_month_id_template():
    """
    Latest c360 month id, create if not exist
    """
    return """{{
        params.latest_c360_month_id
        if params.latest_c360_month_id != ''
        else (ds - macros.dateutil.relativedelta.relativedelta(months=2)).strftime('%Y-%m')
    }}""".replace(
        "\n", ""
    )

def offer_type_template():
    """
    offer type 
    """
    return """{{
        params.offer_type
    }}""".replace(
        "\n", ""
    )

def fetch_retention_report(task_id: str):
    """
    DAG task for running the retention report
    """
    run_id = run_id_template()
    run_month_id = run_month_id_template()
    git_sync_branch = get_branch_by_k8s_namespace()

    return create_offer_matching_multi_sim_task(
        task_id,
        f"python -m scripts.01a_fetch_report {run_month_id} {run_id}",
        git_sync_branch=git_sync_branch,
    )


def fetch_multi_sim_mapping(task_id: str):
    """
    DAG task for fetching the historical multi sim mapping
    """
    run_id = run_id_template()
    run_month_id = run_month_id_template()
    git_sync_branch = get_branch_by_k8s_namespace()

    return create_offer_matching_multi_sim_task(
        task_id,
        f"python -m scripts.01b_fetch_multi_sim_mapping {run_month_id} {run_id}",
        git_sync_branch=git_sync_branch,
    )


def train_model_python(task_id: str):
    """
    DAG task for fetching the historical multi sim mapping
    """
    run_id = run_id_template()
    run_month_id = run_month_id_template()
    git_sync_branch = get_branch_by_k8s_namespace()

    return create_offer_matching_multi_sim_task(
        task_id,
        f"python -m scripts.02b_train_model_python {run_month_id} {run_id}",
        git_sync_branch=git_sync_branch,
    )


def offer_to_combo_features_python(task_id: str):
    """
    DAG task for offer to combo
    """
    run_id = run_id_template()
    run_month_id = run_month_id_template()
    git_sync_branch = get_branch_by_k8s_namespace()

    return create_offer_matching_multi_sim_task(
        task_id,
        f"python -m scripts.03_offer_to_combo_features_python {run_month_id} {run_id}",
        git_sync_branch=git_sync_branch,
    )


def om_etl_python(task_id: str):
    """
    DAG task for the etl
    """
    run_id = run_id_template()
    run_month_id = run_month_id_template()
    git_sync_branch = get_branch_by_k8s_namespace()

    return create_offer_matching_multi_sim_task(
        task_id,
        f"python -m scripts.01d_om_etl_python {run_month_id} {run_id}",
        git_sync_branch=git_sync_branch,
    )


def scoring_python_tasks(task_id: str):
    """
    DAG task for the etl
    """
    run_id = run_id_template()
    run_month_id = run_month_id_template()
    ce_to_score = ce_to_score_template()
    git_sync_branch = get_branch_by_k8s_namespace()

    return [
        create_offer_matching_multi_sim_task(
            f"{task_id}_ce{i}",
            f"python -m scripts.04b_scoring_python {run_month_id} {run_id} --ce_to_score {ce}",
            git_sync_branch=git_sync_branch,
            memory="90Gi"
        )
        for i, ce in enumerate(ce_to_score)
    ]


def simulation_python_tasks(task_id: str):
    """
    DAG task for the etl
    """
    run_id = run_id_template()
    run_month_id = run_month_id_template()
    ce_to_score = ce_to_score_template()
    git_sync_branch = get_branch_by_k8s_namespace()
    offer_type = offer_type_template()

    return [
        create_offer_matching_multi_sim_task(
            f"{task_id}_ce{i}",
            f"python -m scripts.05_simulation_python {run_month_id} {run_id} {offer_type} --ce_to_score {ce}",
            git_sync_branch=git_sync_branch,
            memory="30Gi"
        )
        for i, ce in enumerate(ce_to_score)
    ]


def make_omms_spark_app(pyspark_image: str, main_file: str, **kwargs):
    """
    Make the spark app for pre training
    """

    ns = k8s_namespace()
    git_sync_branch = get_branch_by_k8s_namespace()

    spark_app_args = []

    for k, v in kwargs.items():
        if isinstance(v, list):
            spark_app_args.append(f"--{k}")
            spark_app_args.extend(v)
        else:
            spark_app_args.append(v)
    print(f"{spark_app_args=}")

    init_containers = [
        git_clone_init_container_dict(
            repo=GitRepositories.OFFER_MATCHING_MULTI_SIM,
            branch=git_sync_branch,
            more_memory=True,
        )
    ]

    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {"namespace": ns},
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar"
                ]
            },
            "image": pyspark_image,
            "imagePullPolicy": "Always",
            "timeToLiveSeconds": 3600,
            "mainApplicationFile": "/home/git/"
            + GitRepositories.OFFER_MATCHING_MULTI_SIM.repo_name()
            + main_file,
            "arguments": spark_app_args,
            "restartPolicy": {"type": "Never"},
            "imagePullSecrets": ["imagepull",
                "smtds-dockerhub-secret"],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {"version": "2.4.7", "hpecp.hpe.com/dtap": "hadoop2-job"},
                "initContainers": init_containers,
                "volumeMounts": [
                    {"name": "git-volume", "mountPath": "/home/git"},
                    {"name": "secret-volume", "mountPath": "/etc/secret-volume"},
                ],
                "env": [],
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 5,
                "memory": "80g",
                "labels": {"version": "2.4.7", "hpecp.hpe.com/dtap": "hadoop2-job"},
                "initContainers": init_containers,
                "volumeMounts": [
                    {"name": "git-volume", "mountPath": "/home/git"},
                    {"name": "secret-volume", "mountPath": "/etc/secret-volume"},
                ],
                "env": [],
            },
            "volumes": [
                {"name": "git-volume", "emptyDir": {}},
                {
                    "name": "secret-volume",
                    "secret": {"secretName": "git-password-secret"},
                },
            ],
        },
    }
    return spark_app


filters = user_defined_filters()
filters["make_run_id"] = make_run_id

with DAG(
    dag_id="omms",
    default_args=get_default_args(),
    params={
        "run_month_id": "2023-11",
        "__run_month_id__": "Month of CE0 in format YYYY-MM",
        "pipeline_run_id": "test",
        "__pipeline_run_id__": "Any string, standardize by limit string, will overwrite previous run if exist",
        "latest_c360_month_id": "2023-10",
        "__latest_c360_month_id__": "Latest C360 month id in format YYYY-MM",
        "offer_type": "",
        "__offer_type__": "type the offertype you would like to general. ['no_special_handling', 'acq', 'normal']",
    },
    user_defined_filters=filters,
    schedule_interval=None,
    catchup=False,
    render_template_as_native_obj=True,
) as dag:
    PYSPARK_IMAGE = "smtds/smt-omms-pyspark:v0.0.1"

    fetch_retention_report_step = fetch_retention_report("omms_fetch_retention_report")
    fetch_multi_sim_mapping_step = fetch_multi_sim_mapping(
        "omms_fetch_multi_sim_mapping"
    )
    om_etl_step = om_etl_python("omms_om_etl")
    train_model_step = train_model_python("omms_train_model")
    offer_to_combo_features_step = offer_to_combo_features_python(
        "omms_offer_to_combo_features"
    )
    scoring_steps = scoring_python_tasks("omms_score")
    simulation_steps = simulation_python_tasks("omms_simulation")
    pre_score_step = spark_task_group(
        dag=dag,
        spark_app_name="omms-pre-score",
        spark_app_spec=make_omms_spark_app(
            pyspark_image=PYSPARK_IMAGE,
            main_file="/scripts/04a_scoring_pyspark.py",
            run_month_id=run_month_id_template(),
            run_id=run_id_template(),
            ce_to_score=ce_to_score_template(),
        ),
    )
    pre_train_step = spark_task_group(
        dag=dag,
        spark_app_name="omms-pre-train",
        spark_app_spec=make_omms_spark_app(
            pyspark_image=PYSPARK_IMAGE,
            main_file="/scripts/02a_pre_train_pyspark.py",
            run_month_id=run_month_id_template(),
            run_id=run_id_template(),
        ),
    )

    number_of_scoring_steps = len(scoring_steps)

    (
        [fetch_retention_report_step, fetch_multi_sim_mapping_step]
        >> om_etl_step
        >> pre_train_step
        >> train_model_step
        >> pre_score_step
    )
    (
        offer_to_combo_features_step
        >> pre_score_step
        >> scoring_steps[: -(number_of_scoring_steps // 2)]
    )

    for scoring_step, simulation_step in zip(scoring_steps, simulation_steps):
        scoring_step >> simulation_step

    # Run ce in 3 by 3
    for scoring_step, simulation_step in zip(
        scoring_steps[number_of_scoring_steps // 2 :],
        simulation_steps[: -(number_of_scoring_steps // 2)],
    ):
        simulation_step >> scoring_step
