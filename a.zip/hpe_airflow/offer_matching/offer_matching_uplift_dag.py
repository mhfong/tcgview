
from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group, k8s_namespace
from offer_matching.python_pod_task import create_uplift_task
from utils.git_utils import GitRepositories, git_clone_init_container_dict
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2023, 2, 3),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "email": "hinny_tsang@smartone.com",
        "doc_md": """
        # Offer Matching Uplift DAG 
        """,
        'on_failure_callback': send_email
    }


def make_run_id(dag_run_id):
    return dag_run_id[:dag_run_id.index('T') + 8]


def scoring_month_id_template():
    return """{{ 
        params.scoring_month_id if params.scoring_month_id != 'yyyy-mm' 
        else (next_execution_date + macros.dateutil.relativedelta.relativedelta(months=1)).strftime('%Y-%m') 
    }}""".replace('\n', '')


def run_id_template():
    return "{{ params.pipeline_run_id if params.pipeline_run_id != '' else run_id | make_run_id | sanitize }}"


def training_data(task_id):
    # dates are not needed for overwrite, use ds
    scoring_month_id = scoring_month_id_template()
    run_id = run_id_template()
    return create_uplift_task(
        task_id,
        f'python -m scripts.01_training_data {scoring_month_id} {run_id}',
        git_sync_branch='feature/kubeflow'
    )


def scoring_data(task_id):
    # dates are not needed for overwrite, use ds
    scoring_month_id = scoring_month_id_template()
    run_id = run_id_template()
    return create_uplift_task(
        task_id,
        f'python -m scripts.03_scoring_data {scoring_month_id} {run_id}',
        git_sync_branch='feature/kubeflow'
    )


def generate_lists(task_id):
    # dates are not needed for overwrite, use ds
    scoring_month_id = scoring_month_id_template()
    run_id = run_id_template()
    return create_uplift_task(
        task_id,
        f'python -m scripts.05_generate_lists {scoring_month_id} {run_id}',
        git_sync_branch='feature/kubeflow'
    )


def uplift_spark_app(train_or_score):
    image = 'smtds/uplift-engine-kubeflow-spark:latest'
    main_file = {
        'train': '/scripts/oscar_uplift_model_selection.py',
        'score': '/scripts/oscar_uplift_scoring.py'
    }[train_or_score]

    ns = k8s_namespace()
    scoring_month_id = scoring_month_id_template()
    run_id = run_id_template()
    args = [scoring_month_id, run_id]

    init_containers = [git_clone_init_container_dict(
        repo=GitRepositories.OFFER_MATCHING_UPLIFT,
        branch='feature/kubeflow',
        more_memory=True
    )]
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "namespace": ns
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": '/home/git/' + GitRepositories.OFFER_MATCHING_UPLIFT.repo_name() + main_file,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "32g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2-job"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": []
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


filters = user_defined_filters()
filters['make_run_id'] = make_run_id


with DAG(
    dag_id='offer_matching_uplift_dag',
    default_args=get_default_args(),
    params={
        '__scoring_month_id_doc__': 'yyyy-mm (Valid month of the DND period)',
        'scoring_month_id': "yyyy-mm",
        "__pipeline_run_id_doc__": "Any String, leave empty for random UUID",
        "pipeline_run_id": "",
    },
    user_defined_filters=filters,
    schedule_interval="0 0 * * 4", # Schedule at last Thursday of each month, since the FTG report will update weekly at Wed
    catchup=False,
) as dag:

    make_training_data = training_data('make_training_data')

    train = spark_task_group(
        dag=dag,
        spark_app_name='train',
        spark_app_spec=uplift_spark_app('train')
    )

    make_scoring_data = scoring_data('make_scoring_data')

    score = spark_task_group(
        dag=dag,
        spark_app_name='score',
        spark_app_spec=uplift_spark_app('score')
    )

    generate_contact_list = generate_lists('generate_contact_list')

    make_training_data >> train >> make_scoring_data >> score >> generate_contact_list 
