
from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group, k8s_namespace
from utils.git_utils import k8s_namespace, git_clone_init_container_dict, GitRepositories, get_branch_by_k8s_namespace
from utils.email_utils import send_email

def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2023, 11, 20),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }


def weblog_spark_app(
        main_file,
        args: list,
        image='smtds/spark-py-2.4.7-oracle:20230614'
) -> dict:
    """
    Makes SparkApplication for c360_data_staging/extract_oracle_main.py
    @return:
    """
    repo_name = GitRepositories.WEBLOG.repo_name()
    repo_dir = '/'.join([
        '/home/git',
        repo_name
    ])
    main_app_file = repo_dir + main_file
    init_containers = [git_clone_init_container_dict(
        GitRepositories.WEBLOG,
        get_branch_by_k8s_namespace()
    )]
    # spark + pyarrow + dateutil + ojdbc8-21.9.0.0.jar + cx-Oracle
    # image = 'smtds/spark-py-2.4.7-oracle:20230328'
    # image = 'smtds/spark-py-2.4.7-oracle:20230614'
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/oracle-jdbc/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": [
                    {
                        "name": "ORACLE_PASS",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-secret",
                                "key": "password"
                            }
                        }
                    },
                    {
                        "name": "CNSS_ORACLE_PASS",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-cnss-secret",
                                "key": "password"
                            }
                        }
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


def ds_arg(offset: int):
    template = f"macros.ds_add(ds, {offset}) if params.run_date == 'yyyy-mm-dd' else macros.ds_add(params.run_date, {offset})"
    return '{{ ' + template + ' }}'


RUN_N_PREVIOUS_DAYS = 3
offsets = list(range(-RUN_N_PREVIOUS_DAYS + 1, 1))  # [-N, -N+1, ..., 0]

with DAG(
    dag_id='weblog_daily',
    default_args=get_default_args(),
    params={
        'run_date': 'yyyy-mm-dd',
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 5 * * *',
    catchup=True,
) as dag:

    ssl = [spark_task_group(
        dag=dag,
        spark_app_name=f'weblog-csv-ssl-parquet-{i}',
        spark_app_spec=weblog_spark_app(main_file='/step1_sslweb_csv_to_parquet.py', args=[ds_arg(i)])
    ) for i in offsets]

    domain_index = [spark_task_group(
        dag=dag,
        spark_app_name=f'weblog-index-{i}',
        spark_app_spec=weblog_spark_app(main_file='/step2_update_domain_index_manual.py', args=[ds_arg(i)])
    ) for i in offsets]

    valid_index = [spark_task_group(
        dag=dag,
        spark_app_name=f'valid-weblog-index-{i}',
        spark_app_spec=weblog_spark_app(main_file='/step2a_index_validation.py', args=[ds_arg(i)])
    ) for i in offsets]

    valid_domain_daily = [spark_task_group(
        dag=dag,
        spark_app_name=f'valid-weblog-daily-{i}',
        spark_app_spec=weblog_spark_app(main_file='/step2c_daily_domain_check.py', args=[ds_arg(i)])
    ) for i in offsets]

    domain_daily = [spark_task_group(
        dag=dag,
        spark_app_name=f'weblog-daily-{i}',
        spark_app_spec=weblog_spark_app(main_file='/step2b_daily_aggregrate_manual.py', args=[ds_arg(i)])
    ) for i in offsets]

    for i in range(RUN_N_PREVIOUS_DAYS):
        ssl[i] >> domain_index[i] >> valid_index[i] >> domain_daily[i] >> valid_domain_daily[i]

    if RUN_N_PREVIOUS_DAYS > 1:
        for i in range(RUN_N_PREVIOUS_DAYS-1):
            valid_index[i] >> domain_index[i+1]
