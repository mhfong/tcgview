
from datetime import datetime

from airflow import DAG
from utils.airflow_utils import user_defined_filters, spark_task_group, k8s_namespace
from weblog.weblog_daily import weblog_spark_app
from utils.email_utils import send_email


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2023, 2, 3),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "doc_md": """
        """,
        'on_failure_callback': send_email
    }


ds_arg = "{{ ds if params.run_month == 'yyyy-mm' else params.run_month }}"


with DAG(
    dag_id='weblog_monthly',
    default_args=get_default_args(),
    params={
        'run_month': 'yyyy-mm',
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='0 8 4 * *',
    catchup=False,
) as dag:

    monthly = spark_task_group(
        dag=dag,
        spark_app_name='weblog-monthly',
        spark_app_spec=weblog_spark_app(main_file='/step3_monthly_aggregate.py', args=[ds_arg])
    )