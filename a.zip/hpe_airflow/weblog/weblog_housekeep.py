import json
from datetime import datetime

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from kubernetes.client import models as k8s
from airflow.utils.dates import days_ago
from utils.git_utils import GitRepositories, get_branch_by_k8s_namespace
from utils import airflow_utils

def get_default_args():
    return {
        "owner": "smartone ds team",
        "tags": ["weblog", "Michael", "pong"],
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": days_ago(1),
        "doc_md": """
                    # weblog housekeep data pipeline
                  """,
    }

with DAG(
    dag_id = 'weblog_housekeep', 
    default_args=get_default_args(),
    schedule_interval="00 13 * * *",
)as dag:
    # git sync into empty directory
    volume_name = "workdir"
    bash_to_housekeep = "bin/weblog_housekeep.sh"
    volume = k8s.V1Volume(name=volume_name,empty_dir=k8s.V1EmptyDirVolumeSource())
    git_env = {
        'GIT_SYNC_REPO': GitRepositories.WEBLOG.value,
        'GIT_SYNC_USERNAME': "dw_dwsup_04@smartone.com",
        'GIT_SYNC_PERMISSIONS': "0755",
        'GIT_SYNC_PASSWORD_FILE': '/etc/secret-volume/git-password-file',
        'GIT_SYNC_DEST': "weblog",
        'GIT_SYNC_ROOT': f"/workdir" + "/airflow-working-dir/",
        'GIT_SYNC_BRANCH': get_branch_by_k8s_namespace(),
        'GIT_SYNC_ONE_TIME': 'true',
        "GIT_SYNC_GIT_CONFIG": "http.sslVerify:false",
        }

    git_env = [k8s.V1EnvVar(name=k, value=v) for k, v in git_env.items()]

    # secret key
    git_env.append(k8s.V1EnvVar(
        name = "GIT_SYNC_PASSWORD",
        value_from = k8s.V1EnvVarSource (
            secret_key_ref = k8s.V1SecretKeySelector(
                            name="airflow-gitrepo-password",
                            key="password"
            )
        )
    ))

    git_sync_init_container = k8s.V1Container(
            name =  "git-sync-weblog",
            image= "k8s.gcr.io/git-sync/git-sync:v3.3.4",
            resources=k8s.V1ResourceRequirements(
                limits={
                    "cpu": "500m", "memory": "700Mi"
                },
                requests={
                    "cpu": "500m", "memory": "700Mi"
                }
            ),
            volume_mounts=[
                k8s.V1VolumeMount(
                    mount_path=f"/workdir",
                    name=volume_name,
                ),
            ],
            env=git_env

        )
    # makes the dtap process show up in `ps`
    additional_pod_spec = k8s.V1Pod(
        spec=k8s.V1PodSpec(
            share_process_namespace=True,
            containers=[]
            )
        )
    
    # set the bash/command after the pods has establish
    arg = ["sleep 20s", # wait for dtap sidecar to become ready
           f"/workdir/airflow-working-dir/weblog/{bash_to_housekeep}" # main bash script
           ]
    
    args = ' && '.join(arg)
    call_image = KubernetesPodOperator(
                    namespace=airflow_utils.k8s_namespace(),
                    image="smtds/python310-hadoop2102-dtap",
                    image_pull_secrets='smtds-dockerhub-secret',
                    cmds=['/bin/bash','-c'],
                    arguments=[args],
                    labels={"hpecp.hpe.com/dtap": "hadoop2-job"},
                    name="weblog-housekeep-",
                    task_id="weblog-housekeeping",
                    get_logs=True,
                    volumes=[volume],
                    volume_mounts = [k8s.V1VolumeMount(
                                                    name = volume_name,
                                                    mount_path = f"/workdir"
                                                    )
                                    ],
                    init_containers = [git_sync_init_container],
                    is_delete_operator_pod =True,
                    full_pod_spec=additional_pod_spec,
                    resources=k8s.V1ResourceRequirements(
                        limits={"cpu": "500m", "memory": "900Mi"},
                        requests={"cpu": "500m", "memory": "900Mi"}
                    ),
                    dag=dag
                    )
    call_image