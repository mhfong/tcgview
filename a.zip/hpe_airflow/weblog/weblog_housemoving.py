
from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import \
    KubernetesPodOperator
from kubernetes.client import models as k8s
from utils.email_utils import send_email

from utils.airflow_utils import (k8s_namespace, spark_task_group,
                                 user_defined_filters)
from utils.git_utils import (GitRepositories, get_branch_by_k8s_namespace,
                             git_clone_init_container,
                             git_clone_init_container_dict, k8s_namespace)


def get_default_args():
    return {
        "owner": "",
        "start_date": datetime(2023, 2, 3),
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        'on_failure_callback': send_email,
        "doc_md": """
        """,
    }


def weblog_spark_app(
        main_file,
        args: list,
        image='smtds/spark-py-2.4.7-oracle:20231103commonutil'
) -> dict:
    """
    Makes SparkApplication for weblog_spark_app
    @return:
    """
    repo_name = GitRepositories.WEBLOG.repo_name()
    repo_dir = '/'.join([
        '/home/git',
        repo_name
    ])
    main_app_file = repo_dir + main_file
    init_containers = [git_clone_init_container_dict(
        GitRepositories.WEBLOG,
        get_branch_by_k8s_namespace()
    )]
    # spark + pyarrow + dateutil + ojdbc8-21.9.0.0.jar + cx-Oracle
    # image = 'smtds/spark-py-2.4.7-oracle:20230328'
    # image = 'smtds/spark-py-2.4.7-oracle:20230614'
    spark_app = {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        "metadata": {
            "generateName": "",
            "namespace": k8s_namespace()
        },
        "spec": {
            "sparkConf": {
                "spark.mapr.user.secret": "mapr-user-secret-livy",
                "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                "spark.driver.extraClassPath": "/opt/bdfs/bluedata-dtap.jar",
                "spark.executor.extraClassPath": "/opt/bdfs/bluedata-dtap.jar"
            },
            "type": "Python",
            "sparkVersion": "2.4.7",
            "pythonVersion": "3",
            "mode": "cluster",
            "deps": {
                "jars": [
                    # must be local, spark-submit k8s Job do not have dtap sidecar
                    "local:///opt/bdfs/bluedata-dtap.jar",
                    "local:///opt/oracle-jdbc/ojdbc8-21.9.0.0.jar"
                ]
            },
            "image": image,
            "imagePullPolicy": "Always",
            "mainApplicationFile": main_app_file,
            "arguments": args,
            "restartPolicy": {
                "type": "Never"
            },
            "imagePullSecrets": [
                "imagepull",
                "smtds-dockerhub-secret"
            ],
            "driver": {
                "cores": 5,
                "coreLimit": "5000m",
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
                "env": [
                    {
                        "name": "ORACLE_USER",
                        "value": "BAANAUSR"  
                    },
                    {
                        "name": "ORACLE_PASS",
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": "oracle-secret",
                                "key": "password"
                            }
                        }
                    }
                ]
            },
            "executor": {
                "cores": 5,
                "coreLimit": "5000m",
                "instances": 2,
                "memory": "50g",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                },
                "initContainers": init_containers,
                "volumeMounts": [
                    {
                        "name": "git-volume",
                        "mountPath": "/home/git"
                    },
                    {
                        "name": "secret-volume",
                        "mountPath": "/etc/secret-volume"
                    }
                ],
            },
            "volumes": [
                {
                    "name": "git-volume",
                    "emptyDir": {}
                },
                {
                    "name": 'secret-volume',
                    "secret": {
                        "secretName": "git-password-secret"
                    }
                }
            ]
        }
    }
    return spark_app


ds_arg = "{{ next_ds_nodash if params.run_date == 'yyyymmdd' else params.run_date }}"


with DAG(
    dag_id='weblog_housemoving',
    default_args=get_default_args(),
    params={
        'run_date': 'yyyymmdd',
    },
    user_defined_filters=user_defined_filters(),
    schedule_interval='30 0 * * 1,3,5',
    catchup=False,
) as dag:

    weblog_housemoving = spark_task_group(
        dag=dag,
        spark_app_name='weblog-housemoving',
        spark_app_spec=weblog_spark_app(main_file='/weblog_housemoving.py', args=[ds_arg])
    )
    
    
    weblog_housemoving_validate = spark_task_group(
        dag=dag,
        spark_app_name='weblog-housemoving-v',
        spark_app_spec=weblog_spark_app(main_file='/weblog_housemoving_validate.py', args=[ds_arg])
    )

    weblog_housemoving >> weblog_housemoving_validate
