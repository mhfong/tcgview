
from airflow import DAG
from utils.airflow_utils import user_defined_filters
from utils.git_utils import get_branch_by_k8s_namespace
from airflow.operators.dummy import DummyOperator
from datetime import datetime


def get_default_args():
    return {
        "owner": "smartone ds team",
        "wait_for_downstream ": True,
        "do_xcom_push": False,
        "depends_on_past": False,
        "start_date": datetime(2999, 1, 1),
    }


with DAG(
    dag_id='00000_This_is_' + get_branch_by_k8s_namespace() + '_environment',
    default_args=get_default_args(),
    catchup=False,
    schedule_interval=None,
    user_defined_filters=user_defined_filters()
) as dag:
    DummyOperator(dag=dag, task_id='dummy')
