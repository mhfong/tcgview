import os
from datetime import datetime
from airflow.operators.email import EmailOperator
from kubernetes import client, config
from utils import airflow_utils
import requests
import time
# The config must be placed here
os.environ['AIRFLOW__SMTP__SMTP_HOST'] = 'smtp-server-mail'
os.environ['AIRFLOW__SMTP__SMTP_PORT'] = '587'
os.environ['AIRFLOW__SMTP__SMTP_STARTTLS'] = 'False'
os.environ['AIRFLOW__SMTP__SMTP_SSL'] = 'False'
os.environ['AIRFLOW__SMTP__SMTP_MAIL_FROM'] = 'dsteam@dsmlworker.hksmartone.com'

es_api_endpoint_credential = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiJ9.mH6tbhsxsgnMtSMf_H5QXjpGpIGSJzCimOgfVqCFucg"
wait_time = 600 # 10 mins


def createnl(line: str, bold=False):
    if bold:
        return f"<br><b> {line} </b></br>"

    return f"<br> {line} </br>"

def get_error_log_from_es(namespace: str, pod_name: str, container_name: str, date:str,
                          host="es-api.c360-project.svc.cluster.local",
                          port=8000):

    api_wait_time = wait_time # 10 mins
    request_interval = 10 # send http request every 30 seconds until 5 mins
    error_message = ""
    print("namespace: ", namespace)
    print("pod_name: ", pod_name)
    print("container_name: ", container_name)
    print("date: ", date)
    _input={
        "namespace": namespace,
        "pod_name": pod_name,
        "container_name": container_name,
        "date": date,
        "token": es_api_endpoint_credential
    }
    try:
        for _time in range(0,api_wait_time,request_interval):
            print(f"REQUEST API: https://{host}:{port}")
            resp = requests.get(f"https://{host}:{port}/get_error_message", params=_input, verify=False)
            is_found = resp.json()["found"]
            if is_found is True:
                error_message = resp.json()["log"].replace("\n","<br>")
                break
            else:
                time.sleep(request_interval)

    except: # no effect
        pass

    return error_message

def send_email(context):
    """
    Define the callback to post on email if a failure is detected in the Workflow
    :return: operator.execute
    """
    ns = airflow_utils.k8s_namespace()

    if ns == "c360-project":
        DEFAULT_EMAIL = "ALL.BPM@smartone.com"
        # Customize the email body by modifying the html_content parameter
        execute_date = context.get("execution_date").strftime("%m/%d/%Y, %H:%M:%S")
        task_instance_key_str = context.get("task_instance_key_str")
        error_message = context.get("exception").__str__()
        ti = context['task_instance']
        task = context['task']
        if ti.operator == 'SparkKubernetesSensor':
            upstream_task_ids = [upstream_task.task_id for upstream_task in task.upstream_list]
            submit_task_id = upstream_task_ids[0]
            resp = get_error_log_from_es(namespace=ns,
                                         pod_name=ti.xcom_pull(submit_task_id)['metadata']['name'] + "-driver",
                                         container_name="spark-kubernetes-driver",
                                         date=context['dag_run'].start_date.strftime('%Y.%m.%d'))
            if resp != "":
                error_message = resp
        elif ti.operator == 'SmartSparkK8sOperator':
            spark_pod_name = ""
            try: # use try and except because ti.xcom_pull maybe None value if "application_name" does not exist
                spark_pod_name = ti.xcom_pull(ti.task_id, key="application_name") + "-driver"
            except Exception as e:
                print("Cannot find SmartSparkK8sOperator application name")
                print(e)
            resp = get_error_log_from_es(namespace=ns,
                                         pod_name=spark_pod_name,
                                         container_name="spark-kubernetes-driver",
                                         date=context['dag_run'].start_date.strftime('%Y.%m.%d'))
            if resp != "":
                error_message = resp
        # Body
        next_line_1 = createnl(f"Task: {task_instance_key_str}", bold=True)
        next_line_2 = createnl(f"Date: {execute_date}")
        next_line_3 = createnl(f"Error: {error_message}")

        # get Task instance
        dag_run = context['dag_run']
        dag = dag_run.dag
        default_args = dag.default_args
        email = default_args.get('email')

        if email:
            TARGET_EMAIL = email
        else:
            TARGET_EMAIL = DEFAULT_EMAIL

        content = next_line_1 + next_line_2 + next_line_3
        operator = EmailOperator(
            task_id='send_email_task',
            to=TARGET_EMAIL,
            subject=f"[Airflow Alert]",
            html_content=content
        )

        return operator.execute(context=context)

    else:

        return None


def send_email_test(context):
    """
    Define the callback to post on email if a failure is detected in the Workflow
    :return: operator.execute
    """
    ns = airflow_utils.k8s_namespace()
    DEFAULT_EMAIL = "walter_sin@smartone.com"
    if ns == "smt-apps":
        # Customize the email body by modifying the html_content parameter
        execute_date = context.get("execution_date").strftime("%m/%d/%Y, %H:%M:%S")
        task_instance_key_str = context.get("task_instance_key_str")
        error_message = context.get("exception").__str__()
        ti = context['task_instance']
        task = context['task']
        if ti.operator == 'SparkKubernetesSensor':
            upstream_task_ids = [upstream_task.task_id for upstream_task in task.upstream_list]
            submit_task_id = upstream_task_ids[0]
            resp = get_error_log_from_es(namespace=ns,
                                         pod_name=ti.xcom_pull(submit_task_id)['metadata']['name'] + "-driver",
                                         container_name="spark-kubernetes-driver",
                                         date=context['dag_run'].start_date.strftime('%Y.%m.%d'))
            if resp != "":
                error_message = resp
        elif ti.operator == 'SmartSparkK8sOperator':
            spark_pod_name = ""
            try: # use try and except because ti.xcom_pull maybe None value if "application_name" does not exist
                spark_pod_name = ti.xcom_pull(ti.task_id, key="application_name") + "-driver"
            except Exception as e:
                print("Cannot find SmartSparkK8sOperator application name")
                print(e)
            resp = get_error_log_from_es(namespace=ns,
                                         pod_name=spark_pod_name,
                                         container_name="spark-kubernetes-driver",
                                         date=context['dag_run'].start_date.strftime('%Y.%m.%d'))
            if resp != "":
                error_message = resp

        # Body
        next_line_1 = createnl(f"Task: {task_instance_key_str}", bold=True)
        next_line_2 = createnl(f"Date: {execute_date}")
        next_line_3 = createnl(f"Error: {error_message}")

        # get Task instance
        dag_run = context['dag_run']
        dag = dag_run.dag
        default_args = dag.default_args
        email = default_args.get('_email')

        if email:
            TARGET_EMAIL = email
        else:
            TARGET_EMAIL = DEFAULT_EMAIL

        content = next_line_1 + next_line_2 + next_line_3
        operator = EmailOperator(
            task_id='send_email_task',
            to=TARGET_EMAIL,
            subject=f"[Airflow Alert]",
            html_content=content
        )

        return operator.execute(context=context)
    

def send_email_success(context):
    """
    Define the callback to post on email if a failure is detected in the Workflow
    :return: operator.execute
    """
    ns = airflow_utils.k8s_namespace()
    if ns == "smt-apps":
        # Customize the email body by modifying the html_content parameter
        execute_date = context.get("execution_date").strftime("%m/%d/%Y, %H:%M:%S")
        task_instance_key_str = context.get("task_instance_key_str")
        dag_run = context['dag_run']

        # Body
        next_line_1 = createnl(f"Task: {task_instance_key_str}", bold=True)
        next_line_2 = createnl(f"Date: {execute_date}")
        next_line_3 = createnl(f"Task finished!")

        # get Task instance
        dag_run = context['dag_run']
        dag = dag_run.dag
        default_args = dag.default_args
        TARGET_EMAIL = default_args.get('_email')

        content = next_line_1 + next_line_2 + next_line_3
        operator = EmailOperator(
            task_id='send_email_task',
            to=TARGET_EMAIL,
            subject=f"[Airflow Alert]",
            html_content=content
        )

        return operator.execute(context=context)