import re
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import SparkKubernetesOperator
from airflow.providers.cncf.kubernetes.sensors.spark_kubernetes import SparkKubernetesSensor
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
import json
from airflow import DAG
from airflow.models import Variable
from airflow.utils.task_group import TaskGroup
from airflow.utils.context import Context
from airflow.providers.cncf.kubernetes.hooks.kubernetes import KubernetesHook
from airflow.exceptions import AirflowException
import time
from datetime import timedelta


def get_registry_proxy():
    return {
        "dockerhub": "dsecp-gateway.hksmartone.com:10066",
        "gcr.io": "dsecp-gateway.hksmartone.com:10067",
        "k8s.gcr.io": "dsecp-gateway.hksmartone.com:10076",
    }


def airflow_job_labels():
    return {
        'airflow-dag': '{{ dag.dag_id }}',
        'airflow-task': '{{ task.task_id }}',
        'airflow-ds': '{{ ds_nodash }}',
        'airflow-try-number': '{{ ti.try_number }}'
    }


def k8s_namespace() -> str:
    return Variable.get('k8s_namespace', default_var='smt-apps')


def _sanitize(_input: str) -> str:
    """
    for sanitizing k8s pod names
    @param _input:
    @return:
    """
    return re.sub(r'([^-_a-zA-Z0-9])', "_", _input)


def _split_list_roughly_equal(_list: list, num_chunks=2):
    """
    split list into chunks with roughly equal lengths.
    Chunk length is (L = int(len(_list) / num_chunks)) L or L+1
    @param _list:
    @param num_chunks:
    @return:
    """
    length = len(_list)
    chunks = max(min(length, num_chunks), 1)
    chunk_len, remaining = divmod(length, chunks)
    end = 0
    for i in range(chunks):
        start = end
        end = start + chunk_len + (1 if i < remaining else 0)
        yield _list[start: end]


def _split_str_list_roughly_equal(str_list, num_chunks=2):
    """
    split comma separated str list into chunks with roughly equal lengths.
    """
    return map(','.join, _split_list_roughly_equal(str_list.split(','), num_chunks))


def get_str_list_chunk(str_list, num_chunks, chunk_index):
    """
    split comma separated str list into chunks with roughly equal lengths. and get the indexed chunk
    @param str_list: "a,b,c,...."
    @param num_chunks: int > 0
    @param chunk_index: int > 0
    @return:
    """
    split_list = list(_split_str_list_roughly_equal(str_list, num_chunks))
    if chunk_index < len(split_list):
        return split_list[chunk_index]


def user_defined_filters() -> dict:
    return {
        'sanitize': _sanitize
    }


def user_defined_macros() -> dict:
    return {
        'get_str_list_chunk': get_str_list_chunk
    }


class SmartSparkK8sOperator(SparkKubernetesOperator):
    SPARK_APP_RUNNING = {
        "RUNNING",
        "SUBMITTED",
        "SUCCEEDING",
        "PENDING_RERUN",
        "PENDING_SUBMISSION",
        ""
    }

    template_fields = ("application_file", "namespace", 'log_url')

    def __init__(self, *, log_url, **kwargs):
        super().__init__(**kwargs)
        self.k8s: KubernetesHook = None
        self.application_name: str = None
        self.log_url: str = log_url  # log_url is in args to be templated

    def spark_is_running(self) -> bool:

        response = self.k8s.get_custom_object(
            group=self.api_group,
            version=self.api_version,
            plural="sparkapplications",
            name=self.application_name,
            namespace=self.namespace,
        )
        application_state = response["status"]["applicationState"]["state"]

        # if application_state in SparkKubernetesSensor.FAILURE_STATES:
        #     raise AirflowException(f"Spark application failed with state: {application_state}")

        # if application_state in SparkKubernetesSensor.SUCCESS_STATES:
        #     return False

        if application_state in self.SPARK_APP_RUNNING:
            return True
        elif application_state in SparkKubernetesSensor.SUCCESS_STATES:
            return False
        else:
            raise AirflowException(f"Spark application failed with state: {application_state}")

    def execute(self, context: Context):
        self.k8s = KubernetesHook(conn_id=self.kubernetes_conn_id)
        api_resp = super().execute(context)
        self.application_name = api_resp['metadata']['name']
        ti = context["ti"]
        ti.xcom_push(key="application_name", value=self.application_name)
        time.sleep(10)  # initial delay, status not available yet
        while self.spark_is_running():
            time.sleep(10)

        return api_resp


def apply_spark_settings(dag: DAG, namespace: str, spark_app_name: str, spark_app_spec: dict) -> tuple:
    # force the namespace
    _namespace = namespace if namespace is not None else k8s_namespace()
    spark_app_spec['metadata']['namespace'] = _namespace

    # to avoid:
    # [metadata.generateName: Invalid value: \"c360_data_staging_snapshot_test_test_\":
    # a lowercase RFC 1123 subdomain must consist of lower case alphanumeric characters, '-' or '.',
    # and must start and end with an alphanumeric character
    clean_dag_id = re.sub(r'([^-a-z0-9])', "-", dag.dag_id.lower())
    spark_app_spec['metadata']['generateName'] = clean_dag_id + '-' + spark_app_name + '-'

    # replace entrypoint.sh to solve dtap not ready issue, adds this to beginning of original entrypoint.sh
    # max_attempts=5
    # current_attempt=1
    # while ! pgrep -x memq_cnode > /dev/null && (( current_attempt++ <= max_attempts ));
    # do echo "waiting for memq_cnode process to start..." && sleep 5
    # done
    if 'hpecp.hpe.com/dtap' in spark_app_spec['spec']['driver']['labels']:
        v = {
            "name": 'my-entrypoint',
            "configMap": {
                "name": "my-entrypoint",
                # decimal for 0777 see https://kubernetes.io/docs/reference/kubernetes-api/config-and-storage-resources/volume/#projections
                "defaultMode": 511
            }
        }
        if 'volumes' in spark_app_spec['spec']:
            spark_app_spec['spec']['volumes'].append(v)
        else:
            spark_app_spec['spec']['volumes'] = [v]

        mount = {
            "name": "my-entrypoint",
            "mountPath": "/opt/mapr/spark/spark-2.4.7/kubernetes/dockerfiles/spark/entrypoint.sh",
            "subPath": "entrypoint.sh"
        }
        if 'volumeMounts' in spark_app_spec['spec']['driver']:
            spark_app_spec['spec']['driver']['volumeMounts'].append(mount)
        else:
            spark_app_spec['spec']['driver']['volumeMounts'] = [mount]
        if 'volumeMounts' in spark_app_spec['spec']['executor']:
            spark_app_spec['spec']['executor']['volumeMounts'].append(mount)
        else:
            spark_app_spec['spec']['executor']['volumeMounts'] = [mount]

    # add airflow job label
    labels = airflow_job_labels()
    spark_app_spec['spec']['driver']['labels'].update(labels)
    spark_app_spec['spec']['executor']['labels'].update(labels)

    return _namespace, spark_app_spec


def apply_spark3_settings(dag: DAG, namespace: str, spark_app_name: str, spark_app_spec: dict) -> tuple:
    # force the namespace
    _namespace = namespace if namespace is not None else k8s_namespace()
    spark_app_spec['metadata']['namespace'] = _namespace

    # to avoid:
    # [metadata.generateName: Invalid value: \"c360_data_staging_snapshot_test_test_\":
    # a lowercase RFC 1123 subdomain must consist of lower case alphanumeric characters, '-' or '.',
    # and must start and end with an alphanumeric character
    clean_dag_id = re.sub(r'([^-a-z0-9])', "-", dag.dag_id.lower())
    spark_app_spec['metadata']['generateName'] = clean_dag_id + '-' + spark_app_name + '-'

    # add airflow job label
    labels = airflow_job_labels()
    spark_app_spec['spec']['driver']['labels'].update(labels)
    spark_app_spec['spec']['executor']['labels'].update(labels)

    return _namespace, spark_app_spec


def spark_task_group(dag: DAG, spark_app_name: str, spark_app_spec: dict, namespace: str = None) -> TaskGroup:
    """
    Make airflow task group for Spark submit and monitor tasks
    @param dag:
    @param spark_app_name:
    @param spark_app_spec: CRD definition: {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        ...
    }
    @param namespace: override k8s namespace
    @return:
    """
    _namespace, spark_app_spec = apply_spark_settings(dag, namespace, spark_app_name, spark_app_spec)
    group_id = 'spark-' + spark_app_name
    with TaskGroup(group_id=group_id) as taskgroup:
        submit = SparkKubernetesOperator(
            task_id='submit_spark',
            namespace=_namespace,
            application_file=json.dumps(spark_app_spec, indent=4),
            do_xcom_push=True,
            api_group="sparkoperator.hpe.com",
            enable_impersonation_from_ldap_user=False,
            dag=dag
        )

        task_id = f'{group_id}.submit_spark'

        sensor = SparkKubernetesSensor(
            task_id='monitor_spark',
            namespace=_namespace,
            application_name="{{ task_instance.xcom_pull(dag_id='" + dag.dag_id + "', task_ids='" + task_id + "')['metadata']['name'] }}",
            api_group="sparkoperator.hpe.com",
            attach_log=True,
            dag=dag
        )

    submit >> sensor
    return taskgroup


def spark_task(dag: DAG, spark_app_name: str, spark_app_spec: dict, namespace: str = None) -> SmartSparkK8sOperator:
    """
    Make airflow task
    @param dag:
    @param spark_app_name:
    @param spark_app_spec: CRD definition: {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        ...
    }
    @param namespace: override k8s namespace
    @return:
    """
    _namespace, spark_app_spec = apply_spark_settings(dag, namespace, spark_app_name, spark_app_spec)
    group_id = 'spark-' + spark_app_name

    submit = SmartSparkK8sOperator(
        task_id=group_id,
        namespace=_namespace,
        application_file=json.dumps(spark_app_spec, indent=4),
        do_xcom_push=True,
        api_group="sparkoperator.hpe.com",
        enable_impersonation_from_ldap_user=False,
        dag=dag,
        retries=1,
        retry_delay=timedelta(seconds=30),
        log_url=log_url(_namespace, 'spark-kubernetes-driver')
    )
    return submit


class SmartPodOperator(KubernetesPodOperator):
    template_fields = (
        *KubernetesPodOperator.template_fields,
        'log_url',
    )

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.log_url: str = log_url(kwargs['namespace'])


def log_url(namespace, container='base'):
    """
    kibana log url template for airflow job resources
    namespace: k8s namespace
    container: pod container name
    """
    s = """%27{{ ti.start_date.date().isoformat() }}%27"""
    e = """%27{{ (ti.start_date + macros.timedelta(days=1)).date().isoformat() }}%27"""
    url = """{{ var.value.get('es_url') }}/app/discover#/?_g=(filters:!(),refreshInterval:(pause:!t,value:0),""" + \
        'time:(from:' + s + ',to:' + e + '))' + \
        """&_a=(columns:!(log),filters:!(),hideChart:!t,""" + \
        """index:%273b33e795-4ec2-4e0e-a833-eae3ca3983e5%27,interval:auto,""" + \
        """query:(language:kuery,query:%27""" + \
        """kubernetes.labels.airflow-dag.keyword%20:%20%22{{ dag.dag_id }}%22%20""" + \
        """and%20kubernetes.namespace_name.keyword%20:%20%22""" + namespace + """%22%20""" + \
        """and%20kubernetes.labels.airflow-ds.keyword%20:%20%22{{ ds_nodash }}%22%20""" + \
        """and%20kubernetes.labels.airflow-task.keyword%20:%20%22{{ task.task_id }}%22%20""" + \
        """and%20kubernetes.container_name.keyword%20:%20%22""" + container + """%22%20""" + \
        """%27),rowHeight:0,sort:!(!(%27@timestamp%27,desc)))"""

    return url



def spark3_task(dag: DAG, spark_app_name: str, spark_app_spec: dict, namespace: str = None) -> SmartSparkK8sOperator:
    """
    Make airflow task
    @param dag:
    @param spark_app_name:
    @param spark_app_spec: CRD definition: {
        "apiVersion": "sparkoperator.hpe.com/v1beta2",
        "kind": "SparkApplication",
        ...
    }
    @param namespace: override k8s namespace
    @return:
    """
    _namespace, spark_app_spec = apply_spark3_settings(dag, namespace, spark_app_name, spark_app_spec)
    group_id = 'spark-' + spark_app_name

    submit = SmartSparkK8sOperator(
        task_id=group_id,
        namespace=_namespace,
        application_file=json.dumps(spark_app_spec, indent=4),
        do_xcom_push=True,
        api_group="sparkoperator.hpe.com",
        enable_impersonation_from_ldap_user=False,
        dag=dag,
        retries=1,
        retry_delay=timedelta(seconds=30),
        log_url=log_url(_namespace, 'spark-kubernetes-driver')
    )
    return submit