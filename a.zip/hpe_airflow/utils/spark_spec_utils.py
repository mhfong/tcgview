import random
import string
from utils.git_utils import GitPvc
from utils.git_utils import GitRepositories
from utils.airflow_utils import k8s_namespace, airflow_job_labels
class GitSyncInitContainer:

    def __init__(self,
                name: str,
                repo: GitRepositories,
                destination:str,
                branch:str,
                volume_mount_name: str) -> dict:
        
        """
        Class to extract init container spec for Gitsync
        @param name: git sync container name in a pod
        @param repo: GitRepositories object in git_utils
        @param destination: /airflow-working-dir/{{ dag.dag_id }}_{{ run_id | sanitize }}/<destination>
        @param branch: branch name required in repo
        @param volume_mount_name: which volume name representing volume in your yaml setting.
        """
        self.name = name
        self.repo = repo.value
        self.destination = destination
        self.branch = branch
        self.volume_mount_name = volume_mount_name

    @property
    def volume_mount_path(self):
        return "/directory"
    
    @property
    def root_without_mount(self):
        return "airflow-working-dir/{{ dag.dag_id }}_{{ run_id | sanitize }}"
    
    @property
    def root_path(self): # with mount path
        return f"{self.volume_mount_path}/{self.root_without_mount}"
    
    @property
    def source_folder_path(self):

        return  f"{self.root_without_mount}/{self.destination}"
    
    def __call__(self):

        return {
        "name": self.name,
        "securityContext": {
            "runAsUser": 0
        },
        "image": "docker.io/smtds/git-sync:v3.6.3",
        "resources": {
            "requests":{
                "memory": "1000Mi",
                "cpu": "250m"
                },
            "limits": {
                "memory": "1000Mi",
                "cpu": "250m"
            }
        },
        "volumeMounts":[
            {
            "name": self.volume_mount_name,
            "mountPath": "/directory"
                },
        ],
        "env":[
            {"name": "GIT_SYNC_REPO", "value": self.repo},
            {"name": "GIT_SYNC_DEST", "value": self.destination},
            {"name": "GIT_SYNC_ROOT", "value": self.root_path},
            {"name": "GIT_SYNC_BRANCH","value": self.branch },
            {"name": "GIT_SYNC_ONE_TIME", "value": "true"},
            {"name": "GIT_SYNC_REV"},
            {"name": "HTTP_PROXY"},
            {"name": "HTTPS_PROXY"},
            {"name": "GIT_SYNC_GIT_CONFIG", "value": "http.sslVerify:false"},
            {"name": "GIT_SYNC_PASSWORD",
                "valueFrom": 
                {"secretKeyRef": 
                    {"key": "password",
                    "name": "airflow-gitrepo-password"
                    }
                }
            },
            {"name": "GIT_SYNC_USERNAME","value": "dw_dwsup_04@smartone.com"},
            {"name": "GIT_SYNC_PERMISSIONS","value": "0755"}
        ]

        }
    
    def __repr__(self):

        return f"GitSyncInitContainer(name={self.name}, repo={self.repo}, branch={self.branch})"
    
    def __str__(self):

        return f"GitSyncInitContainer(name={self.name}, repo={self.repo}, branch={self.branch})"
    
class SparkDriver:

    def __init__(self,
                core: int,
                memory: str,
                env: list,
                volumeMounts: list,
                initcontainer: list=None,
                affinity: list = None) -> dict:
        """_summary_

        Args:
            core (str): number of cores, maximum : "5"/5
            memory (str): amount of memory per executor, such as "50g"
            env (list): list of env
            volumeMounts (list): list of volumeMounts dictionary ('name'-'mountPath' pair)
            initcontainer (list, optional): list of InitContainer. Defaults to None.

        Returns:
            dict: _description_
        """
        assert isinstance(affinity, list) or affinity is None
        self.core=int(core)
        self.memory=memory
        self.env = env
        self.volumeMounts = volumeMounts
        self.initcontainer = initcontainer
        self.affinity = affinity
        
        # restrict core number
        if int(self.core) > 5:
            self.core = 5

    def __call__(self):

        driver_spec =  {
                "cores": self.core,
                "coreLimit": str(self.core*1000) + "m",
                "memory": self.memory,
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2",
                },
                "volumeMounts": self.volumeMounts
            }
        if self.initcontainer is not None:

            driver_spec['initContainers'] = list(map(lambda container: container(), self.initcontainer))

        if self.env is not None:

            driver_spec['env'] = self.env

        if self.affinity is not None:
            driver_spec["affinity"] = {
                "nodeAffinity":{
                    "requiredDuringSchedulingIgnoredDuringExecution": {
                        "nodeSelectorTerms": [
                            {"matchExpressions": [
                                {"key": "kubernetes.io/hostname",
                                 "operator": "In",
                                 "values": self.affinity}
                            ]}
                        ]
                    }
                }
            }
        return driver_spec
    
    def __repr__(self):
        
        if self.initcontainer is not None:
            return f"{self.__class__.__name__}(core={self.core}, memory={self.memory}, initcontainer={self.initcontainer})"
        else:
            return f"{self.__class__.__name__}(core={self.core}, memory={self.memory})"
    
class SparkExecutor:

    def __init__(self,
                core: int,
                memory: str,
                instances: int,
                env: list = [],
                volumeMounts: list = [],
                affinity: list = None) -> dict:
        """

        Args:
            core (str): number of cores, maximum : "5"/5
            memory (str): amount of memory per executor, such as "50g"
            instances (int): amount of spark executors. Maximum: 10
            env (list): list of env variable dictionary ('name'-'value' pairs)
            volumeMounts (list): list of volumeMounts dictionary ('name'-'mountPath' pairs)

        Returns:
            dict: _description_
        """
        assert isinstance(affinity, list) or affinity is None
        self.core=int(core)
        self.memory=memory
        self.instances = instances
        self.env = env
        self.volumeMounts = volumeMounts
        self.affinity = affinity
        # restrict core number
        if int(self.core) > 5:
            self.core = 5

        # restrict instances number
        if int(self.instances) > 10:
            self.instances = 10

    def __call__(self):
        
        exec_spec =  {

                "cores": self.core,
                "coreLimit": str(self.core*1000) + "m",
                "instances": self.instances,
                "memory": f"{self.memory}",
                "labels": {
                    "version": "2.4.7",
                    "hpecp.hpe.com/dtap": "hadoop2"
                }
            }
        
        if self.env != [] or self.env is not None:
            exec_spec["env"] = self.env

        if self.volumeMounts != [] or self.volumeMounts is not None:
            exec_spec["volumeMounts"] = self.volumeMounts

        if self.affinity is not None:
            exec_spec["affinity"] = {
                "nodeAffinity":{
                    "requiredDuringSchedulingIgnoredDuringExecution": {
                        "nodeSelectorTerms": [
                            {"matchExpressions": [
                                {"key": "kubernetes.io/hostname",
                                 "operator": "In",
                                 "values": self.affinity}
                            ]}
                        ]
                    }
                }
            }
        return exec_spec
    
    def __repr__(self):

        return f"{self.__class__.__name__}(core={self.core}, memory={self.memory})"

class BaseVolume():

    def __init__(self,name: str) -> dict:
        
        self.name = name

    def __call__(self):

        volume_spec = {
                        "name": self.name,
                    }

        return volume_spec
    
    def __repr__(self):

        return f"Volume(name={self.name})"

class EmptyVolume(BaseVolume):
    
    def __init__(self, name: str):
        super().__init__(name)

    def __call__(self):

        volume_spec =  super().__call__()
        volume_spec["emptyDir"] = {}

        return volume_spec
    
    def __repr__(self):

        return f"{self.__class__.__name__}(name={self.name}, Dir=emptyDir)"
    
class PVCVolume(BaseVolume):
    def __init__(self, name: str, PVC: GitPvc):

        super().__init__(name)
        self.PVC = PVC
        self.name = name
    def __call__(self, is_readOnly = False):

        volume_spec = super().__call__()
        volume_spec["persistentVolumeClaim"] = {
            "claimName": self.PVC.value,
            "readOnly": is_readOnly
        }

        return volume_spec
    
    def __repr__(self):

        return f"{self.__class__.__name__}(name={self.name}, Dir=PVCVolume({self.PVC.value}))"
    

class SparkApplication():

    def __init__(self, driver: SparkDriver, executor: SparkExecutor, volumes: list):

        self.driver = driver
        self.executor = executor
        self.volumes = volumes

    def get_spec(self, path_to_py: str ,generateName: str, args: list=[]):

        letters = string.ascii_lowercase

        return {
            "apiVersion": "sparkoperator.hpe.com/v1beta2",
            "kind": "SparkApplication",
            "metadata": {
                "generateName": generateName + "-",
                "namespace": k8s_namespace()
            },
            "spec": {
                "sparkConf": {
                    "spark.mapr.user.secret": "mapr-user-secret-livy",
                    "spark.hadoop.fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
                    "spark.hadoop.fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
                    "spark.hadoop.fs.dtap.impl.disable.cache": "false",
                    "spark.driver.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                    "spark.executor.extraClassPath": "local:///opt/bdfs/bluedata-dtap.jar",
                    "spark.driver.maxResultSize": "0",
                    "spark.rpc.message.maxSize": "512",
                    "spark.kubernetes.executor.podNamePrefix": generateName + "-" + ''.join(random.choice(letters) for i in range(5))

                },
                "type": "Python",
                "sparkVersion": "2.4.7",
                "pythonVersion": "3",
                "mode": "cluster",
                "image": "smtds/spark-py-2.4.7-oracle:20231103commonutil",
                "imagePullPolicy": "Always",
                "mainApplicationFile": path_to_py,
                "arguments": args,
                "restartPolicy": {
                    "type": "Never"
                },
                "imagePullSecrets": [
                    "imagepull",
                    "smtds-dockerhub-secret"
                ],
                "driver": self.driver(),
                "executor": self.executor(),
                "volumes": list(map(lambda volume: volume(), self.volumes))
            }
        }
