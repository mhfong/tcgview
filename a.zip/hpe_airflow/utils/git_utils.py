
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from kubernetes.client import models as k8s
from enum import Enum
from utils.airflow_utils import k8s_namespace, airflow_job_labels
from airflow.utils.trigger_rule import TriggerRule
from typing import Optional


def get_branch_by_k8s_namespace() -> str:
    """
    get the correct git sync branch using the k8s namespace, dev / prod environment is separated by k8s namespace.
    """
    current_airflow_namespace = k8s_namespace()
    return {
        'smt-apps': 'dev',
        'c360-project': 'prod',
    }[current_airflow_namespace]


class GitRepositories(Enum):
    # user "vendor" needs to have access to following repos
    BIRDIE = 'https://apgitscpl01.smartone.com/ds_datascience_grp/birdie.git'
    C360 = 'https://apgitscpl01.smartone.com/C360_DS_GRP/C360.git'
    C360_DATA_STAGING = 'https://apgitscpl01.smartone.com/ds_datascience_grp/c360_data_staging.git'
    CALLLOG = 'https://apgitscpl01.smartone.com/ds_datascience_grp/calllog.git'
    CNSS = 'https://apgitscpl01.smartone.com/ds_datascience_grp/cnss_weblog.git'
    DASHBOARD = 'https://apgitscpl01.smartone.com/ds_datascience_grp/dashboard.git'
    FOOTPRINT_SHKP = 'https://apgitscpl01.smartone.com/ds_datascience_grp/geolocation.git'
    GEOLOCATION_STOP = 'https://apgitscpl01.smartone.com/ds_datascience_grp/geolocation_stop.git'
    GOV_STAT = 'https://apgitscpl01.smartone.com/ds_datascience_grp/gov_stats.git'
    HPE_CUSTOM = "https://apgitscpl01.smartone.com/ds_datascience_grp/hpe_k8s_custom.git"
    NETWORK_DATA_ANALYSIS = "https://apgitscpl01.smartone.com/ds_datascience_grp/network-data-analysis.git"
    OFFER_MATCHING = 'https://apgitscpl01.smartone.com/C360_DS_GRP/smt-offer-matching-engine.git'
    OFFER_MATCHING_MULTI_SIM = 'https://apgitscpl01.smartone.com/C360_DS_GRP/smt-offer-matching-engine-multi-sim.git'
    OFFER_MATCHING_UPLIFT = 'https://apgitscpl01.smartone.com/C360_DS_GRP/smt-retention-uplift-engine.git'
    PERSONAS = 'https://apgitscpl01.smartone.com/ds_datascience_grp/personas.git'
    SEGMENTATION_WORKER = 'https://apgitscpl01.smartone.com/ds_datascience_grp/segmentation_worker.git'
    SEGMENTATION_WEB = 'https://apgitscpl01.smartone.com/ds_datascience_grp/segmentation_web.git'
    TEST_DATA_DRIFT = 'https://apgitscpl01.smartone.com/ds_datascience_grp/walter-workspace.git'
    TESLA_SHKP = 'https://apgitscpl01.smartone.com/ds_datascience_grp/tesla_daily_job_for_shkp.git'
    WEBLOG = 'https://apgitscpl01.smartone.com/ds_datascience_grp/weblog.git'
    WEBLOG_5GHBB = "https://apgitscpl01.smartone.com/ds_datascience_grp/5ghbb.git"
    AIRTABLE_DATA_STAGING = 'https://apgitscpl01.smartone.com/ds_datascience_grp/airtable_data_staging.git'
    HANDSET = 'https://apgitscpl01.smartone.com/ds_datascience_grp/handset.git'
    COMMON_DATABASE = 'https://apgitscpl01.smartone.com/ds_datascience_grp/cdb.git'
    OFFER_ASSIGNMENT_JOBS = 'https://apgitscpl01.smartone.com/ds_datascience_grp/offer_assignment_jobs.git'
    OFFER_ASSIGNMENT_WEB = 'https://apgitscpl01.smartone.com/ds_datascience_grp/offer_assignment_web.git'
    LOAD_AIRTABLE_DATA_TO_ADW = 'https://apgitscpl01.smartone.com/dw_infomgt_grp/dw_gz_grp/prj_airtable.git'


    def repo_name(self) -> str:
        repo_name = self.value.split('/')[-1]
        return repo_name.split('.')[0]


class GitSyncSubmodules(Enum):
    RECURSIVE = 'recursive'
    SHALLOW = 'shallow'
    OFF = 'off'


class GitPvc(Enum):
    C360_STAGING = 'git-pvc-data-staging-airflow'
    C360 = 'c360-airflow-dependencies-pvc'
    TESLA = 'git-pvc-tesla-airflow'
    FOOTPRINT = 'git-pvc-footprint'
    C360_GE = 'great-expectations-pvc'


# default mount path for Git PVC
MOUNT_PATHS = {
    GitPvc.C360: '/c360-airflow-dependencies-vol',
    GitPvc.C360_STAGING: '/c360-airflow-dependencies-vol',
    GitPvc.TESLA: '/tesla-airflow-dependencies-vol',
    GitPvc.FOOTPRINT: '/footprint-airflow-dependencies-vol',
    GitPvc.C360_GE: '/great-expectations-pvc-vol',
}


def git_clone_init_container(
        repo: GitRepositories, branch: str,
        submodules: GitSyncSubmodules = GitSyncSubmodules.OFF,
        more_memory: bool = False,
        tag: Optional[str] = None
) -> k8s.V1Container:
    """
    Container of Git Sync image to be used as init containers.
    Needs empty dir volume for git files and git password file:
    "volumes": [
        {
            "name": "git-volume",
            "emptyDir": {}
        },
        {
            "name": 'secret-volume',
            "secret": {
                "secretName": "git-password-secret"
            }
        }
    ]
    @param repo:
    @param branch:
    @param submodules:
    @param more_memory: True to request 4Gi, otherwise 1Gi
    @param tag: which git tag to sync, optional
    @return:
    """
    env_dict = {
        'GIT_SYNC_REPO': repo.value,
        'GIT_SYNC_USERNAME': 'vendor',
        'GIT_SYNC_PASSWORD_FILE': '/etc/secret-volume/git-password-file',
        'GIT_SYNC_DEST': repo.repo_name(),
        'GIT_SYNC_ROOT': '/home/git',
        'GIT_SYNC_BRANCH': branch,
        'GIT_SYNC_ONE_TIME': 'true',
        'GIT_SYNC_SUBMODULES': submodules.value
    }
    if tag:
        env_dict['GIT_SYNC_REV'] = tag

    memory = '4Gi' if more_memory else '1Gi'
    container = k8s.V1Container(
        name='git-clone',
        image='docker.io/smtds/git-sync:v3.6.3',
        resources=k8s.V1ResourceRequirements(
            limits={"cpu": "1", "memory": memory},
            requests={"cpu": "1", "memory": memory}
        ),
        env=[k8s.V1EnvVar(name=k, value=v) for k, v in env_dict.items()],
        volume_mounts=[
            k8s.V1VolumeMount(
                mount_path='/home/git',
                name="git-volume",
            ),
            k8s.V1VolumeMount(
                mount_path="/etc/secret-volume",
                name="secret-volume",
                read_only=True
            )
        ]
    )
    return container


def git_clone_init_container_dict(
        repo: GitRepositories, branch: str,
        submodules: GitSyncSubmodules = GitSyncSubmodules.OFF,
        more_memory: bool = False,
        tag: Optional[str] = None
) -> dict:
    """
    Container of Git Sync image to be used as init containers, but as a dict
    @param repo:
    @param branch:
    @param submodules:
    @param more_memory:
    @return:
    """
    def _to_camel(s):
        def upper_first(w):
            if w == '':
                return w

            else:
                return w[0].upper() + w[1:]

        words = s.split('_')
        return words[0] + ''.join([upper_first(w) for w in words[1:]])

    def _remove_none_values(d: dict) -> dict:
        # {'a_p': 'a', 'b': None} -> {'aP': 'a'}
        if isinstance(d, list):
            return [
                _remove_none_values(e) for e in d if e is not None
            ]
        elif isinstance(d, dict):
            return {_to_camel(k): _remove_none_values(v) for k, v in d.items() if v is not None}

        else:
            return d

    container_dict = git_clone_init_container(repo, branch, submodules, more_memory, tag).to_dict()
    # need to remove None values, otherwise k8s will return error
    return _remove_none_values(container_dict)


class GitSyncOperator(KubernetesPodOperator):

    def __init__(
            self, *, repo: GitRepositories, branch: str, pvc: GitPvc,
            username: str = 'vendor', namespace: str = None,
            **kwargs
    ):
        """
        Git Sync k8s pod operator, for downloading git repos into a PVC drive
        @param repo: repo to sync GitRepositories
        @param branch:
        @param pvc: which PVC to sync the files to
        @param username: git username
        @param namespace: override k8s namespace of the pod
        @param kwargs:
        """
        self.template_fields += ('env_vars_dict', )
        git_volume_mount_path = MOUNT_PATHS.get(pvc, '/c360-airflow-dependencies-vol')
        git_sync_root = git_volume_mount_path + '/airflow-working-dir/{{ dag.dag_id }}_{{ run_id | sanitize }}'
        git_sync_dest = repo.repo_name()
        self.env_vars_dict = {
            'GIT_SYNC_REPO': repo.value,
            'GIT_SYNC_USERNAME': username,
            'GIT_SYNC_PASSWORD_FILE': '/etc/secret-volume/git-password-file',
            'GIT_SYNC_DEST': git_sync_dest,
            'GIT_SYNC_ROOT': git_sync_root,
            'GIT_SYNC_BRANCH': branch,
            'GIT_SYNC_ONE_TIME': 'true'
        }
        labels = airflow_job_labels()
        labels['hpecp.hpe.com/dtap'] = 'hadoop2-job'

        super().__init__(
            namespace=namespace if namespace is not None else k8s_namespace(),
            image='docker.io/smtds/git-sync:v3.6.3',
            env_vars=[],
            labels=labels,
            resources=k8s.V1ResourceRequirements(
                limits={
                    "cpu": "1", "memory": "1Gi"
                },
                requests={
                    "cpu": "1", "memory": "1Gi"
                }
            ),
            volumes=[
                k8s.V1Volume(
                    name="c360-airflow-dependencies-vol",
                    persistent_volume_claim=k8s.V1PersistentVolumeClaimVolumeSource(
                        claim_name=pvc.value,
                        read_only=False
                    ),
                ),
                k8s.V1Volume(
                    name='secret-volume',
                    secret=k8s.V1SecretVolumeSource(
                        secret_name='git-password-secret'
                    )
                )
            ],
            volume_mounts=[
                k8s.V1VolumeMount(
                    mount_path=git_volume_mount_path,
                    name="c360-airflow-dependencies-vol",
                ),
                k8s.V1VolumeMount(
                    mount_path="/etc/secret-volume",
                    name="secret-volume",
                    read_only=True
                ),
            ],
            name="git-sync-name",
            reattach_on_restart=False,
            **kwargs
        )

    def execute(self, context):
        # unable to get V1EnvVar to render according to templates. Had to use dict instead.
        print(self.env_vars_dict)
        self.env_vars = [
            k8s.V1EnvVar(name=n, value=v) for n, v in self.env_vars_dict.items()
        ]
        return super().execute(context)


class GitSynCleanUpOperator(KubernetesPodOperator):

    def __init__(self, *, pvc: GitPvc, namespace: str = None, **kwargs):
        """
        Clean up git files from a PVC from the same DAG run
        @param pvc: which PVC to sync the files to
        @param kwargs:
        """
        git_volume_mount_path = MOUNT_PATHS.get(pvc, '/c360-airflow-dependencies-vol')
        labels = airflow_job_labels()
        labels['hpecp.hpe.com/dtap'] = 'hadoop2-job'

        super().__init__(
            namespace=namespace if namespace is not None else k8s_namespace(),
            image="debian:bullseye-slim",
            labels=labels,
            cmds=[
                "/bin/rm"
            ],
            arguments=[
                "-rf",
                git_volume_mount_path + "/airflow-working-dir/{{ dag.dag_id }}_{{ run_id | sanitize }}/"
            ],
            resources=k8s.V1ResourceRequirements(
                limits={"cpu": "1", "memory": "1Gi"},
                requests={"cpu": "1", "memory": "1Gi"}
            ),
            volumes=[
                k8s.V1Volume(
                    name="c360-airflow-dependencies-vol",
                    persistent_volume_claim=k8s.V1PersistentVolumeClaimVolumeSource(
                        claim_name=pvc.value,
                        read_only=False
                    ),
                ),
            ],
            volume_mounts=[
                k8s.V1VolumeMount(
                    mount_path=git_volume_mount_path,
                    name="c360-airflow-dependencies-vol",
                )
            ],
            name="git-cleanup-name",
            reattach_on_restart=False,
            trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
            **kwargs
        )
