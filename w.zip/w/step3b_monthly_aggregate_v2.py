import argparse
import logging
import sys
from datetime import datetime

import pyspark.sql.functions as F
from dateutil.relativedelta import relativedelta
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, DecimalType
from weblog_util.paths import domain_daily, domain_monthly_v2


# Logger
logger = logging.getLogger(__name__)
log_format = "[%(asctime)s][%(funcName)25s:%(lineno)4d] %(message)s"
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=log_format)


def main(run_month):
    spark = SparkSession.builder.appName("weblog-monthly-v2").getOrCreate()
    # define sc for checking to closing spark

    ## --------------------------------- Get Sdfs ------------------------------ ##
    # t domain daily, filtered by current month
    run_month = run_month[:7] + '-01'
    sdf_tdd_cm = spark.read.parquet(domain_daily).withColumn(
        '_filter', F.trunc(F.to_date(F.col('date_id').cast(StringType()), 'yyyyMMdd'), 'mon')
    ).filter(
        f"_filter = '{run_month}'"
    ).drop('_filter')

    # t domain monthly
    # sdf_tdm = spark.read.parquet(t_domain_monthly_dir)

    ## ------------------------------- Aggregate -------------------------------- ##
    # get days of a month
    count_days = sdf_tdd_cm.select('date_id').distinct().count()

    # check if all t doamin daily ready and t domain monthly not exist
    run_month_dt = datetime.strptime(run_month, '%Y-%m-%d')
    days_in_month = (run_month_dt + relativedelta(months=1) - run_month_dt).days

    if count_days == days_in_month:
        logging.info('Ready to generate t domain monthly')

        logging.info('Ready to generate t domain monthly')

        # preprocessing
        # day of month
        sdf_tdd_cm = sdf_tdd_cm.withColumn('day_of_month', F.substring(F.col('date_id'), 7, 2).cast('int')) \
            .withColumn("dom_rpad", F.expr("rpad('1',day_of_month,'0')").cast(DecimalType(31, 0))) \
            .withColumn('last_day_in_month', F.lit(days_in_month))
        # aggregate
        sdf_tdm_new = sdf_tdd_cm.groupby(['subr_num', 'agg_value', 'agg_level']) \
            .agg(
            F.sum(F.col('in_byte')).alias('in_byte'),
            F.sum(F.col('out_byte')).alias('out_byte'),
            F.sum(F.col('byte_count')).alias('byte_count'),
            F.sum(F.col('total_hit')).alias('total_hit'),
            F.sum(F.col('duration')).alias('duration'),
            F.countDistinct('date_id').alias('days'),
            F.sum("dom_rpad").cast(DecimalType(31, 0)).alias("dom_rpad_sum"),
            F.max("last_day_in_month").alias("last_day_in_month")) \
            .withColumn('dom_binary', F.expr("reverse(lpad(dom_rpad_sum,last_day_in_month,'0'))")) \
            .drop('last_day_in_month', 'dom_rpad_sum')

        # write
        month_id = run_month_dt.strftime('%Y%m')
        # no need to delete old directory since checked above
        sdf_tdm_new.write.mode('overwrite') \
            .parquet(f'{domain_monthly_v2}/month_id={month_id}')
    else:
        logging.info(f'Not Ready to generate t domain monthly. Number of days of data for now: {count_days}')

    logging.info(f"End, {datetime.now()}")


if __name__ == '__main__':
    # parser
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_month', type=str, help='yyyy-mm')
    args = parser.parse_args()

    main(args.run_month)