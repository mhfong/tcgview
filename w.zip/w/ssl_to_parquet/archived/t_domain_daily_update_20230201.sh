#!/bin/sh

# update_domain_index
python3 /app/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/1_in01_9999_update_domain_index_manual.py 

# t doamin daily 
python3 /app/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/2_in01_9999_daily_aggregrate_manual.py