#############################################
#### Daily Aggregrage
# 1 dictionary is done
# 2 aggreage both domain, tag and tag_gp
#############################################

import cx_Oracle
import pandas as pd
from smtutil import common
from smtutil import hiveutil
from datetime import datetime
import numpy as np
import csv, pickle

sc, spark = hiveutil.get_sc_spark()
hiveutil.register_common_udf(spark)

# refresh table
spark.sql("""
refresh PRD_BIZ_SUMM_VW.VW_IDP_SSL_SED_CALL_SUMM
""")

# get dates to load
dates_to_loaded = spark.sql("""
with t_loaded as (
    select distinct
        date_id
    from weblog.t_domain_daily
), t_legal as (
    select distinct
        date_id
    from PRD_BIZ_SUMM_VW.VW_IDP_SSL_SED_CALL_SUMM
)
select 
    t_legal.date_id
from t_legal
left join t_loaded
    on t_legal.date_id = t_loaded.date_id
where t_loaded.date_id is null
and t_legal.date_id >= 20200101
order by t_legal.date_id desc
limit 4
""").toPandas().date_id
dates_to_loaded = list(dates_to_loaded)
dates_to_loaded

## ---------------- 1. List to Aggregation ----------------  ##
# get list of existing t doamin daily tables
spark.sql("refresh weblog.t_domain_daily")
spark.sql("""
with t as (
    select distinct
        date_id
    from weblog.t_domain_daily
)
select
    left(date_id, 6) as month_id,
    count(*) as days
from t
group by month_id
order by month_id
""").toPandas()

# get list of existing t tags tables
spark.sql("refresh weblog.t_tag_daily")
spark.sql("""
with t as (
    select distinct
        date_id
    from weblog.t_tag_daily
)
select
    left(date_id, 6) as month_id,
    count(*) as days
from t
group by month_id
order by month_id
""").toPandas()

# get list of existing t tag groups tables
spark.sql("refresh weblog.t_tag_gp_daily")
spark.sql("""
with t as (
    select distinct
        date_id
    from weblog.t_tag_gp_daily
)
select
    left(date_id, 6) as month_id,
    count(*) as days
from t
group by month_id
order by month_id
""").toPandas()

## ---------------- 2. Aggregate Domain ----------------  ##
print(f'[Info] Date to load: {dates_to_loaded}')

# load t_domain_daily for each date
for date_id in dates_to_loaded: # 20 mins
    print(date_id, datetime.now())
    spark.sql(f"alter table weblog.t_domain_daily drop if exists partition (date_id={date_id})")
    spark.sql("""
    select
        subr_num,
        domain_index as agg_value,
        'domain' as agg_level,
        0 as in_byte,
        0 as out_byte,
        byte_count,
        total_hit,
        0 as duration,
        date_id
    from prd_biz_summ_vw.vw_idp_ssl_sed_call_summ
    join weblog.t_domain_index
        on vw_idp_ssl_sed_call_summ.ssl_cert_domain = t_domain_index.domain
    where date_id = {date_id}
    """.format(
        date_id=date_id
    ))\
        .coalesce(10)\
        .write.mode('append')\
        .partitionBy('date_id')\
        .saveAsTable('weblog.t_domain_daily')
print(datetime.now())

## ---------------- 3. Aggregate Tag ----------------  ##

# spark.sql("""
# select *
# from weblog.t_tag_dictionary
# limit 2
# """).toPandas()

# for date_id in dates_to_loaded: # 20 mins        
#     print(date_id, datetime.now()) # 1 min
#     spark.sql(f"alter table weblog.t_tag_daily drop if exists partition (date_id={date_id})")
#     spark.sql("""
#     with t_tag_dictionary as (
#         select
#             t_tag_dictionary.tag_gp,
#             t_tag_dictionary.tag,

#             t_tag_dictionary.agg_value,
#             t_tag_dictionary.agg_level,

#             t_domain_dictionary.agg_value as domain_index
#         from weblog.t_tag_dictionary
#         join weblog.t_domain_dictionary
#             on t_tag_dictionary.tag_gp = t_domain_dictionary.tag_gp
#             and t_tag_dictionary.tag = t_domain_dictionary.tag
#         where t_tag_dictionary.default_aggregation = 1
#     )
#     select
#         subr_num,
#         t_tag_dictionary.agg_value,
#         t_tag_dictionary.agg_level,
#         sum(in_byte) as in_byte,
#         sum(out_byte) as out_byte,
#         sum(byte_count) as byte_count,
#         sum(total_hit) as total_hit,
#         0 as duration,
#         date_id
#     from weblog.t_domain_daily
#     join t_tag_dictionary
#         on t_tag_dictionary.domain_index = t_domain_daily.agg_value
#     where date_id = '{date_id}'
#     group by subr_num, date_id, t_tag_dictionary.agg_value, t_tag_dictionary.agg_level
#     """.format(
#         date_id=date_id
#     ))\
#         .coalesce(10)\
#         .write.mode('append')\
#         .partitionBy('date_id')\
#         .saveAsTable('weblog.t_tag_daily')
# print(datetime.now())

## ---------------- 4. Aggregate Tag Group ----------------  ##

# for date_id in dates_to_loaded: # 15 mins    
#     print(date_id, datetime.now())
    
#     spark.sql(f"alter table weblog.t_tag_gp_daily drop if exists partition (date_id={date_id})")
#     spark.sql("""
#     with t_tag_dictionary as (
#         select
#             t_tag_gp_dictionary.tag_gp,
#             t_tag_gp_dictionary.tag,

#             t_tag_gp_dictionary.agg_value,
#             t_tag_gp_dictionary.agg_level,

#             t_domain_dictionary.agg_value as domain_index
#         from weblog.t_tag_gp_dictionary
#         join weblog.t_domain_dictionary
#             on t_tag_gp_dictionary.tag_gp = t_domain_dictionary.tag_gp
#         where t_tag_gp_dictionary.default_aggregation = 1
#     )
#     select
#         subr_num,
#         t_tag_dictionary.agg_value,
#         t_tag_dictionary.agg_level,
#         sum(in_byte) as in_byte,
#         sum(out_byte) as out_byte,
#         sum(byte_count) as byte_count,
#         sum(total_hit) as total_hit,
#         0 as duration,
#         date_id
#     from weblog.t_domain_daily
#     join t_tag_dictionary
#         on t_tag_dictionary.domain_index = t_domain_daily.agg_value
#     where date_id = '{date_id}'
#     group by subr_num, date_id, t_tag_dictionary.agg_value, t_tag_dictionary.agg_level
#     """.format(
#         date_id=date_id
#     ))\
#         .coalesce(10)\
#         .write.mode('append')\
#         .partitionBy('date_id')\
#         .saveAsTable('weblog.t_tag_gp_daily')
# print(datetime.now())

# stop spark session and spark content
spark.stop()
sc.stop()
