#!/usr/bin/env python
# coding: utf-8

from pathlib import Path
import yaml
import argparse
from datetime import datetime

def main(derived_dir):
    
    # get current timestamp
    time_now = datetime.now().timestamp()
    
    for child in Path(derived_dir).glob('*'):
        if child.is_file() and (time_now - child.stat().st_mtime > 86400):
            child.unlink()
    # print(f'[Info] Deleted files in {derived_dir}')
    return

if __name__ == '__main__':

    # parser
    parser = argparse.ArgumentParser(description='.yaml config file path, should be the same as sslweb_csv_to_parquet.py')
    parser.add_argument('--cfg', type=str, default='/app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/testing/config_test.yaml',
                        help='.yaml config file path')
    args = parser.parse_args()

    # load yaml
    fhandle = open(args.cfg,'r')
    cfg = yaml.safe_load(fhandle)

    # get derived dir path
    derived_dir = cfg['derived_dir']

    main(derived_dir)