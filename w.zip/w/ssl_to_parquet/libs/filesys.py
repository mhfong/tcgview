from pyspark.sql import SparkSession

def get_spark_fs(spark: SparkSession, uri):

    """get spark file system object.

    Returns:
        fs: FileSystem object in pyspark jvm object.
    """
    
    sc = spark.sparkContext
    jvm = sc._jvm
    conf = sc._jsc.hadoopConfiguration()
    url = uri
    uri = jvm.java.net.URI(url)
    fs = jvm.org.apache.hadoop.fs.FileSystem.get(uri, conf)

    return fs
def is_exist(spark: SparkSession, check_path: str):
    """Check file exist using jvm.

    Args:
        spark (SparkSession): spark session

    Returns:
        bool: if True, the folder/ file exists. Otherwise, False

    """
    assert isinstance(check_path, str), "Please input check_path with string data type"

    fs = get_spark_fs(spark, check_path)

    return fs.exists(spark.sparkContext._jvm.org.apache.hadoop.fs.Path(check_path))
