import os
import re
import subprocess

from pyarrow import csv as pv
from pyarrow import hdfs
from pyarrow import parquet as pq


def try_hdfs_for_hpe_notebook():
    """
    Try setting up env for pyarrow HDFS access
    """
    if re.search(r'hadoop-common[^/]+.jar', os.environ.get('CLASSPATH', '')):
        return

    hadoop_classpath_args = ('hadoop', 'classpath', '--glob')
    classpath = subprocess.check_output(hadoop_classpath_args)

    os.environ['CLASSPATH'] = classpath.decode('utf-8')
    os.environ['ARROW_LIBHDFS_DIR'] = os.environ.get('ARROW_LIBHDFS_DIR', '/opt/bluedata/hadoop-2.8.5/lib/native')


def read_parquet_file(dtap_uri):
    try_hdfs_for_hpe_notebook()
    input_fs = hdfs.connect(dtap_uri)
    df = pq.ParquetDataset(path_or_paths=dtap_uri,
                              filesystem=input_fs,
                              use_legacy_dataset=True
                ).read().to_pandas(safe=False)
    return df
    

def read_csv_file(dtap_uri):
    try_hdfs_for_hpe_notebook()
    input_fs = hdfs.connect(dtap_uri)
    with input_fs.open(dtap_uri, "rb") as f:
        table = pv.read_csv(f)
    df = table.to_pandas()
    return df