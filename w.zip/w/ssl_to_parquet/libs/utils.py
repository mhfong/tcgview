from datetime import datetime as dt

# function to get dates
def get_date_vars(file_export_date, bw_date_st=3, duration=2, bw_date_st_village=8):
    
    fed = dt.strptime(file_export_date, '%Y%m%d')
    
    # get 3 days if Monday
    if fed.weekday() == 0:
        bw_date_st = 4
        duration = 3
    
    d_call_start=dt.strftime(fed-timedelta(days=bw_date_st), '%Y-%m-%d')
    d_call_end=dt.strftime(fed-timedelta(days=bw_date_st-duration+1), '%Y-%m-%d')
    val_agg_period_start=int(d_call_start.replace('-', ''))
    val_agg_period_end=int(d_call_end.replace('-', ''))

    val_agg_period_start_village=int(dt.strftime(fed-timedelta(days=bw_date_st_village), '%Y%m%d'))

    return d_call_start, d_call_end, val_agg_period_start, val_agg_period_end, val_agg_period_start_village

