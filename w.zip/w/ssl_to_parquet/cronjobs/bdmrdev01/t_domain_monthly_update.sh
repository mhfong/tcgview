#!/bin/sh

# # t domain monthly
# python3 /app/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/1_in01_9999_update_domain_index_manual.py 
python3 /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/monthly_aggregate.py --cfg '/app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/config_pipeline_bdmrdev01.yaml'
