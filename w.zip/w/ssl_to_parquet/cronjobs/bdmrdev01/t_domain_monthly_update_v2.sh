#!/bin/sh
# # t domain monthly
python3 /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/monthly_aggregate_v2.py --cfg '/app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/config_monthly_agg_v2_bemrdev01.yaml'