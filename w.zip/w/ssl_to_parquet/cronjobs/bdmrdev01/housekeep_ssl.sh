ssl_deleted_dir=/app/sna_bdmrdev03/weblog_ssl_data_deleted/; export ssl_deleted_dir;
ssl_03_dir=/app/sna_bdmrdev03/weblog_ssl_data/; export ssl_03_dir;
ssl_01_dir=/app/ws-ic/hive/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ/; export ssl_01_dir;

## part1 ssl_data_delete
cd $ssl_03_dir

ym=`date -d "$(date +%Y-%m-1) -15 month" +"%Y%m"` #15 months

# echo "./date_id=$ym*"
# mv "date_id=${ym}*" "/app/weblog_ssl_housekeep_v2/"

find . -name "date_id=$ym*" -exec mv -t "$ssl_deleted_dir" {} +
echo "removed date with date_id=$ym*" `date`

## part2 ssl_data_transfer
cd $ssl_01_dir

ym=`date -d "$(date +%Y-%m-1) -7 month" +"%Y%m"` #15 months

# echo "./date_id=$ym*"
# mv "date_id=${ym}*" "/app/weblog_ssl_housekeep_v2/"

find . -name "date_id=$ym*" -exec mv -t "$ssl_03_dir" {} +
echo "moved date with date_id=$ym* from 01 to 03" `date`