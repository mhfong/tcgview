#!/bin/sh

# run to parquet python script
python3 /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/raw/sslweb_csv_to_parquet.py --cfg '/app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/raw/config.yaml' # --ts 20230518

# echo sslweb_csv_to_parquet.py OK

# testing only
# move from derived to testing folder
# find /app/sna_bdmrdev03/ws-simon/data/sslweb/derived/ -type f | wc -l
# cp -r /app/sna_bdmrdev03/ws-simon/data/sslweb/derived/. /app/sna_bdmrdev03/ws-simon/data/sslweb/testing/
# echo copied to testing OK

# testing only
# check outputs and remove
# find /app/sna_bdmrdev03/ws-simon/data/sslweb/raw/. -type d | wc -l
# rm -rf /app/sna_bdmrdev03/ws-simon/data/sslweb/raw/*
# echo remove raw OKFREQUENT_TRAVELER_CHINA_MACAU = auto()