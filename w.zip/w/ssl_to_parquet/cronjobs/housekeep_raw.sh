#!/bin/sh

# get number of files before deletion
# echo [Info] Number of files before: $(find /app/weblog_ssl_housekeep/ -type f | wc -l)

# clean derived files > 1 day
# find /app/weblog_ssl_housekeep/ -type f -mmin +1440 -exec rm -rf {} \;
python3 /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/raw/sslweb_delete.py --cfg '/app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/raw/config.yaml'

# get number of files after deletion
# echo [Info] Number of files after: $(find /app/weblog_ssl_housekeep/ -type f | wc -l)

date