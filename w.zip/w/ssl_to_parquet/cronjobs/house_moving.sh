#!/bin/sh

python3 /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/pipeline/3_notin01_9999_house_moving.py
