#!/bin/sh

# get number of files before deletion
echo [Info] Number of files before: $(find /app/sna_bdmrdev03/ws-simon/data/sslweb/derived/ -type f | wc -l)

# clean derived files > 1 day
find /app/sna_bdmrdev03/ws-simon/data/sslweb/derived/ -type f -mmin -1440 -exec rm -rf {} \;

# get number of files after deletion
echo [Info] Number of files after: $(find /app/sna_bdmrdev03/ws-simon/data/sslweb/derived/ -type f | wc -l)

date