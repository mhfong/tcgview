# Weblog SSL Data


## Data Size

Size of one day raw data ~= **60G** 

Size of one day parquet output data ~= **6G** 

Size of one day t_doamin_daily ~= **3G**

Size of one month t_doamin_monthly ~= **19G**


## Directories

| data | path | remark |
|--|--|--|
|project directory|/app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/||
|raw data|/app/sna_bdmrdev01/t_ssl/raw||
|raw data (processing)|/app/sna_bdmrdev01/t_ssl/working/|if raw_to_ssl cronjob failed, usually you can find the raw data in this folder|
|weblog ssl data|/app/sna_bdmrdev01/ws-ic/hive/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ/||
|t domain daily data| /app/sna_bdmrdev01/ws-ic/hive/weblog.db/t_domain_daily/||
|t domain monthly data|/app/sna_bdmrdev01/ws-ic/hive/weblog.db/t_domain_monthly/||
|t domain monthly data v2|/app/sna_bdmrdev01/ws-ic/hive/weblog_v2.db/t_domain_monthly/||
|raw data - housekeeping|/app/sna_bdmrdev01/weblog_ssl_housekeep/|housekeeping data with modified time over 24 hours will be deleted daily|
|weblog ssl data - housekeeping|/app/sna_bdmrdev03/weblog_ssl_data/||
|weblog ssl data - to be delete|/app/sna_bdmrdev03/weblog_ssl_data_deleted/|folder for weblog_ssl_data housekeep script test, data inside can be deleted anytime|
|log| /app/sna_bdmrdev03/ws-simon/logs/weblog/ssl_to_parquet/ | logs of weblog cronjobs|

## Cronjobs
try to RUN  
```
sed -i '/session    required     pam_loginuid.so/c\#session    required   pam_loginuid.so' /etc/pam.d/cron
```  
if cronjob is not working

### 1. Process DW raw data
This job will transform DW weblog raw data and save parquet output data

#### Frequency
Daily, 4:00 a.m.

#### Location
bdmrdev03:9994

#### Cronjob
```
0 4 * * * sh /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/cronjobs/raw_to_ssl.sh > /app/sna_bdmrdev03/ws-simon/logs/weblog/ssl_to_parquet/raw_to_ssl.log 2>&1
```
### 2. Delete DW raw data every 24 hrs
This job will delete data in housekeeping data directory with modified time over 24 hours

#### Frequency
Daily, 11:50 p.m.

#### Location
bdmrdev03:9994

#### Cronjob
```
50 23 * * * sh /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/cronjobs/housekeep_raw.sh >> /app/sna_bdmrdev03/ws-simon/logs/weblog/ssl_to_parquet/housekeep_raw.log 2>&1
```

### 3. t_domain_daily table update
This job will update t doamin daily table every 24 hours

#### Frequency
Daily, 7:00 a.m.

#### Location
bdmrdev03:9994

#### Cronjob
```
0 7 * * * sh /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/cronjobs/t_domain_daily_update.sh > /app/sna_bdmrdev03/ws-simon/logs/weblog/ssl_to_parquet/t_domain_daily_update.log 2>&1
```
### 4. generate housemoving project output csv

#### Frequency
Daily, 4:00 a.m.

#### Location
bdmrdev01:9999

#### Cronjob
```
0 4 * * 1,3,5 sh /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/cronjobs/house_moving.sh > /app/sna_bdmrdev03/ws-simon/logs/weblog/ssl_to_parquet/house_moving.log 2>&1
```

### 5. gen t_domain_monthly 

#### Frequency
Monthly, 6:30 p.m., 1st of the month

#### Location
bdmrdev03:9994

#### Cronjob
```
30 18 1 * * sh /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/cronjobs/t_domain_monthly_update.sh > /app/sna_bdmrdev03/ws-simon/logs/weblog/ssl_to_parquet/t_domain_monthly_update.log 2>&1
```

### 6. gen t_domain_monthly version 2

#### Frequency
Monthly, 6:30 p.m., 3rd of the month

#### Location
bdmrdev03:9994

#### Cronjob
```
30 18 2 * * sh /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/cronjobs/t_domain_monthly_update_v2.sh > /app/sna_bdmrdev03/ws-simon/logs/weblog/ssl_to_parquet/t_domain_monthly_update_v2.log 2>&1
```

### 7. housekeeping ssl data

#### Frequency
Monthly, 8:50 p.m., 1st of the month

#### Location
bdmrdev03:9994

#### Cronjob
```
50 20 1 * * sh /app/sna_bdmrdev03/ws-simon/git_repo/weblog/ssl_to_parquet/cronjobs/housekeep_ssl.sh >> /app/sna_bdmrdev03/ws-simon/logs/weblog/ssl_to_parquet/housekeep_ssl.log 2>&1
```

### 8. upload t_domain_monthly to ext_mapr

#### Frequency
Monthly, 6:00 a.m., 2nd of the month

#### Location
bdmrdev03 (hdssmart), .sh path: /home/hdssmart/cronjob/scripts/t_domain_monthly_upload.sh

#### Cronjob
```
0 6 3 * * sh /home/hdssmart/cronjob/scripts/t_domain_monthly_upload.sh > /tmp/t_domain_monthly_upload.log 2>&1
```

### 9. upload t_domain_daily to ext_mapr & delete t_domain_daily data of 61 days before

#### Frequency
Daily, 4:00 p.m.

#### Location
bdmrdev03 (hdssmart), .sh path: /home/hdssmart/cronjob/scripts/t_domain_daily_upload.sh

#### Cronjob
```
0 16 * * * sh /home/hdssmart/cronjob/scripts/t_domain_daily_upload.sh >> /tmp/t_domain_daily_upload.log 2>&1
```

### 10. upload t_domain_monthly_v2 to ext_mapr

#### Frequency
Monthly, 6:00 a.m., 4th of the month

#### Location
bdmrdev03 (hdssmart), .sh path: /home/hdssmart/cronjob/scripts/t_domain_monthly_v2_upload.sh

#### Cronjob
```
0 6 4 * * sh /home/hdssmart/cronjob/scripts/t_domain_monthly_v2_upload.sh >> /tmp/t_domain_monthly_v2_upload.log 2>&1
```

## Manual Preprocessing

#### Run every Mon, Wed, Fri (Retired)
1. **1_in01_9999_update_domain_index_manual.ipynb**
update weblog.t_domain_index and weblog.t_domain_dictionary
2. **2_in01_9999_daily_aggregrate_manual.ipynb**
aggreage domain, tag and tag_gp data to daily domain, tag and tag_gp data
rmk: if skipped running for some day(s) (e.g. holiday on Monday), please run multiple times and check if all missing t_domain_daily data in **domain daily aggragated data: /app/sna_bdmrdev01/ws-ic/hive/weblog.db/t_domain_daily/** is generated. Each time the script can generate up to 4 days of t_domain_daily data.


## Projects

### 1. House Moving

#### Frequency:

Every Mon, Wed, Fri

#### Current State:

Automated

#### Procedures (Auto):
1. Check if there is .csv data output in output_path = **/app/sna_bdmrdev02/data_out/to_Cognos_De_SMS/De_5G_BB_{file_export_date}.csv** on Mon, Wed, Fri

#### Procedures (Manual):

1. Run Manual Preprocessing notebook 1 and 2 in bdmrdev01:9999 (if not yet run on that day)
2. Change **file_export_date** in **3_notin01_9999_house_moving.ipynb** to expected file export date
3. Run **3_notin01_9999_house_moving.ipynb** in bdmrdev01 but not in port 9999
4. Check if there is .csv data output in output_path = **/app/sna_bdmrdev02/data_out/to_Cognos_De_SMS/De_5G_BB_{file_export_date}.csv**

#### Segment and Criteria:

**Home Mover** + **BB Provider** + **Village Property**

Monday: run previous 3 days

Wed: run previous 2 days

Friday: run previous 2 days

|  **Segment**  | **Criteria** |
| ------------- | ------------- |
| **1. Home Mover** | 1. select customers with house_moving_usage > 0 in the past few days | 
|               | 2. exclude 5GBB existing base |
|               | 3. deduplicate customer who receive this house moving SMS in past 30 days |
| **2. BB provider** | 1. select customers with NETVIGATOR_USAGE > 0  or with HKBN_USAGE usage > 0 in the past 7 days | 
|               | 2. exclude 5GBB existing base |
|               | 3. deduplicate customer who receive this house moving SMS in past 30 days |
|               | 4. Regular automated sent out in every week|
| **3. Village property agent** | 1. select customers with village property agent usage > 0  in the past 7 days | 
|               | 2. exclude 5GBB existing base |
|               | 3. deduplicate customer who receive this village property agent SMS in past 30 days |
|               | 4. Regular automated sent out in every week |
|               | P.S village property agent data will be ready in Cognos by end of Sep |

## Health Check
all logs of 03 cronjob is at log at `/app/sna_bdmrdev03/ws-simon/logs/` 

### 1. Raw Data -> SSL Data Output

Check **/app/sna_bdmrdev01/ws-ic/hive/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ/**  
  
e.g. on 20230322, check if there is /app/ws-ic/hive/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ/date_id=20230321  

### 2. SSL Data -> t_domain_daily

Check **/app/sna_bdmrdev01/ws-ic/hive/weblog.db/t_domain_daily/**
  
e.g. on 20230322, check if there is /app/sna_bdmrdev01/ws-ic/hive/weblog.db/t_domain_daily/date_id=20230321  

### 3. t_domain_daily -> t_domain_monthly, t_domain_monthly_v2  
Check **/app/sna_bdmrdev01/ws-ic/hive/weblog.db/t_domain_monthly/** and **/app/sna_bdmrdev01/ws-ic/hive/weblog_v2.db/t_domain_monthly/**
  
e.g. on 20230402, check if there is /app/sna_bdmrdev01/ws-ic/hive/weblog.db/t_domain_monthly/month_id=202303

### 4. House Moving Project Output
Check if there is .csv data output in output_path = **/app/sna_bdmrdev02/data_out/to_Cognos_De_SMS/De_5G_BB_{file_export_date}.csv** on Mon, Wed, Fri

