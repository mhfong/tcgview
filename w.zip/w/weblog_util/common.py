
import os

import pyspark.sql.functions as F
from pyspark.sql import SparkSession


def getCleansedDomainList(raw_domain_list:list):
    """
    Clean the raw web domain
    
    :param raw_domain_list: list contains raw web domamin strings
    :returns: list contains cleansed web domain strings
    """
    cleansed_domain_list=[]
    for value in raw_domain_list:
        if value.find('//')!=-1:
            value=value.split('//')[1]
        if value.find('/')!=-1:
            value=value.split('/')[0]
        if len(value)<=3:
            break
        value=value.replace(' ','').upper()
        cleansed_domain_list.append(value)

    return cleansed_domain_list


def getAggValue(spark: SparkSession, domain_list: list, fpath_t_domain_index: str):
    """
    Check if the temp view name exists

    :param spark: spark session
    :param domain_list: Web Domain List you would like to find their agg value
    :returns: Temp View which contains your agg value
    """
    # Get Domain List Cleansed
    cleansed_domain_list=getCleansedDomainList(domain_list)
    
    # Read web domain dicitionary: domain|agg_value
    sdf_domain_dict=spark.read.parquet(fpath_t_domain_index)
    
    # Get Agg value of Target Domains
    sdf_domain_agg_value=sdf_domain_dict.filter(F.col('domain').rlike("|".join(cleansed_domain_list))).select(F.col('domain_index').alias('agg_value'))
    
    return sdf_domain_agg_value



def getDomainSummary(spark: SparkSession, agg_value_table: object, agg_freq: str, agg_period_start: str, agg_period_end: str,app_name: str, fpath_t_domain_table: str, filter_table=None):
    """
    Aggregate following Weblog Features with Web Domain Agg Value
        -  Sum of Data Usage in byte 
        -  Maximum of Total Hit
        -  Maximum of Day Used

    :param agg_value_table: Web Domain Agg Value Table
    :param agg_freq: Aggeration Frequncy ('daily','weekly','monthly')
    :param agg_period_start: Aggreate period start time in following format:
                                - daily: yyyymmdd
                                - weekly: yyyymmdd
                                - monthly: yyyymm
    :param agg_period_end: Aggreate period end time with same format of agg_period_start
    :param app_name: Column of Application name in the output 
    :param filter_table: Optional, inner join table on `SUBR_NUM` 

    :returns: Temp View of Aggerate Domain Summary:
            
    :raises ValueError: When You have input wrong agg_freq
    
    TODO:
    1. Add CUST_NUM from filter_table if it exists.
    """

    if int(agg_period_start) > int(agg_period_end):
            correct_agg_period_end=agg_period_start
            agg_period_start=agg_period_end
            agg_period_end=correct_agg_period_end

    if agg_freq == 'daily':
            t_domain_table='t_domain_daily'
            t_domain_time_key='date_id'
    # elif agg_freq == 'weekly':
    #     t_domain_table='t_domain_weekly'
    #     t_domain_time_key='week_id'
    elif agg_freq == 'monthly':
        t_domain_table='t_domain_monthly'
        t_domain_time_key='month_id'
    else:
        raise ValueError("Wrong agg_freq received. Please input correct agg_freq (daily, weekly, monthly)")

    # sdf_domain_table=spark.read.parquet(f"/app/ws-ic/hive/weblog.db/{t_domain_table}").where(f"{t_domain_time_key} between {agg_period_start} and  {agg_period_end}")
    if agg_period_start == agg_period_end:
        sdf_domain_table = spark.read.parquet(os.path.join(fpath_t_domain_table, f"{t_domain_table}/{t_domain_time_key}={agg_period_start}/"))
        # add month_id column
        sdf_domain_table = sdf_domain_table.withColumn(t_domain_time_key, F.lit(agg_period_start))
    else:
        sdf_domain_table=spark.read.parquet(os.path.join(fpath_t_domain_table, f"{t_domain_table}")).where(f"{t_domain_time_key} between {agg_period_start} and {agg_period_end}")

    sdf_domain_table=sdf_domain_table.join(agg_value_table, sdf_domain_table.agg_value==agg_value_table.agg_value, 'inner').select(sdf_domain_table['*'])
    
    for col in sdf_domain_table.columns:
        sdf_domain_table=sdf_domain_table.withColumnRenamed(col, col.upper())
    
    if filter_table:
        sdf_domain_table=sdf_domain_table.join(filter_table,sdf_domain_table.SUBR_NUM==filter_table.SUBR_NUM,'inner').select(sdf_domain_table['*'])

    groupby_list= ['SUBR_NUM',t_domain_time_key]
    if agg_freq == 'daily':
        res_domain=sdf_domain_table.groupby(groupby_list).agg(F.sum('BYTE_COUNT').alias('TOTAL_BYTE_COUNT'),
                                                              F.sum('TOTAL_HIT').alias('TOTAL_HIT')
                                                             ).fillna(0).withColumn('APPS',F.lit(app_name))
    else:
        res_domain=sdf_domain_table.groupby(groupby_list).agg(F.sum('BYTE_COUNT').alias('TOTAL_BYTE_COUNT'),
                                                              F.sum('TOTAL_HIT').alias('TOTAL_HIT'),
                                                              F.max('DAYS').alias('MAX_DAYS')
                                                             ).fillna(0).withColumn('APPS',F.lit(app_name))

    return res_domain