import os
from pyspark.sql import SparkSession
from smartone_airtable import AirtableBase, AirtableTable
from enum import Enum
from weblog_util.paths import domain_lists
from datetime import datetime


class DomainList(Enum):
    phishing_website = 'PHISHING_APP'
    travel_website = 'TRAVEL_APP'
    university_website = 'UNIVERSITY_APP'
    family_website = 'FAMILY_APP'
    northbound_driver_website = 'NORTHBOUND_DRIVER_APP'
    driver_website = 'DRIVER_APP'
    games_website = 'GAMES_APP'
    house_moving_website = 'HOUSE_MOVING_APP'
    all_website = 'ALL_APP'


class TableID(Enum):
    PHISHING_APP ='tbldChKSuweYgRuaz'
    TRAVEL_APP = 'tbl2VceVg52CnyGFz'
    UNIVERSITY_APP = 'tblrfnWwjKfiG2hnn'
    FAMILY_APP = 'tblTXHVoiw1qBf0eV'
    NORTHBOUND_DRIVER_APP = 'tblGAR9Diwfc5LJgx'
    DRIVER_APP = 'tblvS0mIDbWxlKnxX'
    GAMES_APP = 'tbl4eDlSK5NO09MxD'
    HOUSE_MOVING_APP = 'tblLRh7k3D1SeMDWD'
    ALL_APP = 'tblKgTtacAWvDvpKf'


class ViewID(Enum):
    PHISHING_APP = 'viwHT4qIZDNqYaNf2'
    TRAVEL_APP = 'viwXBoLSI74LTqhhL'
    UNIVERSITY_APP = 'viwmVzttLMhrcUSZz'
    FAMILY_APP = 'viwODTslKy3z77BQ7'
    NORTHBOUND_DRIVER_APP = 'viwAeehpkEIqSQxva'
    DRIVER_APP = 'viwpwnuuFjpL8PbMA'
    GAMES_APP = 'viwYS0tEMdg2NeAMg'
    HOUSE_MOVING_APP = 'viwFvEf65Lu61Rrbg'
    ALL_APP = 'viwEUgBWeIpJqAdZS'


def save_airtable(spark: SparkSession, run_date: datetime, tag: str):
    base = AirtableBase(
        at_base_id='appeRJ6bwaCKgc4Tu',
        personal_access_token=os.environ['AIRTABLE_ACCESS_TOKEN'],
        proxy_url='apispxyp01.hksmartone.com:443'
    )

    table = AirtableTable(
        base=base,
        table_id=TableID[tag].value,
        view_id=ViewID[tag].value,
        flatten=True
    )

    airtable = spark.createDataFrame(table.to_pandas()).select('domain', 'APP', 'CATEGORY', 'TAG')
    path_date = run_date
    if not isinstance(path_date, str):
        path_date = run_date.strftime('%Y%m%d')
    airtable.coalesce(1).write.format("csv").option("header", "true").mode("overwrite").save(
        f'{domain_lists}/run_date={path_date}/{tag}.csv'
    )