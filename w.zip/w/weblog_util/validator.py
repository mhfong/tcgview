class Validator:
    df = None

    def __init__(self, df):
        self.df = df

    def check_value_counts(self, column, value_dicts):

        def _get_value_dict(value_dicts, value):
            for value_dict in value_dicts:
                if value_dict['value'] == value:
                    return value_dict
            raise Exception(f"value: {value} not found in value_dicts: {value_dicts}")

        self.df[column] = self.df[column].astype(str)
        column_value_counts = self.df[column].value_counts().to_dict()

        for value in column_value_counts:

            value_dict = _get_value_dict(value_dicts, value)

            value = value_dict.get("value")
            min_value = value_dict.get("min_value")
            strict_min = value_dict.get("strict_min")
            max_value = value_dict.get("max_value")
            strict_max = value_dict.get("strict_max")

            if value not in column_value_counts:
                return {"success": False, "result": {"observed_value": column_value_counts}}

            if min_value is not None:
                if strict_min:
                    above_min = column_value_counts[value] > min_value
                else:
                    above_min = column_value_counts[value] >= min_value
            else:
                above_min = True

            if max_value is not None:
                if strict_max:
                    below_max = column_value_counts[value] < max_value
                else:
                    below_max = column_value_counts[value] <= max_value
            else:
                below_max = True

            success = above_min and below_max
            if not success:
                return {"success": False, "result": {"observed_value": column_value_counts}}
        return {"success": True, "result": {"observed_value": column_value_counts}}
