from enum import Enum


class DomainChecklist(Enum):
    DOMAIN_GOOGLE = 1 
    DOMAIN_FACEBOOK = 2 
    DOMAIN_APPLE = 3 
    DOMAIN_OUTLOOK = 4 
    DOMAIN_KMB = 5 
    DOMAIN_OPENRICE = 6 
    DOMAIN_YOUTUBE = 7 
    DOMAIN_WHATSAPP = 8 
    DOMAIN_WEATHER = 9 
    DOMAIN_TAOBAO = 10
    DOMAIN_INSTAGRAM = 11

    @property
    def DOMAINS(self) -> str:
        return DOMAINS.get(self)
    
    @property
    def INDEX(self) -> str:
        return INDEX.get(self)


DOMAINS = {
    DomainChecklist.DOMAIN_GOOGLE: 'WWW.GOOGLE.COM',
    DomainChecklist.DOMAIN_FACEBOOK: 'WWW.FACEBOOK.COM',
    DomainChecklist.DOMAIN_APPLE: 'APPLE.COM',
    DomainChecklist.DOMAIN_OUTLOOK: 'OUTLOOK.OFFICE365.COM',
    DomainChecklist.DOMAIN_KMB: 'APP.KMB.HK',
    DomainChecklist.DOMAIN_OPENRICE: 'API.OPENRICE.COM',
    DomainChecklist.DOMAIN_YOUTUBE: 'WWW.YOUTUBE.COM',
    DomainChecklist.DOMAIN_WHATSAPP: 'DIT.WHATSAPP.NET',
    DomainChecklist.DOMAIN_WEATHER: 'PDA.WEATHER.GOV.HK',
    DomainChecklist.DOMAIN_TAOBAO: 'TAOBAO.COM',
    DomainChecklist.DOMAIN_INSTAGRAM: 'WWW.INSTAGRAM.COM'
}


INDEX = {
    DomainChecklist.DOMAIN_GOOGLE: 36833,
    DomainChecklist.DOMAIN_FACEBOOK: 58410,
    DomainChecklist.DOMAIN_APPLE: 20173,
    DomainChecklist.DOMAIN_OUTLOOK: 2411,
    DomainChecklist.DOMAIN_KMB: 20594,
    DomainChecklist.DOMAIN_OPENRICE: 13074,
    DomainChecklist.DOMAIN_YOUTUBE: 43570,
    DomainChecklist.DOMAIN_WHATSAPP: 80703,
    DomainChecklist.DOMAIN_WEATHER: 57399,
    DomainChecklist.DOMAIN_TAOBAO: 53178,
    DomainChecklist.DOMAIN_INSTAGRAM: 59230
}