import argparse
from datetime import datetime, timedelta

from pyspark.sql import SparkSession

from weblog_util.validator import Validator
from weblog_util.paths import housemoving_output


def get_housemoving_date_dict(file_export_date):
    date_obj = datetime.strptime(file_export_date, "%Y%m%d")
    date_id = date_obj.strftime('%Y%m%d')  # Convert date to string format
    
    # past_date_ids T-2 to T-9
    past_start_date = date_obj - timedelta(days=8)
    past_end_date = date_obj - timedelta(days=1)
    past_date_ids = []
    while past_start_date < past_end_date:
        past_date_ids.append(past_start_date.strftime("%Y%m%d"))
        past_start_date += timedelta(days=1)
    
    return {'date_id': date_id, 'weekday': date_obj.weekday(), 'past_date_ids': past_date_ids}


def main(file_export_date):
    
    # get spark session
    spark = SparkSession \
            .builder \
            .appName("housemoving-validate") \
            .getOrCreate()
    
    date_dict = get_housemoving_date_dict(file_export_date)
    date_id = date_dict['date_id']
    print(f"loading date_id: {date_id}")
    fpath = housemoving_output.format(file_export_date=date_id)
    sdf = spark.read.option("header", "true").csv(fpath)
    df = sdf.toPandas()

    value_dicts = []
    date_index_bound = 3 if date_dict['weekday'] == 0 else 2
    for index, past_date_id in enumerate(sorted(date_dict['past_date_ids'], reverse=True)):
        if index < date_index_bound:
            min_value = 1000
            max_value = 30000
        else:
            min_value = 1
            max_value = 1000

        value_dicts.append({"value": past_date_id, "min_value": min_value, "max_value": max_value, "strict_min": True, "strict_max": True})

    validator = Validator(df)
    validation_result = validator.check_value_counts("DATE", value_dicts)

    # add other validations here
    print(f"validation_result: {validation_result}")
    assert validation_result['success'] == True
    print(f"file: {fpath} validation success")


if __name__ == '__main__':

    # parser
    parser = argparse.ArgumentParser(description='config')
    parser.add_argument('run_date', type=str, default='', help='file export date (yyyymmdd), default will get today')
    args = parser.parse_args()

    main(file_export_date=args.run_date)
