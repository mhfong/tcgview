import argparse
import logging
import sys
from datetime import datetime, timedelta

import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from weblog_util.paths import ssl_parquet, domain_index_daily, domain_index_latest


logger = logging.getLogger(__name__)
log_format = "[%(asctime)s][%(funcName)25s:%(lineno)4d] %(message)s"
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=log_format)


def main(run_date: str, count_filter=50):
    spark = SparkSession.builder.appName("weblog-index").getOrCreate()

    previous_run_date = (datetime.strptime(run_date, '%Y-%m-%d') - timedelta(days=1)).date().isoformat()

    # check the parquet folder exists
    partition_key = "part_key"
    full_ssl_path = f"{ssl_parquet}/{partition_key}={str(run_date.replace('-', ''))}"
    full_domain_index_path = f"{domain_index_daily}/{partition_key}={str(previous_run_date.replace('-', ''))}"

    # read ssl data
    sdf = spark.read.parquet(full_ssl_path)
    sdf_tdi = spark.read.parquet(full_domain_index_path)

    logging.info("Read ssl data and t domain index data")

    ## ---------------- 1. Update Domain Index ----------------  ##
    # t domain count
    sdf_t_domain_count = sdf.select('ssl_cert_domain').groupby(
        'ssl_cert_domain'
    ).agg(F.count('*').alias('c'))

    # add filter >= 50
    sdf_t_domain_count = sdf_t_domain_count.filter(F.col('c') >= count_filter)

    ## t doamin index new

    # t doamin index new
    sdf_t_domain_index_new = sdf_t_domain_count \
        .join(sdf_tdi, sdf_t_domain_count.ssl_cert_domain == sdf_tdi.domain, 'outer') \
        .drop('o_domain_index') \
        .select(
        F.when(~F.col('ssl_cert_domain').isNull(), F.col('ssl_cert_domain')).otherwise(F.col('domain')).alias('domain'),
        F.col('domain_index').alias('o_domain_index').cast('string'),
        F.row_number().over(Window.orderBy(F.col('domain_index').asc_nulls_last())).alias('domain_index'),
    )
    #         .select(
    #             F.when(~F.col('ssl_cert_domain').isNull(), F.col('ssl_cert_domain')).otherwise(F.col('domain')).alias('domain'),
    #             F.col('domain_index').alias('o_domain_index'),
    #             F.row_number().over(window_spec_c).alias('domain_index'),
    #         )

    logging.info("Joined new t domain index table")

    part_key = run_date.replace('-', '')
    sdf_t_domain_index_new.write.mode('overwrite').parquet(f'{domain_index_daily}/part_key={part_key}')
    # write new t_domain_index table
    sdf_t_domain_index_new.coalesce(10).write.mode('overwrite').parquet(domain_index_latest)


if __name__ == '__main__':

    # parser
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str,
                        default='',
                        help='')
    args = parser.parse_args()

    main(args.run_date)
