from pyspark.sql import SparkSession
from pyspark.sql.functions import broadcast
import argparse
from datetime import datetime, timedelta
from subscribers_by_websites.visit_travel_website_subscribers import travel_intent
from subscribers_by_websites.visit_university_website_subscribers import university_student
from subscribers_by_websites.visit_family_website_subscribers import family_member
from subscribers_by_websites.visit_northbound_driver_website_subscribers import northbound_driver
from subscribers_by_websites.visit_games_website_subscribers import gamer
from subscribers_by_websites.visit_driver_website_subscribers import driver
from subscribers_by_websites.visit_house_moving_website_subscribers import house_mover
from subscribers_by_websites.visit_phishing_website_subscribers import phishing
from weblog_util.save_airtable import save_airtable, TableID
from weblog_util.paths import domain_lists, domain_index_latest, domain_daily


ALL_WEBSITES = {
    'house_moving_website': house_mover,
    'driver_website': driver,
    'travel_website': travel_intent,
    'university_website': university_student,
    'family_website': family_member,
    'northbound_driver_website': northbound_driver,
    'games_website': gamer,
    'phishing_website': phishing
}


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str, default='', help='yyyy-mm-dd of the date of data files')
    args = parser.parse_args()

    spark = SparkSession.builder.appName("websites_subscribers").getOrCreate()

    if args.run_date == 'yyyy-mm-dd':
        run_date = (datetime.now() - timedelta(days=2))
    else:
        run_date = datetime.strptime(args.run_date, '%Y-%m-%d')

    for table in TableID:
        save_airtable(spark, run_date, table.name)

    yyyymmdd = run_date.strftime('%Y%m%d')
    airtable = spark.read.csv([f'{domain_lists}/run_date={yyyymmdd}/{t.name}.csv' for t in TableID], header=True)
    index = spark.read.parquet(domain_index_latest).withColumnRenamed('domain_index', 'agg_value').cache()
    weblog = spark.read.option("basePath", domain_daily).parquet(
            *[
                f'{domain_daily}/date_id=' + (run_date - timedelta(days=i)).strftime('%Y%m%d')
                for i in range(365)
            ]
        ).select('SUBR_NUM', 'agg_value', 'byte_count', 'date_id')

    airtable_with_index = index.join(broadcast(airtable), 'domain', 'inner').cache()
    weblog = weblog.join(broadcast(airtable_with_index), 'agg_value', 'inner').cache()

    for tag, func in ALL_WEBSITES.items():
        func(spark, run_date, tag, weblog)