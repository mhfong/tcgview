#!/bin/bash

src_root=/HDS_VOL_DS/weblog/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ

dest_root=/sna2/weblog/ssl_to_parquet

t_90=$(date -d "90 days ago" +%Y%m%d)

echo "start backup T-90 ssl_to_parquet from ext_mapr to 03"


file="part_key=${t_90}"
src_path="${src_root}/${file}"
echo "src_path: $src_path"

dest_path="${dest_root}"
echo "dest_path: $dest_path"

# copy the data to local
if hadoop fs -test -e $src_path; then
    echo "file exists"
    hadoop fs -copyToLocal $src_path $dest_path
else
    echo "file does not exist, continue"
fi
echo "--------"