#!/bin/bash

src_root=/HDS_VOL_DS/weblog/t_domain_index_daily

dest_root=/sna2/weblog/t_domain_index_daily

t_3=$(date -d "3 days ago" +%Y%m%d)

echo "start backup T-90 t_domain_index_daily from ext_mapr to 03"


file="part_key=${t_3}"
src_path="${src_root}/${file}"
echo "src_path: $src_path"

dest_path="${dest_root}"
echo "dest_path: $dest_path"

# copy the data to local
if hadoop fs -test -e $src_path; then
    echo "file exists"
    hadoop fs -copyToLocal $src_path $dest_path
else
    echo "file does not exist, continue"
fi
echo "--------"