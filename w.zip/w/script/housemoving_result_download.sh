#!/bin/bash

src_root=/HDS_VOL_DS/weblog/data_out/to_Cognos_De_SMS

# testing destination path
dest_root=/home/hdssmart/cronjob/scripts/housemoving/data
# production destination path
#dest_root=/sna_bdmrdev02/data_out/to_Cognos_De_SMS

echo "start running housemoving uploader"

# get T-0 date
num=0
year=`date --date="${num} days ago" +"%Y"`
month=`date --date="${num} days ago" +"%Y%m"`
date=`date --date="${num} days ago" +"%Y%m%d"`

# for debug, set date = 20220401
year=2023
month=202311
date=20231117

echo "year_id=$year month_id=$month date_id=$date"

# filename
file="De_5G_BB_${date}.csv"

src_path="${src_root}/${file}/*.csv"
echo "src_path: $src_path"

dest_path="${dest_root}/${file}"
echo "dest_path: $dest_path"

# copy the data to local
if hadoop fs -test -e $src_path; then
    echo "file exists"
    hadoop fs -copyToLocal $src_path $dest_path
else
    echo "file does not exist, continue"
fi
echo "--------"
