Weblog SSL data

Background
This notebook needs to be run daily to generate the weblog data. This is the first step to run early in the morning. We need to automate it in order to remove the manual work.

Steps to run the notebook


enter analytical server notebook (03) under your own namespace
http://bdmrdev03:9994/lab/workspaces/(your namespace)
e.g.
http://bdmrdev03:9994/lab/workspaces/ws-pong


find the notebook import_VW_IDP_SSL_SED_CALL_SUMM_2.ipynb
under ws-jerry/smc_load/import_VW_IDP_SSL_SED_CALL_SUMM_2.ipynb


Run all cells



Note

Data depends on /app/sna_bdmrdev01/ws-ic/hive/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ/date_id=*

it will run T-2 instead of T-1 since data is not ready yet
