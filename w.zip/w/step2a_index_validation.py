import argparse
import logging
import sys

from pyspark.sql.functions import col
from pyspark.sql import SparkSession
from weblog_util.paths import domain_index_latest
from weblog_util.domain_checklist import DomainChecklist


logger = logging.getLogger(__name__)
log_format = "[%(asctime)s][%(funcName)25s:%(lineno)4d] %(message)s"
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=log_format)


def main():
    # define sc for checking to closing spark
    spark = SparkSession.builder.getOrCreate()

    t_domain_index = spark.read.parquet(domain_index_latest)

    for domain in DomainChecklist:
        check_df = t_domain_index.filter(
            (col('domain') == domain.DOMAINS) & (col('domain_index') == domain.INDEX)
        )
        if check_df.count() == 1:
            print(f'Case: {domain.DOMAINS} passed')
        else:
            raise ValueError(f"Error: Case {domain.DOMAINS} failed.")


if __name__ == '__main__':

    # parser
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str,
                        default='',
                        help='')
    args = parser.parse_args()
    main()
