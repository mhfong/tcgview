from weblog_util.paths import domain_daily, domain_index_daily
from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
import string
import random
import os, binascii
import numpy as np
from pyspark.sql import functions as f
import argparse
import logging
import sys

logger = logging.getLogger(__name__)
log_format = "[%(asctime)s][%(funcName)25s:%(lineno)4d] %(message)s"
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=log_format)


def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))


class Checker:
    name = None
    hard_check = False
    is_pass_checker = False

    def __init__(self, hard_check=False):
        self.hard_check = hard_check

    def check(self, data: DataFrame):
        raise NotImplementedError("Please Add details in check functions")


class CheckerChain:

    def __init__(self, *args):
        for arg in args:
            if not isinstance(arg, Checker):
                raise TypeError("Chain input must be Checker")

        self.checkers = args

    def checkall(self, data: DataFrame):

        length_checkers = len(self.checkers)

        _pass = False
        _pass_records = []
        msgs = {}
        result = {}
        if length_checkers == 0:
            raise Exception("Length is 0. Please check checkers size")

        if length_checkers == 1:
            _pass, msg = self.checkers[0].check(data)
            msgs.update(msg)
            return _pass, msgs

        if length_checkers > 1:

            for index, checker in enumerate(self.checkers):
                print(f"Using {checker.name}")
                if index == len(self.checkers):
                    break

                if index == 0:
                    _single_pass, _single_msg = checker.check(data)
                    _pass_records.append(_single_pass)
                    msgs = {**msgs, **_single_msg}
                    continue

                previous_checker = self.checkers[index - 1]
                current_checker = checker
                Validatebridge = ValidateCheckerBridge(previous_checker, current_checker)
                if Validatebridge.validate_checker():

                    _single_pass, _single_msg = current_checker.check(data)
                    _pass_records.append(_single_pass)
                    msgs = {**msgs, **_single_msg}

                else:

                    return _pass, msgs

            if all(_pass_records):
                _pass = True

            return _pass, msgs


class ValidateCheckerBridge():

    def __init__(self, previous_checker: Checker, current_checker: Checker):

        self.previous_checker = previous_checker
        self.current_checker = current_checker

    def validate_checker(self):

        if self.previous_checker.hard_check:

            return self.previous_checker.is_pass_checker

        else:
            # must be execution
            return True


# Basic Checking
class HeaderChecker(Checker):

    def __init__(self, hard_check=False,
                 fixed_length=None,
                 fixed_columns=None,
                 contain_columns=None):

        super().__init__(hard_check)
        if fixed_length is None and fixed_columns is None and contain_columns is None:
            raise ValueError("Please set either fixed_length or fixed_columns")
        if fixed_length is not None:
            assert isinstance(fixed_length, int)
        if fixed_columns is not None:
            assert "__iter__" in dir(fixed_columns)
        if contain_columns is not None:
            assert "__iter__" in dir(contain_columns)
        self.name = self.__class__.__name__
        self.fixed_length = fixed_length
        self.fixed_columns = fixed_columns
        self.contain_columns = contain_columns

    def _check_is_columns_length(self, data: DataFrame):

        columns_length = {"columns_length": len(data.columns)}
        if columns_length["columns_length"][0] == self.fixed_length:
            return True, columns_length
        else:
            return False, columns_length

    def _check_all_col_names_equality(self, data: DataFrame):

        columns_names = {"columns_equal": data.columns}

        if set(columns_names["columns_equal"]) == set(self.fixed_columns):

            return True, columns_names
        else:
            return False, columns_names

    def _check_contains_columns(self, data: DataFrame):

        intersect = set(data.columns).intersection(set(self.contain_columns))
        matched = {"columns_matched": list(intersect)}

        if len(matched["columns_matched"]) == len(self.contain_columns):

            return True, matched

        else:

            return False, matched

    def check(self, data: DataFrame):
        _pass = False
        cols_len = True
        cols_eq = True
        cols_contain = True
        info_len = {}
        info_eq = {}
        info_contain = {}
        if self.fixed_length is not None:
            cols_len, info_len = self._check_is_columns_length(data)
        if self.fixed_columns is not None:
            cols_eq, info_eq = self._check_all_col_names_equality(data)
        if self.contain_columns is not None:
            cols_contain, info_contain = self._check_contains_columns(data)

        if cols_len and cols_eq and cols_contain:

            _pass = True

        else:

            _pass = False

        self.is_pass_checker = _pass

        return _pass, {**info_len, **info_eq, **info_contain}


class DomainSubrNumChecker(Checker):

    def __init__(self, hard_check=False, target_domains: dict = None):

        super().__init__(hard_check)

        self.name = self.__class__.__name__
        if target_domains is None:
            raise ValueError("Please enter target_domain with dictionary dtype")
        assert isinstance(target_domains, dict)
        self.target_domains = target_domains

    def domain_subr_num(self, data):
        _pass = False
        _pass_count = 0
        subr_num_count = {}
        for domain in self.target_domains.keys():
            # subr_num_count[domain]
            temp_rows = data.filter(f.col("domain") == domain).collect()
            if len(temp_rows) != 1:
                raise Exception(f"subr_num_count should be only one row. Now: {len(temp_rows)}")
            subr_num_count[domain] = temp_rows[0]["count_subr_num"]
            if subr_num_count[domain] >= int(self.target_domains[domain]):
                _pass_count = _pass_count + 1

        if _pass_count == len(self.target_domains.keys()):
            _pass = True

        return _pass, subr_num_count

    def check(self, data: DataFrame):

        _pass = False

        pass_domain_subr_num, info_domain_subr_num = self.domain_subr_num(data)
        _pass = pass_domain_subr_num
        self.is_pass_checker = _pass

        return _pass, {**info_domain_subr_num}


class DomainChecker(Checker):

    def __init__(self, hard_check=False, target_domains: list = None):

        super().__init__(hard_check)

        self.name = self.__class__.__name__
        if target_domains is None:
            raise ValueError("Please enter target_domain with list dtype")
        assert isinstance(target_domains, list)
        self.target_domains = target_domains

    def domains_exists(self, data: DataFrame):

        _pass = False
        filtered_sdf = data.filter(f.col("domain").isin(self.target_domains))
        filtered_sdf = filtered_sdf.dropDuplicates(subset=["domain"])
        rows = filtered_sdf.select("domain").collect()
        matched_columns = []

        for row in rows:
            matched_columns.append(row["domain"])
        counts = len(matched_columns)

        if counts == len(self.target_domains):
            _pass = True

        return _pass, {"matched_domains_count": counts, "matched_domains": matched_columns}

    def check(self, data: DataFrame):

        _pass = False

        pass_domains_exists, info_domains_exists = self.domains_exists(data)
        _pass = pass_domains_exists
        self.is_pass_checker = _pass

        return _pass, {**info_domains_exists}


class Validation:

    def __init__(self, data: DataFrame, checkers_chain: CheckerChain):
        # check class object in data and data_comparison
        type_error_msg = lambda x: "df: {x}. Message: type is not Pyspark DataFrame"
        if not isinstance(data, DataFrame):
            raise TypeError(type_error_msg("data"))
        if isinstance(checkers_chain, Checker):
            checkers_chain = CheckerChain(checkers_chain)
            print("[Info] Change Checker to be CheckerChain Object.")
        else:
            if not isinstance(checkers_chain, CheckerChain):
                raise TypeError("checkerschain must be a CheckerChain Object")

        self.data = data
        self.checkerschain = checkers_chain

    def report(self):
        """ return bool and dictionary pair to indicate the whether the validation passed or not and its information in dict.

        Returns:
            bool, dict: if all validation passed, the first arg is 
        """
        _pass, msgs = self.checkerschain.checkall(self.data)

        return _pass, msgs


if __name__ == "__main__":

    spark = SparkSession.builder.appName("checker").getOrCreate()
    part_key = "date_id"
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str, default='', help='yyyy-mm-dd of the date of data files')
    args = parser.parse_args()

    date_id = args.run_date.replace('-', '')
    # reading Data
    domain_daily = spark.read.parquet(f"{domain_daily}/{part_key}={date_id}")
    index = spark.read.parquet(f"{domain_index_daily}/part_key={date_id}")

    data = domain_daily.groupBy("subr_num", "agg_value").agg(f.sum("byte_count").alias("byte_count")).groupBy(
        "agg_value").agg(f.count("subr_num").alias("count_subr_num"))
    data = data.join(index, on=data.agg_value == index.domain_index, how="left")
    data.cache()
    headerChecker = HeaderChecker(hard_check=True,
                                  contain_columns=['agg_value', 'count_subr_num', 'domain', 'o_domain_index',
                                                   'domain_index'])
    domains = {
        "WWW.GOOGLE.COM": 40000,
        "WWW.FACEBOOK.COM": 40000,
        "APPLE.COM": 40000,
        "OUTLOOK.OFFICE365.COM": 40000,
        "APP.KMB.HK": 40000,
        "API.OPENRICE.COM": 40000,
        "WWW.YOUTUBE.COM": 40000,
        "DIT.WHATSAPP.NET": 40000,
        "PDA.WEATHER.GOV.HK": 40000,
        "SCONTENT.CDNINSTAGRAM.COM": 40000
    }
    domainChecker = DomainChecker(hard_check=True, target_domains=["WWW.GOOGLE.COM", "WWW.FACEBOOK.COM", "APPLE.COM",
                                                                   "OUTLOOK.OFFICE365.COM", "APP.KMB.HK",
                                                                   "API.OPENRICE.COM",
                                                                   "WWW.YOUTUBE.COM", "DIT.WHATSAPP.NET",
                                                                   "PDA.WEATHER.GOV.HK",
                                                                   "SCONTENT.CDNINSTAGRAM.COM"])
    domainSubrNumChecker = DomainSubrNumChecker(hard_check=True, target_domains=domains)
    is_pass, info = Validation(data, checkers_chain=CheckerChain(
        headerChecker,
        domainChecker,
        domainSubrNumChecker
    )).report()

    if is_pass:
        for i in info.keys():
            print(f"{i} :", info[i])

        logger.info("ALL Checkers Passed")

    else:
        for i in info.keys():
            print(f"{i} :", info[i])

        raise Exception("Checking did not pass!")
