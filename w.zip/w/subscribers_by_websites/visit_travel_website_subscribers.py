import logging
from pyspark.sql import SparkSession
from datetime import datetime, timedelta
from enum import Enum
from pyspark.sql.functions import col, sum as _sum, countDistinct, when
from weblog_util.save_airtable import DomainList
from weblog_util.paths import n1table, subscribers_output


class PastNDays(Enum):
    PAST_14D = 14
    PAST_180D = 180


def travel_intent(spark: SparkSession, run_date: datetime, tag: str, weblog):
    run_date_str = run_date.strftime('%Y%m%d')
    n1 = spark.read.parquet(n1table).select('SUBR_NUM', 'CUST_NUM')

    logging.info('-----Agg travel_intent cols------')

    result = weblog.filter(col('TAG')==DomainList[tag].value)\
        .groupBy('SUBR_NUM')\
        .pivot('CATEGORY').agg(
            _sum(
                when(
                    (col('date_id').between((run_date - timedelta(days=PastNDays.PAST_14D.value-1)).strftime('%Y%m%d'), run_date_str)),
                    col('byte_count')
                )
            ).alias(f'DATA_USAGE_SUM_{PastNDays.PAST_14D.name}'),
            _sum(
                when(
                    (col('date_id').between((run_date - timedelta(days=PastNDays.PAST_180D.value-1)).strftime('%Y%m%d'), run_date_str)),
                    col('byte_count')
                )
            ).alias(f'DATA_USAGE_SUM_{PastNDays.PAST_180D.name}'),
            countDistinct(
                when(
                    (col('date_id').between((run_date - timedelta(days=PastNDays.PAST_14D.value-1)).strftime('%Y%m%d'), run_date_str)),
                    col('date_id')
                )
            ).alias(f'DAY_CNT_{PastNDays.PAST_14D.name}'),
            countDistinct(
                when(
                    (col('date_id').between((run_date - timedelta(days=PastNDays.PAST_180D.value-1)).strftime('%Y%m%d'), run_date_str)),
                    col('date_id')
                )
            ).alias(f'DAY_CNT_{PastNDays.PAST_180D.name}'),
            countDistinct(
                when(
                    (col('date_id').between((run_date - timedelta(days=PastNDays.PAST_14D.value-1)).strftime('%Y%m%d'), run_date_str)),
                    col('domain')
                )
            ).alias(f'DOMAIN_CNT_{PastNDays.PAST_14D.name}'),
            countDistinct(
                when(
                    (col('date_id').between((run_date - timedelta(days=PastNDays.PAST_180D.value-1)).strftime('%Y%m%d'), run_date_str)),
                    col('domain')
                )
            ).alias(f'DOMAIN_CNT_{PastNDays.PAST_180D.name}'),
        )

    logging.info('-----Join n1------')

    result = result.join(n1, 'SUBR_NUM', 'inner').select('SUBR_NUM', 'CUST_NUM', *sorted(result.columns[1:]))

    result.coalesce(10).write.mode('overwrite').parquet(f'{subscribers_output}/{tag}/date_id={run_date_str}')