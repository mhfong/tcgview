import logging
from pyspark.sql import SparkSession
from datetime import datetime, timedelta
from enum import Enum
from pyspark.sql.functions import col, countDistinct, when
from weblog_util.save_airtable import DomainList
from weblog_util.paths import n1table, subscribers_output


class PastNDays(Enum):
    PAST_30D = 30


def house_mover(spark: SparkSession, run_date: datetime, tag: str, weblog):
    run_date_str = run_date.strftime('%Y%m%d')
    n1 = spark.read.parquet(n1table).select('SUBR_NUM', 'CUST_NUM')

    logging.info('-----Agg house mover cols------')

    cat = weblog.filter(col('TAG')==DomainList[tag].value)\
            .groupBy('SUBR_NUM')\
            .pivot('CATEGORY').agg(
                countDistinct(
                    when(
                        (col('date_id').between((run_date - timedelta(days=PastNDays.PAST_30D.value-1)).strftime('%Y%m%d'), run_date_str)),
                        col('date_id')
                    )
                )
            )

    result = cat.select(
        col('SUBR_NUM'),
        *[col(c).alias(f'{c.upper()}_DAY_CNT_{PastNDays.PAST_30D.name}') for c in cat.columns if c != 'SUBR_NUM']
    )
    
    result = result.join(n1, 'SUBR_NUM', 'inner').select('SUBR_NUM', 'CUST_NUM', *sorted(result.columns[1:]))

    result.coalesce(10).write.mode('overwrite').parquet(f'{subscribers_output}/{tag}/date_id={run_date_str}')