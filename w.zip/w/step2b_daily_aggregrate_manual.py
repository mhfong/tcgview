#############################################
#### Daily Aggregrage
# 1 dictionary is done
# 2 aggreage both domain, tag and tag_gp
#############################################

import argparse
import logging
import sys

import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from weblog_util.paths import ssl_parquet, domain_daily, domain_index_daily


logger = logging.getLogger(__name__)
log_format = "[%(asctime)s][%(funcName)25s:%(lineno)4d] %(message)s"
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=log_format)


def main(run_date: str):
    # define sc for checking to closing spark
    spark = SparkSession.builder.appName("weblog-daily").getOrCreate()

    # ssl_data_dir = '/app/sna_bdmrdev01/ws-ic/hive/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ/'
    # t_domain_base_dir = '/app/sna_bdmrdev01/ws-ic/hive/weblog.db/'
    # num_of_dates_to_load = 4

    ## ---------------------------- Path Settings ------------------------------ ##
    # t_domain_daily_dir = t_domain_base_dir + '/t_domain_daily/'
    # t_domain_index_dir = t_domain_base_dir + '/t_domain_index/'

    ## ---------------------------- Get Sdfs ------------------------------ ##
    # ssl weblog
    # check the parquet folder exists

    partition_key = "part_key"
    full_ssl_path = f"{ssl_parquet}/{partition_key}={str(run_date.replace('-', ''))}"
    full_domain_index_path = f"{domain_index_daily}/{partition_key}={str(run_date.replace('-', ''))}"
    
    sdf_ssl = spark.read.parquet(full_ssl_path)

    # t doamin daily
    # sdf_tdd = spark.read.parquet(t_domain_daily_dir)
    # t doamin index
    sdf_tdi = spark.read.parquet(full_domain_index_path)

    ## ------------------------ Get Dates to Load ------------------------ ##
    # temp table for getting list of dates to laod
    # df_loaded = sdf_tdd.select('date_id').distinct().toPandas()
    # df_legal = sdf_ssl.select('date_id').distinct().filter(F.col('date_id') >= 20200101).toPandas()

    # get list of dates to load
    # dates_to_loaded = \
    # df_legal[~df_legal['date_id'].isin(df_loaded['date_id'])].sort_values(by='date_id', ascending=False)[
    #     'date_id'].tolist()[:num_of_dates_to_load]
    # logging.info(f'Dates to loaded: {dates_to_loaded}')

    ## --------------------- Aggregate Summary ----------------------  ##
    # df_tdd_count = pd.DataFrame([x.split('=')[1][:6] for x in os.listdir(t_domain_daily_dir) if '=' in x],
    #                             columns=['month_id'])
    # logging.info(df_tdd_count['month_id'].value_counts().sort_index())

    ## ------------------------ Aggregate Domain ---------------------- ##
    # for date_id in dates_to_loaded:  # 20 mins
    sdf_tdd_new = sdf_ssl.join(
        sdf_tdi, sdf_ssl.ssl_cert_domain == sdf_tdi.domain, how='left'
    ).select(
        'subr_num',
        F.col('domain_index').alias('agg_value'),
        F.lit('domain').alias('agg_level'),
        F.lit(0).alias('in_byte'),
        F.lit(0).alias('out_byte'),
        'byte_count',
        'total_hit',
        F.lit(0).alias('duration')
    )

    # write
    part_key = run_date.replace('-', '')
    sdf_tdd_new.coalesce(10).write.mode('overwrite').parquet(f'{domain_daily}/date_id={part_key}')


if __name__ == '__main__':

    # parser
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str,
                        default='',
                        help='')
    args = parser.parse_args()
    main(args.run_date)
