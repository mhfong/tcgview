import argparse
import os
from datetime import datetime as dt
from datetime import timedelta

import cx_Oracle
import pandas as pd
import pyspark.sql.functions as f
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.types import LongType, StringType, StructField, StructType

from weblog_util import paths
#sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), "../.."))
from weblog_util.common import getAggValue, getDomainSummary

# ## Data Source
# #### Data Usage Agg
# 1. res_house_moving 
# 2. res_hkbn
# 3. res_netvigator
# 4. res_village_property_agent
# #### Call Record 
# 1. sdf_hkbn
# 2. sdf_netvigator
# #### 5GBB CHRUN List
# 1. sdf_FBB

# ## Aggragation
# #### Union all Web Access
# 1. res_merged=res_house_moving.union(res_house_renovating).union(res_hkbn).union(res_netvigator).cache()
# 2. res_pivot=res_merged.groupBy('date_id','SUBR_NUM').pivot('APPS').agg(f.sum('TOTAL_BYTE_COUNT').alias('TOTAL_BYTE_COUNT'),f.countDistinct('date_id').alias('TOTAL_DAYS')).na.fill(0).withColumnRenamed('date_id','DATE_ID')         

# #### Union and pivot hotline call
# 1. res_2n_call_Log=sdf_2n_call_log.groupby('DATE_ID','SUBR_NUM').pivot('network_operator').agg(f.sum('CALL_DUR').alias('CALL_DUR')).na.fill(0)

# #### Outer Join Agg Web SDF and Agg Hotline SDF, left join live active sim
# 1. res=res_2n_call_Log.join(res_pivot,['DATE_ID','SUBR_NUM'],'outer').na.fill(0).join(sdf_postpaid_mas_n1,['SUBR_NUM'],'left').where('CUST_NUM is not null')

# #### Join the sdf result with Chrun List
# 1. sdf_FBB

def oracle_dsn():
    return """(DESCRIPTION = 
                (ADDRESS = 
                    (PROTOCOL = TCP)
                    (HOST = uds2vm01clu01-vip)
                    (PORT = 25502))
                (ADDRESS = 
                    (PROTOCOL = TCP)
                    (HOST = uds2vm02clu01-vip)
                    (PORT = 25502))
                (ADDRESS = 
                    (PROTOCOL = TCP)
                    (HOST = uds2vm03clu01-vip)
                    (PORT = 25502))
                (ADDRESS = 
                    (PROTOCOL = TCP)
                    (HOST = uds2vm04clu01-vip)
                    (PORT = 25502))
                (CONNECT_DATA = 
                (SERVER = DEDICATED) 
                (SERVICE_NAME = UDSDW_DS)))"""


def oracle_conn(username: str, password: str, dsn: str = oracle_dsn()):
    try:
        conn = cx_Oracle.connect(
            user=username,
            password=password,
            dsn=dsn,
            encoding="utf-8",
            nencoding="utf-8",
        )

        print("Connect to Oracle Successfully")
        return conn
    except Exception as e:
        print(f"dsn string: {dsn}")
        print("error, fail to connect to oracle: {}".format(str(e)))
        raise e


# function to get dates
def get_date_vars(file_export_date, bw_date_st=3, duration=2, bw_date_st_village=8):

    fed = dt.strptime(file_export_date, '%Y%m%d')

    # get 3 days if Monday
    if fed.weekday() == 0:
        bw_date_st = 4
        duration = 3

    d_call_start=dt.strftime(fed-timedelta(days=bw_date_st), '%Y-%m-%d')
    d_call_end=dt.strftime(fed-timedelta(days=bw_date_st-duration+1), '%Y-%m-%d')
    val_agg_period_start=int(d_call_start.replace('-', ''))
    val_agg_period_end=int(d_call_end.replace('-', ''))

    val_agg_period_start_village=int(dt.strftime(fed-timedelta(days=bw_date_st_village), '%Y%m%d'))

    return d_call_start, d_call_end, val_agg_period_start, val_agg_period_end, val_agg_period_start_village


def main(file_export_date: str=''):
    ## ---------------------- 0. Parameters ------------------- ##
    if not file_export_date:
        file_export_date=dt.strftime(dt.now(), '%Y%m%d')
    
    # get oracle connection in HPE
    # original output_path = f'/app/sna_bdmrdev02/data_out/to_Cognos_De_SMS/De_5G_BB_{file_export_date}.csv'
    output_path = paths.housemoving_output.format(file_export_date=file_export_date)
    fpath_t_domain_index = paths.domain_index_latest
    fpath_t_domain_table = os.path.dirname(paths.domain_index_daily)
    
    # init oracle connection here
    username = os.getenv("ORACLE_USER", "")
    password = os.getenv("ORACLE_PASS", "")
    
    #print(f"oracle_user: {username}, oracle_pass: {password}")
    conn = oracle_conn(username=username, password=password)
    
    # get spark session
    spark = SparkSession \
            .builder \
            .appName("housemoving") \
            .getOrCreate()

    # get date vars
    d_call_start, d_call_end, val_agg_period_start, val_agg_period_end, val_agg_period_start_village=get_date_vars(file_export_date)

    print('[Info] d_call_start, d_call_end, val_agg_period_start, val_agg_period_end, val_agg_period_start_village:')
    print(d_call_start, d_call_end, val_agg_period_start, val_agg_period_end, val_agg_period_start_village)
    print(f'[Info] output_path: {output_path}')

    ## ---------------------- 1. Postpaid Master N1 ------------------- ##
    df_postpaid_mas_n1 = pd.read_sql_query("""
    select
                    VW_PREPD_POSTPAID_SUBR_N1.CUST_NUM,
                    VW_PREPD_POSTPAID_SUBR_N1.SUBR_NUM,
                    VW_PREPD_POSTPAID_SUBR_N1.D_HKID_N

    from PRD_BIZ_SUMM_VW.VW_PREPD_POSTPAID_SUBR_N1
    left join PRD_BIZ_SUMM_VW.VW_RATE_PLAN_REF
    on VW_PREPD_POSTPAID_SUBR_N1.Rate_Plan_Cd = VW_RATE_PLAN_REF.Rate_Plan_Cd

    left join PRD_BIZ_SUMM_VW.VW_PREPD_DEMO_CARD
    on VW_PREPD_POSTPAID_SUBR_N1.Subr_Num = VW_PREPD_DEMO_CARD.Msisdn

    left join PRD_BIZ_SUMM_VW.VW_SUBR_NOMINATION_HIST 
    on VW_PREPD_POSTPAID_SUBR_N1.Cust_Num = VW_SUBR_NOMINATION_HIST.CUST_NUM
    and VW_PREPD_POSTPAID_SUBR_N1.subr_num = VW_SUBR_NOMINATION_HIST.subr_num

    left join PRD_BIZ_SUMM_VW.VW_SUBR_DATA_ENTITLE
    on VW_PREPD_POSTPAID_SUBR_N1.Cust_Num = VW_SUBR_DATA_ENTITLE.CUST_NUM
    and  VW_PREPD_POSTPAID_SUBR_N1.subr_num = VW_SUBR_DATA_ENTITLE.subr_num

    left join PRD_BIZ_SUMM_VW.VW_SHK_RATE_PLAN_GRP_REF
    on VW_SUBR_DATA_ENTITLE.FREE_DATA_ENTITLE = VW_SHK_RATE_PLAN_GRP_REF.FREE_DATA_ENTITLE

    WHERE VW_PREPD_POSTPAID_SUBR_N1.D_Active_Subr_Flg = 'Y'
                    AND VW_PREPD_POSTPAID_SUBR_N1.Prepost_Type = 'PO'
                    AND CASE 
                                    WHEN (
                                                                    VW_PREPD_POSTPAID_SUBR_N1.Prepost_Type <> 'PO'
                                                                    AND VW_PREPD_DEMO_CARD.Msisdn <> ' '
                                                                    )
                                                    THEN 'N'
                                    WHEN (
                                                                    (coalesce(VW_RATE_PLAN_REF.Rate_Plan_Grp, ' ')) IN (
                                                                                    'Add-on Numbers'
                                                                                    ,'Non Revenue Mobile Plan'
                                                                                    ,'Non Revenue BB Line'
                                                                                    ,'DHL Special Project'
                                                                                    )
                                                                    )
                                                    THEN 'N'
                                    WHEN (
                                                                    (coalesce(VW_PREPD_POSTPAID_SUBR_N1.Cust_Type_Cd, ' ')) IN (
                                                                                    'SMC'
                                                                                    ,'LPUC1'
                                                                                    ,'HKBU1'
                                                                                    ,'RWSU1'
                                                                                    ,'HKBU2'
                                                                                    ,'GCU1'
                                                                                    )
                                                                    )
                                                    THEN 'N'
                                    ELSE 'Y'
                                    END = 'Y'
                    AND VW_PREPD_POSTPAID_SUBR_N1.NC_FLG = 'N'
                    AND VW_SHK_RATE_PLAN_GRP_REF.SHK_PLAN_SUBGRP NOT IN (
                                    'Excluded'
                                    ,'MVNOs (Local)'
                                    ,'MVNOs (Roaming)'
                                    )
                    AND VW_SUBR_NOMINATION_HIST.NOMINATION_FLG = 'N'
    """,con=conn)

    sdf_postpaid_mas_n1=spark.createDataFrame(df_postpaid_mas_n1)
    print(sdf_postpaid_mas_n1.limit(2).toPandas())

    # 5g bb hkid table
    df_hkid_5gbb=pd.read_sql("""
    select distinct
        D_HKID_N
        , 'Y' as Cur_5GBB_by_HKID
    from PRD_biz_summ_vw.vw_prepd_postpaid_subr_n1
    where SUBR_NUM like '19943%'
    OR SUBR_NUM like '19944%'
    AND SUBR_STAT_CD = 'OK'
    """, con=conn)
    sdf_hkid_5gbb=spark.createDataFrame(df_hkid_5gbb)
    print(sdf_hkid_5gbb.limit(2).toPandas())

    # 5g bb table
    df_5gbb = pd.read_sql("""
    SELECT   A.CUST_NUM, A.SUBR_NUM as BB_subr_num, B.SUBR_NUM as mobile_subr_num, 'Y' as Currently_5GBB_user
    FROM
    (
    SELECT * FROM PRD_biz_summ_vw.vw_prepd_postpaid_subr_n1  WHERE SUBR_NUM LIKE '19943%' OR SUBR_NUM LIKE '19944%' AND SUBR_STAT_CD='OK'  
    ) a
    LEFT OUTER JOIN
    (
    SELECT * FROM PRD_biz_summ_vw.vw_prepd_postpaid_subr_n1  WHERE SUBR_NUM not  LIKE '19943%' OR SUBR_NUM not LIKE '19944%' AND SUBR_STAT_CD='OK'  
    ) b
    on a.cust_num = b.cust_num
    AND A.SUBR_NUM <> B.SUBR_NUM
    where length(B.SUBR_NUM) = 8
    """, con=conn)
    sdf_5gbb=spark.createDataFrame(df_5gbb)
    print(sdf_5gbb.limit(2).toPandas())

    ## ---------------------- 2. Get Domain Aggregated Data ------------------- ##

    # -------- 2.1 House Moving -------- #
    house_moving_list=[
    'WWW.MEKOTRANSPORT.COM',
    'WWW.PPSMOVING.COM.HK',
    'WWW.CANAAN.HK',
    'WWW.CHUNGPONG.COM.HK',
    'WWW.PRUDENTIALMOVERS.COM',
    'YANYAN.HK',
    'WWW.HOITONG.COM',
    'WWW.RINGOMOVINGCOMPANY.COM',
    'YANYAN.HK',
    'WWW.JUMBOMOVERS.COM.HK',
    'WWW.EAMOVERS.COM.HK',
    'WWW.A-ONE.HK',
    'TUNGWAHMOVE.COM',
    'WWW.PPSMOVING.COM.HK',
    'WWW.27048498.COM',
    'WWW.MOVINGCOMBINE.COM',
    'PIANOMOVINGKING.COM',
    'WWW.PIANOMOVINGKING.COM',
    'WWW.GOINGMOVINGHK.COM',
    'WWW.JPSTYLEMOVING.COM',
    'WWW.MOVE-MOVING.COM',
    'WWW.KWONGLEEMOVING.HK',
    'WWW.TOPWAYMOVING.COM',
    'WWW.PRICERIGHT.COM.HK',
    'PRICERIGHT.COM.HK',
    'WWW.28506666.COM.HK'
    ]

    res_house_moving=getDomainSummary(spark,
                                      agg_value_table=getAggValue(spark, house_moving_list, fpath_t_domain_index),
                                      agg_freq='daily',
                                      agg_period_start=val_agg_period_start,
                                      agg_period_end=val_agg_period_end,
                                      app_name='HOUSE_MOVING',
                                      fpath_t_domain_table=fpath_t_domain_table,
                                      filter_table=sdf_postpaid_mas_n1,)

    # -------- 2.2 HKBN -------- #
    hkbn_list = ['HKBN.NET']

    res_hkbn=getDomainSummary(spark, agg_value_table=getAggValue(spark, hkbn_list, fpath_t_domain_index),
                                      agg_freq='daily',
                                      agg_period_start=val_agg_period_start,
                                      agg_period_end=val_agg_period_end,
                                      app_name='HKBN',
                                      fpath_t_domain_table=fpath_t_domain_table,
                                      filter_table=sdf_postpaid_mas_n1)

    # -------- 2.3 Navigator -------- #
    netvigator_list=['NETVIGATOR.COM']

    res_netvigator=getDomainSummary(spark, agg_value_table=getAggValue(spark, netvigator_list, fpath_t_domain_index),
                                      agg_freq='daily',
                                      agg_period_start=val_agg_period_start,
                                      agg_period_end=val_agg_period_end,
                                      app_name='NETVIGATOR',
                                      fpath_t_domain_table=fpath_t_domain_table,
                                      filter_table=sdf_postpaid_mas_n1)

    # -------- 2.4 Village Property Agent -------- #
    village_property_agent_list=[
    'http://www.kahing.com.hk/',
    'https://cnp.hk/',
    'http://pinnacleproperty.com.hk/',
    'http://www.easyhouse.hk/',
    'https://www.home-expert.hk/',
    'https://www.imperialprop.com.hk/'
    ]

    res_village_property_agent=getDomainSummary(spark, agg_value_table=getAggValue(spark, village_property_agent_list, fpath_t_domain_index),
                                      agg_freq='daily',
                                      agg_period_start=val_agg_period_start_village,
                                      agg_period_end=val_agg_period_end,
                                      app_name='VILLAGE',
                                      fpath_t_domain_table=fpath_t_domain_table,
                                      filter_table=sdf_postpaid_mas_n1)

    # -------- 2.5 House Renovating Companies & Platform and Inspection Companines -------- #

    #### Home Renovating Companies
    house_renovating_list=[
    'https://www.gahomeservice.com/21321asdsa',
    'https://sanmarinodesign.com/dasd',
    'https://www.carol-construction.com/1232',
    'https://www.fungstyle.com/asd',
    'https://mystylehouse.com.hk/zxc',
    'https://www.eleganthouse.net/asdas',
    #### Home Renovating Matching Platforms
    'https://codeco.hk'
    'https://echouse.com.hk/',
    'https://www.spaceplan.com.hk/',
    'https://renovate.qanvast.com/',
    'https://hkdecoman.com/',
    'http://easyfull.hk',
    'http://www.renobro.com.hk/',
    #### House Inspection Website
    'https://www.hksurveyors.com/',
    'https://www.silverconeng.com.hk/',
    'https://hk-ppi.com/',
    'https://www.legendflyhk.com/'
    ]

    res_house_renovating=getDomainSummary(spark, agg_value_table=getAggValue(spark, house_renovating_list, fpath_t_domain_index),
                                      agg_freq='daily',
                                      agg_period_start=val_agg_period_start,
                                      agg_period_end=val_agg_period_end,
                                      app_name='HOUSE_RENOVATING_COMPANYS',
                                      fpath_t_domain_table=fpath_t_domain_table,
                                      filter_table=sdf_postpaid_mas_n1)

    # -------- 2.6 HKBN & NETVIGATOR Hotline -------- #
    # Get Sunday
    def allsundays(year):
        return pd.date_range(start=str(year), end=str(year+1), 
                             freq='W-SUN').strftime('%Y-%m-%d').tolist()
    sundays_list=allsundays(int(d_call_start[:4]))

    netvigator_hotline='28880089'
    hkbn_hotline='34902020'
    # hkbn_hotline=['34913888']

    df_hkbn=pd.read_sql(f"""
    with t2 as (Select A_NUM, CUST_NUM, SUBR_NUM, CALL_DUR, CALL_START_DATE, case when CALL_START_DATE between trunc(CALL_START_DATE + 1,'iw')-1 and trunc(CALL_START_DATE + 1,'iw')+5 then trunc(CALL_START_DATE + 1,'iw')-1 end as date_id
    from prd_biz_summ_vw.vw_end_user_msc_call_dtl where call_start_date between DATE '{d_call_start}' and DATE '{d_call_end}' and A_NUM = '{hkbn_hotline}')
    Select CUST_NUM,SUBR_NUM, date_id, sum(CALL_DUR) as CALL_DUR from t2 group by CUST_NUM, SUBR_NUM,date_id
    """,con=conn)

    df_netvigator=pd.read_sql(f"""
    with t2 as (Select A_NUM, CUST_NUM, SUBR_NUM, CALL_DUR, CALL_START_DATE, case when CALL_START_DATE between trunc(CALL_START_DATE + 1,'iw')-1 and trunc(CALL_START_DATE + 1,'iw')+5 then trunc(CALL_START_DATE + 1,'iw')-1 end as date_id
    from prd_biz_summ_vw.vw_end_user_msc_call_dtl where call_start_date between DATE '{d_call_start}' and DATE '{d_call_end}' and A_NUM = '{netvigator_hotline}')
    Select CUST_NUM,SUBR_NUM, date_id, sum(CALL_DUR) as CALL_DUR from t2 group by CUST_NUM, SUBR_NUM, date_id
    """,con=conn)

    # get date str
    try:
        df_hkbn['DATE_ID']=df_hkbn['DATE_ID'].apply(lambda x: x.strftime('%Y%m%d'))
    except AttributeError:
        pass
    try:
        df_netvigator['DATE_ID']=df_netvigator['DATE_ID'].apply(lambda x: x.strftime('%Y%m%d'))
    except AttributeError:
        pass

    ## to sdfs
    # schema
    schema_hkbn_netvigator = StructType([
        StructField("CUST_NUM", StringType(), True),
        StructField("SUBR_NUM", StringType(), True),
        StructField("DATE_ID", StringType(), True),
        StructField("CALL_DUR", LongType(), True)])

    # to sdfs
    sdf_hkbn=spark.createDataFrame(df_hkbn, schema=schema_hkbn_netvigator)
    sdf_netvigator=spark.createDataFrame(df_netvigator, schema=schema_hkbn_netvigator)

    # add network_operator
    sdf_hkbn=sdf_hkbn.withColumn('network_operator',lit('HKBN'))
    sdf_netvigator=sdf_netvigator.withColumn('network_operator',lit('NETVIGATOR'))

    # -------- 2.6 FBB Churn List -------- #
    df_fbb = pd.read_sql_query("""
    SELECT
        DISTINCT
        VW_PREPD_POSTPAID_CUST.Cust_Num AS CUST_NUM
        ,VW_PREPD_POSTPAID_SUBR_N1.Subr_Num AS SUBR_NUM
        ,VW_HKID_BR.Hkid_Br AS Hkid_Br
        ,VW_PREPD_POSTPAID_SUBR_N1.Subr_Sw_On_Date AS Subscriber_Switch_On_Date
        ,VW_PREPD_POSTPAID_SUBR_N1.ACCS_MAX_SU_EFFECT_DATE AS Subscriber_Switch_Off_Date
    FROM (
        SELECT CUST_NUM AS Cust_Num
            ,SUBR_NUM AS Subr_Num
            ,SUBR_STAT_CD AS Subr_Stat_Cd
            ,SUBR_SW_ON_DATE AS Subr_Sw_On_Date
            ,D_ACTIVE_SUBR_FLG AS D_Active_Subr_Flg
            ,RATE_PLAN_CD AS Rate_Plan_Cd
            ,ACCS_MAX_SU_EFFECT_DATE AS Accs_Max_SU_Effect_Date
        FROM PRD_BIZ_SUMM_VW.VW_PREPD_POSTPAID_SUBR_N1
        ) VW_PREPD_POSTPAID_SUBR_N1
    LEFT OUTER JOIN (

        SELECT
            RATE_PLAN_CD AS Rate_Plan_Cd
        FROM PRD_BIZ_SUMM_VW.VW_PREPD_POSTPD_RATE_PLAN_REF
        ) VW_PREPD_POSTPD_RATE_PLAN_REF ON (VW_PREPD_POSTPAID_SUBR_N1.Rate_Plan_Cd = VW_PREPD_POSTPD_RATE_PLAN_REF.Rate_Plan_Cd)
    LEFT OUTER JOIN (
        SELECT STAT_CD AS Stat_Cd
        FROM PRD_BIZ_SUMM_VW.VW_PREPD_POSTPAID_STAT_REF
        ) VW_PREPD_POSTPAID_STAT_REF ON (VW_PREPD_POSTPAID_SUBR_N1.Subr_Stat_Cd = VW_PREPD_POSTPAID_STAT_REF.Stat_Cd)
    LEFT OUTER JOIN (
        SELECT CUST_NUM AS Cust_Num
        FROM PRD_BIZ_SUMM_VW.VW_PREPD_POSTPAID_CUST
        ) VW_PREPD_POSTPAID_CUST ON (VW_PREPD_POSTPAID_CUST.Cust_Num = VW_PREPD_POSTPAID_SUBR_N1.Cust_Num)
    LEFT OUTER JOIN (
        SELECT CUST_NUM AS Cust_Num
            ,HKID_BR AS Hkid_Br
        FROM PRD_BIZ_SUMM_VW.VW_CUST_MISC_INFO
        ) VW_CUST_MISC_INFO ON (VW_PREPD_POSTPAID_CUST.Cust_Num = VW_CUST_MISC_INFO.Cust_Num)
    LEFT OUTER JOIN (
        SELECT HKID_BR_PREFIX AS Hkid_Br_Prefix
            ,HKID_BR AS Hkid_Br
        FROM PRD_BIZ_SUMM_VW.VW_HKID_BR
        ) VW_HKID_BR ON (VW_CUST_MISC_INFO.Hkid_Br = VW_HKID_BR.Hkid_Br)
    LEFT OUTER JOIN (
        SELECT HKID_BR_PREFIX AS Hkid_Br_Prefix
        FROM PRD_BIZ_SUMM_VW.VW_HKID_BR_PREFIX
        ) VW_HKID_BR_PREFIX ON (VW_HKID_BR.Hkid_Br_Prefix = VW_HKID_BR_PREFIX.Hkid_Br_Prefix)
    LEFT OUTER JOIN (
        SELECT HKID_BR_PREFIX AS Hkid_Br_Prefix
            ,D_HKID_ACTIVE_FL_CNT AS D_Hkid_Active_FL_Cnt
            ,D_HKID_ACTIVE_MOBILE_CNT_S
        FROM PRD_BIZ_SUMM_VW.VW_HKID_MISC_INFO
        ) VW_HKID_MISC_INFO ON (VW_HKID_BR_PREFIX.Hkid_Br_Prefix = VW_HKID_MISC_INFO.Hkid_Br_Prefix)
    LEFT OUTER JOIN (
        SELECT CONSENT_FLG AS Consent_Flg
            ,CUST_NUM AS Cust_Num
        FROM PRD_BIZ_SUMM_VW.VW_DM_CONSENT_INFO_HKID
        ) VW_DM_CONSENT_INFO_HKID ON (VW_PREPD_POSTPAID_CUST.Cust_Num = VW_DM_CONSENT_INFO_HKID.Cust_Num)
    LEFT OUTER JOIN (
        SELECT SUBR_NUM AS Subr_Num
            ,CUST_NUM AS Cust_Num
            ,TELESALES AS Telesales
        FROM PRD_BIZ_SUMM_VW.VW_ALL_PROFILING_NEW
        ) VW_ALL_PROFILING_NEW ON (
            (VW_ALL_PROFILING_NEW.Cust_Num = VW_PREPD_POSTPAID_SUBR_N1.Cust_Num)
            AND (VW_ALL_PROFILING_NEW.Subr_Num = VW_PREPD_POSTPAID_SUBR_N1.Subr_Num)
            )
    LEFT OUTER JOIN (
        SELECT SUBR_NUM AS Subr_Num
            ,CUST_NUM AS Cust_Num
            ,REJECT_ALL_COMM_FLG AS Reject_All_Comm_Flg
        FROM PRD_BIZ_SUMM_VW.VW_ALL_PROFILING_N2
        ) VW_ALL_PROFILING_N2 ON (
            (VW_ALL_PROFILING_N2.Cust_Num = VW_PREPD_POSTPAID_SUBR_N1.Cust_Num)
            AND (VW_ALL_PROFILING_N2.Subr_Num = VW_PREPD_POSTPAID_SUBR_N1.Subr_Num)
            )
    LEFT OUTER JOIN (
        SELECT CONSENT_FLG AS Consent_Flg
            ,CUST_NUM AS Cust_Num
            ,SUBR_NUM AS Subr_Num
        FROM PRD_BIZ_SUMM_VW.VW_DM_CONSENT_INFO_SUBR_NUM
        ) VW_DM_CONSENT_INFO_SUBR_NUM ON (
            (VW_DM_CONSENT_INFO_SUBR_NUM.Cust_Num = VW_PREPD_POSTPAID_SUBR_N1.Cust_Num)
            AND (VW_DM_CONSENT_INFO_SUBR_NUM.Subr_Num = VW_PREPD_POSTPAID_SUBR_N1.Subr_Num)
            )
    LEFT OUTER JOIN (
        SELECT CUST_NUM AS Cust_Num
            ,SUBR_NUM AS Subr_Num
            ,LM_LD_CD AS Lm_Ld_Cd
            ,LM_LD_EXPIRED_DATE AS Lm_Ld_Expired_Date
            ,LM2_LD_CD AS Lm2_Ld_Cd
            ,LM2_LD_EXPIRED_DATE AS Lm2_Ld_Expired_Date
        FROM PRD_BIZ_SUMM_VW.VW_LATEST_SUBR_LD_PART1
        ) VW_LATEST_SUBR_LD_PART1 ON (
            (VW_LATEST_SUBR_LD_PART1.Cust_Num = VW_PREPD_POSTPAID_SUBR_N1.Cust_Num)
            AND (VW_LATEST_SUBR_LD_PART1.Subr_Num = VW_PREPD_POSTPAID_SUBR_N1.Subr_Num)
            )
    LEFT OUTER JOIN (
        SELECT SUBR_NUM AS Subr_Num
            ,CUST_NUM AS Cust_Num
            ,ESTATE_TYPE AS Estate_Type
        FROM PRD_BIZ_SUMM_VW.VW_FBB_INSTALL_INFO
        ) VW_FBB_INSTALL_INFO ON (
            (VW_FBB_INSTALL_INFO.Cust_Num = VW_PREPD_POSTPAID_SUBR_N1.Cust_Num)
            AND (VW_FBB_INSTALL_INFO.Subr_Num = VW_PREPD_POSTPAID_SUBR_N1.Subr_Num)
            )
    WHERE (
            (
                (VW_PREPD_POSTPAID_SUBR_N1.Subr_Num LIKE '15%')
                OR (VW_PREPD_POSTPAID_SUBR_N1.Subr_Num LIKE '18%')
                )
            OR (VW_PREPD_POSTPAID_SUBR_N1.Subr_Num LIKE '16%')
            )
        AND (VW_PREPD_POSTPAID_SUBR_N1.Subr_Sw_On_Date < VW_PREPD_POSTPAID_SUBR_N1.Accs_Max_SU_Effect_Date)
        AND (NOT (VW_PREPD_POSTPD_RATE_PLAN_REF.Rate_Plan_Cd IN ('FB00F')))
        and VW_HKID_BR.Hkid_Br is not null
        and VW_HKID_BR.Hkid_Br <> ' '
    """,con=conn)
    df_fbb['SUBSCRIBER_SWITCH_ON_DATE'] = df_fbb['SUBSCRIBER_SWITCH_ON_DATE'].apply(lambda x: x.strftime('%Y-%m-%d')).astype(str)
    df_fbb['SUBSCRIBER_SWITCH_OFF_DATE'] = df_fbb['SUBSCRIBER_SWITCH_OFF_DATE'].apply(lambda x: x.strftime('%Y-%m-%d')).astype(str)
    sdf_FBB=spark.createDataFrame(df_fbb)
    # Find FBB Churned Customer for 18 Months and 30 Months
    sdf_FBB=sdf_FBB.where("SUBSCRIBER_SWITCH_OFF_DATE between DATE '2020-02-01' and DATE '2022-08-01' ")

    # -------- 2.7 User Language -------- #
    df_lang=pd.read_sql_query("""
    with t as (
    select
                    VW_PREPD_POSTPAID_SUBR_N1.CUST_NUM,
                    VW_PREPD_POSTPAID_SUBR_N1.SUBR_NUM

    from PRD_BIZ_SUMM_VW.VW_PREPD_POSTPAID_SUBR_N1
    left join PRD_BIZ_SUMM_VW.VW_RATE_PLAN_REF
    on VW_PREPD_POSTPAID_SUBR_N1.Rate_Plan_Cd = VW_RATE_PLAN_REF.Rate_Plan_Cd

    left join PRD_BIZ_SUMM_VW.VW_PREPD_DEMO_CARD
    on VW_PREPD_POSTPAID_SUBR_N1.Subr_Num = VW_PREPD_DEMO_CARD.Msisdn

    left join PRD_BIZ_SUMM_VW.VW_SUBR_NOMINATION_HIST 
    on VW_PREPD_POSTPAID_SUBR_N1.Cust_Num = VW_SUBR_NOMINATION_HIST.CUST_NUM
    and VW_PREPD_POSTPAID_SUBR_N1.subr_num = VW_SUBR_NOMINATION_HIST.subr_num

    left join PRD_BIZ_SUMM_VW.VW_SUBR_DATA_ENTITLE
    on VW_PREPD_POSTPAID_SUBR_N1.Cust_Num = VW_SUBR_DATA_ENTITLE.CUST_NUM
    and  VW_PREPD_POSTPAID_SUBR_N1.subr_num = VW_SUBR_DATA_ENTITLE.subr_num

    left join PRD_BIZ_SUMM_VW.VW_SHK_RATE_PLAN_GRP_REF
    on VW_SUBR_DATA_ENTITLE.FREE_DATA_ENTITLE = VW_SHK_RATE_PLAN_GRP_REF.FREE_DATA_ENTITLE

    WHERE VW_PREPD_POSTPAID_SUBR_N1.D_Active_Subr_Flg = 'Y'
                    AND VW_PREPD_POSTPAID_SUBR_N1.Prepost_Type = 'PO'
                    AND CASE 
                                    WHEN (
                                                                    VW_PREPD_POSTPAID_SUBR_N1.Prepost_Type <> 'PO'
                                                                    AND VW_PREPD_DEMO_CARD.Msisdn <> ' '
                                                                    )
                                                    THEN 'N'
                                    WHEN (
                                                                    (coalesce(VW_RATE_PLAN_REF.Rate_Plan_Grp, ' ')) IN (
                                                                                    'Add-on Numbers'
                                                                                    ,'Non Revenue Mobile Plan'
                                                                                    ,'Non Revenue BB Line'
                                                                                    ,'DHL Special Project'
                                                                                    )
                                                                    )
                                                    THEN 'N'
                                    WHEN (
                                                                    (coalesce(VW_PREPD_POSTPAID_SUBR_N1.Cust_Type_Cd, ' ')) IN (
                                                                                    'SMC'
                                                                                    ,'LPUC1'
                                                                                    ,'HKBU1'
                                                                                    ,'RWSU1'
                                                                                    ,'HKBU2'
                                                                                    ,'GCU1'
                                                                                    )
                                                                    )
                                                    THEN 'N'
                                    ELSE 'Y'
                                    END = 'Y'
                    AND VW_PREPD_POSTPAID_SUBR_N1.NC_FLG = 'N'
                    AND VW_SHK_RATE_PLAN_GRP_REF.SHK_PLAN_SUBGRP NOT IN (
                                    'Excluded'
                                    ,'MVNOs (Local)'
                                    ,'MVNOs (Roaming)'
                                    )
                    AND VW_SUBR_NOMINATION_HIST.NOMINATION_FLG = 'N'
    )

        select distinct
             t.cust_num
            ,t.subr_num
            ,a.D_LANG_PREFERENCE as LANG
        from PRD_BIZ_SUMM_VW.VW_PREPD_POST_COMM_LANG a
        join t
        on t.CUST_NUM = a.CUST_NUM and t.SUBR_NUM = a.SUBR_NUM
    """,con=conn)

    sdf_lang=spark.createDataFrame(df_lang)

    ##--------------------------- 3. Pivot & Merge ---------------------------##
    # merge all domain data
    res_merged=res_house_moving.union(res_house_renovating).union(res_hkbn).union(res_netvigator).union(res_village_property_agent).cache()

    # get pivot table
    res_pivot=res_merged.groupBy('date_id','SUBR_NUM')\
                        .pivot('APPS').agg(f.sum('TOTAL_BYTE_COUNT').alias('TOTAL_BYTE_COUNT'),\
                                           f.countDistinct('date_id').alias('TOTAL_DAYS')\
                                          ).na.fill(0).withColumnRenamed('date_id','DATE_ID')

    # Union HKBN Hotline & Netvigator Hotline
    sdf_2n_call_log=sdf_hkbn.union(sdf_netvigator)
    res_2n_call_Log=sdf_2n_call_log.groupby('DATE_ID','SUBR_NUM').pivot('network_operator').agg(f.sum('CALL_DUR').alias('CALL_DUR')).na.fill(0)
    sdf_5gbb=sdf_5gbb.withColumnRenamed('MOBILE_SUBR_NUM', 'SUBR_NUM')

    # join other tables
    res=res_2n_call_Log.join(res_pivot,['DATE_ID','SUBR_NUM'],'outer').na.fill(0)\
                       .join(sdf_postpaid_mas_n1,['SUBR_NUM'],'left').where('CUST_NUM is not null')\
                       .join(sdf_5gbb,['CUST_NUM', 'SUBR_NUM'],'left').na.fill('N')\
                       .join(sdf_hkid_5gbb,['D_HKID_N'],'left').na.fill('N')\
                       .join(sdf_lang,['CUST_NUM', 'SUBR_NUM'], 'left')

    # join FBB
    res_FBB=sdf_FBB.select(col('CUST_NUM'),col('SUBSCRIBER_SWITCH_OFF_DATE')).withColumn('FBB_CHURN_USER',lit('Y'))
    res=res.join(res_FBB,['CUST_NUM'],'outer')
    res=res.fillna('N','FBB_CHURN_USER')

    ##--------------------------- 4. Output csv ---------------------------##
    ## final check for missing columns
    ## usually due to empty results
    col_to_check = ['HKBN', 'NETVIGATOR', 'HKBN_TOTAL_BYTE_COUNT', 'HOUSE_MOVING_TOTAL_BYTE_COUNT', 'HOUSE_RENOVATING_COMPANYS_TOTAL_BYTE_COUNT', 'NETVIGATOR_TOTAL_BYTE_COUNT', 'VILLAGE_TOTAL_BYTE_COUNT']
    missing_cols = set(col_to_check) - set(res.columns)
    print(f'[Info] Missing Columns: {missing_cols}')

    # create columns with value 0
    for c in missing_cols:
        res = res.withColumn(c, f.lit(0))
        print(f'[Info] Created Col {c}')

    # output .csv
    sdf_out = res.filter(col('CURRENTLY_5GBB_USER') == 'N')\
        .filter(col('Cur_5GBB_by_HKID') != 'Y')\
        .select(\
               col('DATE_ID').alias('DATE')\
               ,'CUST_NUM', 'SUBR_NUM'\
               ,col('HKBN').alias('HKBN_RET_HOTLINE_IN_MINS')\
               ,col('NETVIGATOR').alias('NETVIGATOR_RET_HOTLINE_IN_MINS')\
               ,col('hkbn_TOTAL_BYTE_COUNT').alias('HKBN_USAGE')\
               ,col('house_moving_TOTAL_BYTE_COUNT').alias('HOUSE_MOVING_USAGE')\
               ,col('house_renovating_companys_TOTAL_BYTE_COUNT').alias('HOUSE_RENOVATING_COMPANYS_USAGE')\
               ,col('netvigator_TOTAL_BYTE_COUNT').alias('NETVIGATOR_USAGE')\
               ,col('village_TOTAL_BYTE_COUNT').alias('VILLAGE_PROPERTY_AGENT_USAGE')\
               ,col('LANG').alias('LANGUAGE')\
               ) # .toPandas().to_csv(output_path, index=False)

    sdf_out.show()
    
    print(f"writing result to output path: {output_path}")
    sdf_out.repartition(1).write.option("header", "true").csv(output_path)

    spark.stop()
    conn.close()
    print('[Info] The End')


if __name__ == '__main__':

    # parser
    parser = argparse.ArgumentParser(description='config')
    parser.add_argument('run_date', type=str, default='', help='file export date (yyyymmdd), default will get today')
    args = parser.parse_args()

    main(file_export_date=args.run_date)
