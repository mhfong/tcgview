#!/usr/bin/env python
# coding: utf-8

# Workflow
# 
# 1. read all csv.gz data by timestamp in file name, e.g. SSL_SDE-RG01a_202210090845_791308.csv -> 2021-10-09 08:45. currently read daily
# 2. parse data and then find date col and output the data in parquet format, partition by date col, in pipeline_output_dir
# 3. move processed data files to 'derived_dir'
# 4. Use sslweb_delete.py to delete files in derived dir daily

import argparse
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from pyspark.sql.functions import when, expr
from pyspark.sql.types import StructType, StructField, IntegerType, StringType
from weblog_util.paths import raw_csv_ssl, ssl_parquet


# schema
schema_raw = StructType([
    StructField("MSISDN", StringType(), True),
    StructField("IP1", StringType(), True),
    StructField("TIME_START", StringType(), True),
    StructField("IP2", StringType(), True),
    StructField("BYTE_COUNT_UP", IntegerType(), True),
    StructField("BYTE_COUNT_DOWN", IntegerType(), True),
    StructField("SSL_CERT_DOMAIN", StringType(), False),
    StructField("TIME_END", StringType(), True)])


# get binary time string
def hourly_string(l):
    output = ''
    for i in range(0, 24):
        if int(i) in l:
            output += '1'
        else:
            output += '0'
    return output


def binary2int(txt):
    txt = str(txt)
    try:
        return int(txt, 2)
    except:
        return None


# define pyspark udf
udf_hourly_string = F.udf(lambda x: hourly_string(x), StringType())


# binary string to integer
udf_b2int = F.udf(binary2int)


def processor(
        spark,
        run_date,
        byte_to_kb_ratio=1024,
):
    # check the parquet folder exists
    partition_key = "part_key"
    full_raw_ssl_path = f"{raw_csv_ssl}/{partition_key}={str(run_date.replace('-', ''))}"

    sdf = spark.read.csv(full_raw_ssl_path, sep='|', header=False, schema=schema_raw)
    # drop na domain rows
    sdf = sdf.na.drop(subset=['SSL_CERT_DOMAIN'])

    sdf = sdf.withColumn('date_id', F.date_format(F.to_date(F.col('TIME_START'), 'yyyyMMddHHmmss'), "yyyy-MM-dd"))
    # filter only today's data
    sdf = sdf.filter(F.col('date_id') == run_date)

    # create necessary columns for grouping
    sdf = sdf.withColumn('SSL_CERT_DOMAIN', F.upper(F.col('SSL_CERT_DOMAIN'))) \
        .withColumn('START_TIMESTAMP', F.to_timestamp(F.col('TIME_START'), 'yyyyMMddHHmmss')) \
        .withColumn('END_TIMESTAMP', F.to_timestamp(F.col('TIME_END'), 'yyyyMMddHHmmss')) \
        .withColumn('SECONDS', F.col('END_TIMESTAMP').cast('long') - F.col('START_TIMESTAMP').cast('long')) \
        .withColumn('MINUTES', F.col('SECONDS') / 60) \
        .withColumn('START_HOUR', F.hour(F.col('START_TIMESTAMP')))

    # group by SUBR_NUM, ACCESS_DATE, SSL_CERT_DOMAIN
    sdf = sdf.groupBy('MSISDN', 'date_id', 'SSL_CERT_DOMAIN').agg(
        F.count("*").alias('TOTAL_HIT'),
        F.collect_set(F.col('START_HOUR')).alias('START_HOUR_SET'),
        F.sum('BYTE_COUNT_UP').alias('BYTE_COUNT_UP'),
        F.sum('BYTE_COUNT_DOWN').alias('BYTE_COUNT_DOWN'),
        F.sum('SECONDS').alias('SECONDS'),
        F.sum('MINUTES').alias('MINUTES')
    )

    # add last few columns
    sdf = sdf.withColumn('SUBR_NUM', when(F.col('MSISDN').startswith('852'),
                                          expr("substring(MSISDN, 4, length(MSISDN))")).otherwise(F.col('MSISDN'))) \
        .withColumn('BYTE_COUNT', sum([F.col('BYTE_COUNT_UP'), F.col('BYTE_COUNT_DOWN')])) \
        .withColumn('KB_COUNT', F.col('BYTE_COUNT') / byte_to_kb_ratio) \
        .withColumn('KB_COUNT_UP', F.col('BYTE_COUNT_UP') / byte_to_kb_ratio) \
        .withColumn('KB_COUNT_DOWN', F.col('BYTE_COUNT_DOWN') / byte_to_kb_ratio) \
        .withColumn('HOUR_BINARY', udf_hourly_string(F.col('START_HOUR_SET')))

    # reorder
    sdf = sdf.select(F.col('SUBR_NUM').cast("bigint").alias("subr_num"),
                     F.col('SSL_CERT_DOMAIN').alias("ssl_cert_domain"),
                     F.col('BYTE_COUNT').cast("bigint").alias("byte_count"),
                     udf_b2int(F.col('HOUR_BINARY')).cast("int").alias("hour_binary"),
                     F.col("TOTAL_HIT").cast("bigint").alias("total_hit"),
                     'date_id')

    # save to parquet
    part_key = run_date.replace('-', '')
    sdf.write.mode('overwrite').parquet(f'{ssl_parquet}/part_key={part_key}')


def main(
    run_date: str, *,
    byte_to_kb_ratio
):
    """
    time_stamp: timestamp to select data files to process
    filename_format: filename format, e.g. '*_{}*.csv.gz', used format to replace {} with timestamp
    input_dir: directory that contains the raw data from DW
    working_dir: directory that contains the processing data
    pipeline_output_dir: directory that contains the output parquet files
    derived_dir: directory that contains processed raw data from DW
    byte_to_kb_ratio: ratio for converting byte to kb
    """
    spark = SparkSession.builder.appName("weblog-raw-ssl").getOrCreate()

    # process data
    processor(
        spark=spark,
        run_date=run_date,
        byte_to_kb_ratio=byte_to_kb_ratio,
    )


STEP1_CONFIG = {
    # 'input_dir': "/app/sna_bdmrdev01/t_ssl/raw/",
    # 'working_dir': "/app/sna_bdmrdev01/t_ssl/working/",
    # 'pipeline_output_dir': "/app/sna_bdmrdev01/ws-ic/hive/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ/",
    # 'derived_dir': "/app/sna_bdmrdev01/weblog_ssl_housekeep/",
    #
    # 'filename_format': "*_{}*.csv.gz",
    'byte_to_kb_ratio': 1024,
}

if __name__ == '__main__':

    # parser 0 4 * * *
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str, default='', help='yyyy-mm-dd of the date of data files')
    args = parser.parse_args()

    main(args.run_date, **STEP1_CONFIG)
