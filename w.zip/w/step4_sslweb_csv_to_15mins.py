import argparse, logging
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from pyspark.sql.functions import split, col, expr
from pyspark.sql.types import BooleanType, ArrayType, StructType, StringType, StructField, IntegerType
from weblog_util.paths import domain_daily_15mins, raw_csv_ssl, domain_index_latest


# schema
schema_raw = StructType([
    StructField("MSISDN", StringType(), True),
    StructField("IP1", StringType(), True),
    StructField("TIME_START", StringType(), True),
    StructField("IP2", StringType(), True),
    StructField("BYTE_COUNT_UP", IntegerType(), True),
    StructField("BYTE_COUNT_DOWN", IntegerType(), True),
    StructField("SSL_CERT_DOMAIN", StringType(), False),
    StructField("TIME_END", StringType(), True)])


# get binary time string
def hourly_string(l):
    output = ''
    for i in range(0, 24):
        if int(i) in l:
            output += '1'
        else:
            output += '0'
    return output


def binary2int(txt):
    txt = str(txt)
    try:
        return int(txt, 2)
    except:
        return None


def xmins_string(l, interval=60):
    output = ''
    for i in range(0, 24*60//interval):
        if int(i) in l:
            output += '1'
        else:
            output += '0'
    return output


# define pyspark udf
udf_hourly_string = F.udf(lambda x: hourly_string(x), StringType())
udf_15mins_string = F.udf(lambda x: xmins_string(x, 15), StringType())
udf_30mins_string = F.udf(lambda x: xmins_string(x, 30), StringType())


# binary string to integer
udf_b2int = F.udf(binary2int)


def main(*, run_date: str):

    spark = SparkSession.builder.appName("weblog-raw-ssl").getOrCreate()

    # check the parquet folder exists
    partition_key = "part_key"
    full_raw_ssl_path = f"{raw_csv_ssl}/{partition_key}={str(run_date.replace('-', ''))}"

    logging.info('-----Web Behavior Step 1a: Start Making t_domain_daily_15min_binary------')


    # CSV to Parquet
    sdf = spark.read.csv(full_raw_ssl_path, sep='|', header=False, schema=schema_raw)
    # drop na domain rows
    sdf = sdf.na.drop(subset=['SSL_CERT_DOMAIN'])

    sdf = sdf.withColumn('date_id', F.date_format(F.to_date(F.col('TIME_START'), 'yyyyMMddHHmmss'), "yyyy-MM-dd"))
    # filter only today's data
    sdf = sdf.filter(F.col('date_id') == run_date)

    sdf = sdf.withColumn('ACCESS_DATE', F.to_date(F.col('TIME_START'), 'yyyyMMddHHmmss')) \
                     .withColumn('SSL_CERT_DOMAIN', F.upper(F.col('SSL_CERT_DOMAIN'))) \
                     .withColumn('START_INTERVAL_15MIN', F.floor(((F.substring(F.col('TIME_START'), 9,2).cast('int') * 60 + F.substring(F.col('TIME_START'), 11,2).cast('int'))/15)))
                    #  .withColumn('START_TIMESTAMP', F.to_timestamp(F.col('TIME_START'),'yyyyMMddHHmmss')) \ # to be used if necessary
                    #  .withColumn('END_TIMESTAMP', F.to_timestamp(F.col('TIME_END'),'yyyyMMddHHmmss')) \ # to be used if necessary
                    #  .withColumn('START_HOUR', F.hour(F.col('START_TIMESTAMP'))) \ # to be used if necessary
                    #  .withColumn('START_INTERVAL_30MIN', F.floor(((F.substring(F.col('TIME_START'), 9,2).cast('int') * 60 + F.substring(F.col('TIME_START'), 11,2).cast('int'))/30))) # to be used if necessary

    sdf = sdf.groupBy('MSISDN', 'ACCESS_DATE', 'SSL_CERT_DOMAIN').agg(
                    F.collect_set(F.col('START_INTERVAL_15MIN')).alias('START_INTERVAL_15MIN_SET')
                    # F.count("*").alias('TOTAL_HIT'), \ # to be used if necessary
                    # F.collect_set(F.col('START_HOUR')).alias('START_HOUR_SET'), \ # to be used if necessary
                    # F.collect_set(F.col('START_INTERVAL_30MIN')).alias('START_INTERVAL_30MIN_SET'), \ # to be used if necessary
    )

    sdf = sdf.withColumn('SUBR_NUM', F.when(F.col('MSISDN').startswith('852'), F.expr("substring(MSISDN, 4, length(MSISDN))")).otherwise(F.col('MSISDN'))) \
                        .withColumn('date_id', F.date_format(F.col('ACCESS_DATE'), "yyyyMMdd")) \
                        .withColumn('15MIN_BINARY', udf_15mins_string(F.col('START_INTERVAL_15MIN_SET')))
                        # .withColumn('HOUR_BINARY', udf_hourly_string(F.col('START_HOUR_SET'))) \ # to be used if necessary
                        # .withColumn('30MIN_BINARY', udf_30mins_string(F.col('START_INTERVAL_30MIN_SET'))) # to be used if necessary

    sdf = sdf.select(F.col('SUBR_NUM').cast("bigint").alias("subr_num"), \
                    F.col('SSL_CERT_DOMAIN').alias("domain"), \
                    F.col('15MIN_BINARY').cast("string").alias("15min_binary")
                    )
    

    logging.info('-----Web Behavior Step 1b: Join t_domain_index with t_domain_daily_15min_binary-----')


    sdf_tdi = spark.read.parquet(domain_index_latest)
    sdf_ssl = sdf
    part_key = run_date.replace('-', '')

    sdf_tdd_new = sdf_ssl\
        .join(sdf_tdi, on='domain', how='inner')\
        .withColumn("ListColumn", split(col("15min_binary"), ""))\
        .withColumn("ListColumn", expr("slice(ListColumn, 1, size(ListColumn) - 1)"))\
        .withColumn("ListBoolColumn", col("ListColumn").cast(ArrayType(BooleanType())))\
        .select(
            'subr_num',
            'domain',
            'ListBoolColumn'
        ).distinct()

    sdf_tdd_new.coalesce(10).write.mode('overwrite').parquet(f'{domain_daily_15mins}/date_id={part_key}')


if __name__ == '__main__':

    # parser 0 4 * * *
    import time
    time.sleep(20)
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str, default='', help='yyyy-mm-dd of the date of data files')
    args = parser.parse_args()

    for date in args.run_date.split(','):
        main(run_date=date.replace(' ',''))
