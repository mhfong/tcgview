import argparse, logging, sys
from datetime import datetime, timedelta

from pyspark.sql.functions import col, broadcast, posexplode
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from pyspark.sql import SparkSession
from weblog_util.save_airtable import save_airtable
from weblog_util.paths import domain_daily_15mins, web_behavior_monthly, n1table, domain_lists

logger = logging.getLogger(__name__)
log_format = "[%(asctime)s][%(funcName)25s:%(lineno)4d] %(message)s"
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=log_format)


def main(spark: SparkSession, run_date: datetime, window_size: int):

    logging.info('-----Start Making Web Behavior Monthly------')
    logging.info('-----1. Read Data------')

    yyyymmdd = run_date.strftime('%Y%m%d')

    airtable = spark.read.csv(f'{domain_lists}/run_date={yyyymmdd}/ALL_APP.csv', header=True).select('domain','APP','CATEGORY').cache()
    n1 = spark.read.parquet(n1table).select('SUBR_NUM','CUST_NUM')
    weblog = spark.read.option("basePath", domain_daily_15mins).parquet(
            *[
                f'{domain_daily_15mins}/date_id=' + (run_date - timedelta(days=i)).strftime('%Y%m%d')
                for i in range(int(run_date.day))
            ])

    logging.info('-----2. Agg Data------')

    agg_toListBool = weblog\
            .join(broadcast(airtable),'domain','inner')\
            .select('SUBR_NUM','domain','APP','CATEGORY','ListBoolColumn','DATE_ID')

    agg_exploded = agg_toListBool.select("SUBR_NUM", "DOMAIN", "APP", "CATEGORY", "DATE_ID", posexplode("ListBoolColumn").alias("pos", "value"))
    agg_exploded_max = agg_exploded.groupBy("SUBR_NUM", "APP", "CATEGORY", "pos", "DATE_ID").agg(F.max('value').alias('value'))

    window_spec = Window.partitionBy("SUBR_NUM", "APP", "CATEGORY", "DATE_ID").orderBy("pos").rowsBetween(Window.currentRow, Window.currentRow + window_size - 1)
    agg_rolling_sum = agg_exploded_max\
                        .withColumn("ROLLING_SUM", F.sum(col("value").cast("integer")).over(window_spec))\
                        .groupBy("SUBR_NUM", "APP", "CATEGORY", "DATE_ID")\
                        .agg(F.max('ROLLING_SUM').alias(f'ROLLING_SUM_RATIO_W{window_size}'))\
                        .withColumn(f"ROLLING_SUM_RATIO_W{window_size}", col(f"ROLLING_SUM_RATIO_W{window_size}") / window_size)\
                        
    result = agg_rolling_sum.join(n1, 'SUBR_NUM', 'inner')

    logging.info('-----3. Save Result------')
    
    result.coalesce(10).write.mode('overwrite').parquet(f'{web_behavior_monthly}/month_id={yyyymmdd[:-2]}')


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', metavar='yyyy-mm-dd', type=str, help='')
    parser.add_argument('window_size', metavar='n', type=int, help='')
    args = parser.parse_args()

    spark = SparkSession.builder.getOrCreate()

    run_date = datetime.strptime(args.run_date, "%Y-%m-%d")

    save_airtable(spark, run_date, 'all_website')
    main(spark, run_date=run_date, window_size=args.window_size)