import argparse
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from weblog_util.save_airtable import save_airtable
from weblog_util.paths import n1table, domain_index_latest, domain_monthly, domain_lists, subr_list_app_all


def make_list(spark: SparkSession, run_month: str):

    save_airtable(spark, 'yyyymmdd', 'ALL_APP')
    
    n1 = spark.read.parquet(n1table)
    t_domain_index = spark.read.parquet(domain_index_latest)
    t_domain_monthly = spark.read.parquet(domain_monthly+f'/month_id={run_month}')
    domain_list = spark.read.csv(f'{domain_lists}/run_date=yyyymmdd/ALL_APP.csv', header=True)


    subr_list=n1.withColumnRenamed('SUBR_NUM','subr_num').select('subr_num')\
        .join(t_domain_monthly, 'subr_num', 'inner')\
        .join(t_domain_index.withColumnRenamed('domain_index','agg_value'), 'agg_value', 'left')\
        .join(domain_list.select('domain', 'APP', 'CATEGORY'), 'domain', 'inner')\
        .select('subr_num', 'domain', 'APP', 'CATEGORY', 'byte_count', 'days', 'total_hit').cache()       

    subr_list_APP=subr_list.withColumn("APP", F.concat(F.col("CATEGORY"), F.lit("_"), F.col("APP")))\
        .groupBy('subr_num').pivot('APP').agg(
            F.sum('byte_count').alias('SUM_BYTE_COUNT'),
            F.max("days").alias('MAX_DAYS'),
            F.max("total_hit").alias('MAX_TOTAL_HIT')
        )
    subr_list_APP=subr_list_APP.select(
            [F.col('subr_num')]+[F.col(c).alias("WEBLOG_APP_"+c) for c in subr_list_APP.columns[1:]]
        ).cache()

    subr_list_CAT=subr_list.groupBy('subr_num').pivot('CATEGORY').agg(
            F.sum('byte_count').alias('SUM_BYTE_COUNT'),
            F.max("days").alias('MAX_DAYS'),
            F.max("total_hit").alias('MAX_TOTAL_HIT')
        )
    subr_list_CAT=subr_list_CAT.select(
            [F.col('subr_num')]+[F.col(c).alias("WEBLOG_CATEGORY_"+c) for c in subr_list_CAT.columns[1:]]
        ).cache()

    final_subr_list=subr_list_APP.join(subr_list_CAT,on='subr_num',how='outer')\
        .withColumn('month_id', F.lit(run_month))

    return final_subr_list


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_month', type=str, default='', help='yyyymm of the date of data files')
    args = parser.parse_args()

    spark = SparkSession.builder.appName("subr_list").getOrCreate()

    result = make_list(spark, args.run_month)
    result.coalesce(10).write.mode('overwrite').parquet(f'{subr_list_app_all}/weblog_{args.run_month}.parquet')