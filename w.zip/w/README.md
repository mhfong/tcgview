<img src="src/weblog_pipeline.png">


# Weblog SSL

## Daily Job 1 - weblog_daily
 
- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=weblog_daily)
- **Description:** run step 1-4 in the diagram for each last 3 days
- **Schedule:** Daily 13:00 p.m.

### step 1
- **Script:** step1_sslweb_csv_to_parquet.py
- **Description:** aggregate raw csv.gz and save to parquet in ezmeral
- **Size:** 5 GB
- **Run time:** 50 mins
- **Source:**

`dtap://ext_mapr_hive/ssl_udr`

- **Result:**

`dtap://ext_mapr/weblog/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ`

### step 2
- **Script:** step2_update_domain_index_manual.py
- **Description:** update t_domain_index if any new domain with more than 50 times is found
- **Size:** 150 MB
- **Run time:** 5 mins
- **Source:**

`dtap://ext_mapr/weblog/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ`

- **Result:**

`dtap://ext_mapr/weblog/t_domain_index_daily` (daily snapshot)

`dtap://ext_mapr/weblog/t_domain_index` (latest)

### step 3
- **Script:** step2a_index_validation.py
- **Description:** validation of t_domain_index
- **Run time:** 5 mins

### step 4
- **Script:** step2b_daily_aggregrate_manual.py
- **Description:** clean ssl parquet file to t_domain_daily
- **Size:** 3 GB
- **Run time:** 5 mins
- **Source:**

`dtap://ext_mapr/weblog/prd_biz_summ_vw.db/vw_idp_ssl_sed_call_summ`

- **Result:**

`dtap://ext_mapr/weblog/t_domain_daily`

### step 5
- **Script:** step2c_daily_domain_check.py
- **Description:** validation of t_domain_daily
- **Run time:** 5 mins

## Daily Job 2 - weblog_housemoving
- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=weblog_housemoving)
- **Description:** generate dataset for shkp with validation
- **Schedule:** Every Mon, Wed, Fri 08:30 a.m.
- **Script:** weblog_housemoving.py
- **Description:** clean ssl parquet file to t_domain_daily
- **Size:** 3 GB
- **Run time:** 15 mins
- **Source:**

`dtap://ext_mapr/weblog/t_domain_index`

`dtap://ext_mapr/weblog/t_domain_daily`

- **Result:**

`dtap://ext_mapr/weblog/data_out/to_Cognos_De_SMS`


## Daily Job 3 - website_subscribers
- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=website_subscribers)
- **Description:** generate dataset for personas tag
- **Schedule:** 17:30 p.m.
- **Script:** website_subscribers.py
- **Description:** clean ssl parquet file to t_domain_daily
- **Size:** 300 MB
- **Run time:** 15 mins
- **Source:**

`dtap://ext_mapr/weblog/t_domain_index`

`dtap://ext_mapr/weblog/t_domain_monthly`

`dtap://ext_mapr/weblog/airtable`

- **Result:**

`dtap://ext_mapr/weblog/data_out/to_Cognos_De_SMS`


## Monthly Job 1 - t_domain_monthly

- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=weblog_monthly)
- **Description:** aggregated t_domain_daily to t_domain_monthly
- **Script:** step3_monthly_aggregate.py
- **Schedule:** 4th 16:00 p.m.
- **Size:** 20 GB
- **Run time:** 90 mins
- **Source:**

`dtap://ext_mapr/weblog/t_domain_index`

`dtap://ext_mapr/weblog/t_domain_daily`

- **Result:**

`dtap://ext_mapr/weblog/t_domain_monthly`


## Monthly Job 2 - allapp_list

- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=allapp_list)
- **Description:** generate dataset for sunny's churn model
- **Script:** step3_monthly_aggregate.py
- **Schedule:** 10th 13:00 p.m.
- **Size:** 600 MB
- **Run time:** 20 mins
- **Source:**

`dtap://ext_mapr/weblog/t_domain_index`

`dtap://ext_mapr/weblog/t_domain_daily`

`dtap://ext_mapr/weblog/airtable`

- **Result:**

`dtap://TenantStorage/weblog/adhoc/subr_list_all_app`
