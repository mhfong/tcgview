import argparse
import logging
import sys
from datetime import datetime

import pyspark.sql.functions as F
from dateutil.relativedelta import relativedelta
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType
from weblog_util.paths import domain_daily, domain_monthly


# Logger
logger = logging.getLogger(__name__)
log_format = "[%(asctime)s][%(funcName)25s:%(lineno)4d] %(message)s"
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=log_format)


def main(run_month):
    spark = SparkSession.builder.appName("weblog-monthly").getOrCreate()
    # define sc for checking to closing spark

    ## --------------------------------- Get Sdfs ------------------------------ ##
    # t domain daily, filtered by current month
    run_month = run_month[:7] + '-01'
    sdf_tdd_cm = spark.read.parquet(domain_daily).withColumn(
        '_filter', F.trunc(F.to_date(F.col('date_id').cast(StringType()), 'yyyyMMdd'), 'mon')
    ).filter(
        f"_filter = '{run_month}'"
    ).drop('_filter')

    # t domain monthly
    # sdf_tdm = spark.read.parquet(t_domain_monthly_dir)

    ## ------------------------------- Aggregate -------------------------------- ##
    # get days of a month
    count_days = sdf_tdd_cm.select('date_id').distinct().count()

    # check if all t doamin daily ready and t domain monthly not exist
    run_month_dt = datetime.strptime(run_month, '%Y-%m-%d')
    days_in_month = (run_month_dt + relativedelta(months=1) - run_month_dt).days

    if count_days == days_in_month:
        logging.info('Ready to generate t domain monthly')

        # aggregate
        sdf_tdm_new = sdf_tdd_cm.groupby(['subr_num', 'agg_value', 'agg_level']) \
            .agg(
            F.sum(F.col('in_byte')).alias('in_byte'),
            F.sum(F.col('out_byte')).alias('out_byte'),
            F.sum(F.col('byte_count')).alias('byte_count'),
            F.sum(F.col('total_hit')).alias('total_hit'),
            F.sum(F.col('duration')).alias('duration'),
            F.countDistinct('date_id').alias('days'))

        # write
        # no need to delete old directory since checked above
        month_id = run_month_dt.strftime('%Y%m')
        sdf_tdm_new.write.mode('overwrite') \
            .parquet(f'{domain_monthly}/month_id={month_id}')
    else:
        logging.info(f'Not Ready to generate t domain monthly. Number of days of data for now: {count_days}')

    logging.info(f"End, {datetime.now()}")


if __name__ == '__main__':

    # parser
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_month', type=str, help='yyyy-mm')
    args = parser.parse_args()

    main(args.run_month)
