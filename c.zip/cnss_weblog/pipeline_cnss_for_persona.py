from pyspark.sql import SparkSession
import argparse
from datetime import datetime, timedelta
from cnss_apps.remote_app import frequent_remote_app
from cnss_apps.streaming_apps import frequent_streaming_app
from cnss_apps.data_usage_statistics import data_usage
from cnss_apps.heavy_streaming_app import heavy_streaming_app
from cnss_apps.subscriber_disney_plus import disney_plus_app
from src.path import ebm_daily_path, n1_path


ALL_APPS_EBM = {
    'FREQUENT_REMOTE_APP': frequent_remote_app,
    'FREQUENT_STREAMING_APP': frequent_streaming_app,
    'DATA_USAGE_UPLINK_DOWNLINK': data_usage,
    'HEAVY_STREAMING_APP': heavy_streaming_app,
    'DISNEY_PLUS_APP': disney_plus_app
}

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str, default='', help='yyyy-mm-dd of the date of data files')
    args = parser.parse_args()

    spark = SparkSession.builder.appName("cnss-for-persona").getOrCreate()

    for d in args.run_date.split(','):
        run_date = datetime.strptime(d, '%Y-%m-%d')
        if args.run_date == 'yyyy-mm-dd': 
            run_date = (datetime.now() - timedelta(days=2))

        ebm = spark.read.option("basePath", ebm_daily_path[:-10]).parquet(
                *[
                    ebm_daily_path.format((run_date - timedelta(days=i)).strftime('%Y%m%d'))
                    for i in range(30)
                ]
            )
        n1 = spark.read.parquet(n1_path)

        data = {
            "n1_table": n1
        }

        for tag, func in ALL_APPS_EBM.items():
            func(spark, run_date, tag, ebm, **data)