import logging
from pyspark.sql import SparkSession, DataFrame
from datetime import datetime
import pyspark.sql.functions as F
from pyspark.sql.functions import col, when
from src.path import s11_output_path


def disney_plus_app(spark: SparkSession, run_date: datetime, tag: str, cnss: DataFrame, n1_table: DataFrame):

    yyyymmdd = run_date.strftime('%Y%m%d')
    n1 = n1_table.select('SUBR_NUM', 'CUST_NUM')

    logging.info('-----EBM daily to disney+ subscribers------')

    cnss = cnss.filter(F.col('APP_NAME')=='disney_plus').withColumn(
        'WATCHED_DISNEY_PLUS_PAST_30D',
        F.lit(True)
    ).select(
        'SUBR_NUM',
        'WATCHED_DISNEY_PLUS_PAST_30D',
    )

    result = cnss.join(n1, 'SUBR_NUM','inner').distinct()

    result.write.mode('overwrite').parquet(s11_output_path+f'/{tag.lower()}/date_id={yyyymmdd}')