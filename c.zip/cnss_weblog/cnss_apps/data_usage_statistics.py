import logging
from pyspark.sql import SparkSession, DataFrame
from datetime import datetime
from pyspark.sql import functions as F
from src.path import ebm_personas_features_path
from src.cnss_configs import (COLNAME_EBM_DAILY_UPLINK_USAGE, 
                              COLNAME_EBM_DAILY_DOWNLINK_USAGE, 
                              APP_DATA_USAGE_STATISTICS)


def data_usage(spark: SparkSession, run_date: datetime, tag: str, ebm: DataFrame, n1_table: DataFrame,is_save=True):

    yyyymmdd = run_date.strftime('%Y%m%d')

    logging.info('-----Agg CNSS for UPLINK AND DOWNLINK DATA USAGE------')

    aggregation_conditions = []

    for APP in APP_DATA_USAGE_STATISTICS:
        aggregation_conditions.extend([

            F.sum(F.when(F.col("APP_NAME") == APP, 
                         F.col(COLNAME_EBM_DAILY_UPLINK_USAGE)).otherwise(0)
                ).alias(f"{APP}_UPLINK_USAGE_30D"),

            F.sum(F.when(F.col("APP_NAME") == APP, 
                         F.col(COLNAME_EBM_DAILY_DOWNLINK_USAGE)).otherwise(0)
                ).alias(f"{APP}_DOWNLINK_USAGE_30D")
            ]
        )

    _ebm = ebm.groupBy('SUBR_NUM')\
                .agg(
                    F.sum(COLNAME_EBM_DAILY_UPLINK_USAGE).alias("ALL_CNSS_APPS_TOTAL_UPLINK_USAGE_30D"),
                    F.sum(COLNAME_EBM_DAILY_DOWNLINK_USAGE).alias("ALL_CNSS_APPS_TOTAL_DOWNLINK_USAGE_30D"),
                    *aggregation_conditions,
                )\
                .filter(F.col("SUBR_NUM").isNotNull())\
                .fillna(0)

    for column in _ebm.columns:
        _ebm = _ebm.withColumnRenamed(column, column.upper())

    result = _ebm.join(n1_table, 'SUBR_NUM','inner').select('CUST_NUM', 'SUBR_NUM', *sorted(_ebm.columns[1:]))

    if is_save:
        result.write.mode('overwrite').parquet(ebm_personas_features_path+f'/{tag.lower()}/date_id={yyyymmdd}')
    else:
        return result