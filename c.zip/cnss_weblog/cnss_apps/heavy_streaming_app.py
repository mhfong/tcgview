
import pyspark.sql.functions as F
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType, StructField, ArrayType, StringType
from pyspark.sql.window import Window
from src.path import cnss_app_output_path, cnss_category_output_path
from datetime import datetime, timedelta
from src.cnss_configs import AppCategory
from functools import reduce
from typing import Dict, Set


def cnss_app_categories() -> Dict[str, Set[str]]:
    """
    dict
    {'app name': {categories, ...}, ...}
    """
    d = {}
    for cat in AppCategory:
        for app in cat.value:
            if app.upper() in d:
                d[app.upper()].add(cat.name)

            else:
                d[app.upper()] = {cat.name}
    return d

     
def clean_ebm(spark: SparkSession, raw_df: DataFrame, apps: Dict[str, Set[str]]):

    categories = spark.createDataFrame([(k, list(v)) for k, v in apps.items()], schema=StructType(fields=[
        StructField('APP_NAME', StringType()),
        StructField('CATEGORIES', ArrayType(StringType())),
    ]))
    
    return raw_df.withColumn(
            "APP_NAME", F.upper(F.col('APP_NAME'))
        ).join(
            F.broadcast(categories), on='APP_NAME'
        )


def app_df(raw_cleaned: DataFrame, apps: Dict[str, Set[str]]):
    """
    Calculate app related columns
    CNSS_APP_[APP]_DATA_USAGE_30D
    CNSS_APP_[APP]_DAYS_COUNT_30D
    """

    app_usage = raw_cleaned.groupby('SUBR_NUM').pivot(
        "APP_NAME", values=list(apps.keys())
    ).agg(
        F.sum(F.col('USG_MB')).alias('DATA_USAGE'),
        F.count(F.col('date_id')).alias('DAYS_COUNT')
    )
    for o, n in [(c, 'CNSS_APP_'+c+'_30D') for c in app_usage.columns[1:]]:
        app_usage = app_usage.withColumnRenamed(o, n)

    return app_usage.fillna(0)


def category_df(raw_cleaned: DataFrame, apps: Dict[str, Set[str]]):
    """
    Calculate app category related columns
    CNSS_CATEGORY_[CATEGORY]_DATA_USAGE_30D
    CNSS_CATEGORY_[CATEGORY]_DAYS_COUNT_30D
    CNSS_CATEGORY_[CATEGORY]_DISTINCT_APP_COUNT_30D
    """
    all_cat = reduce(lambda a, b: a.union(b), apps.values())

    cat = raw_cleaned.withColumn(
        'CATEGORY', F.explode('CATEGORIES')
    )
    
    cat_usage = cat.groupby('SUBR_NUM').pivot(
        "CATEGORY", values=list(all_cat)
    ).agg(
        F.sum(F.col('USG_MB')).alias('DATA_USAGE'),
        F.countDistinct(F.col('date_id')).alias('DAYS_COUNT'),
        F.countDistinct(F.col('APP_NAME')).alias('DISTINCT_APP_COUNT')
    )
    for o, n in [(c, 'CNSS_CATEGORY_'+c+'_30D') for c in cat_usage.columns[1:]]:
        cat_usage = cat_usage.withColumnRenamed(o, n)

    return cat_usage.fillna(0)

    
def heavy_streaming_app(spark: SparkSession, run_date: datetime, tag: str, ebm: DataFrame, n1_table: DataFrame):
    apps = cnss_app_categories()
    cleaned = clean_ebm(spark, raw_df=ebm, apps=apps)
    date_id = run_date.strftime('%Y%m%d')
    n1 = n1_table.select('SUBR_NUM', 'CUST_NUM')

    apps_df = app_df(cleaned, apps).join(n1, on='SUBR_NUM')
    apps_df.write.mode('overwrite').parquet(
        cnss_app_output_path.format(date_id=date_id)
    )

    cat_df = category_df(cleaned, apps).join(n1, on='SUBR_NUM')
    cat_df.write.mode('overwrite').parquet(
        cnss_category_output_path.format(date_id=date_id)
    )