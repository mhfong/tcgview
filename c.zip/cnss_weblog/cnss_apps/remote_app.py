import logging
from pyspark.sql import SparkSession, DataFrame
from datetime import datetime
import pyspark.sql.functions as F
from pyspark.sql.functions import col, when
from src.path import s11_output_path


def frequent_remote_app(spark: SparkSession, run_date: datetime, tag: str, cnss: DataFrame, n1_table: DataFrame):

    yyyymmdd = run_date.strftime('%Y%m%d')
    n1 = n1_table.select('SUBR_NUM', 'CUST_NUM')

    logging.info('-----Agg CNSS for remote worker------')

    cnss = cnss.filter(col('APP_NAME').isin(['ms_teams','zoom']))\
                .groupBy('SUBR_NUM')\
                .pivot('APP_NAME')\
                .agg(
                    F.sum(
                        when(
                            (col('is_HBB')==1),
                            col('ACTIVE_MINUTES')
                        )
                    ).alias('5GHBB_ACTIVE_MINUTES_PAST_30D'),
                    F.sum(
                        when(
                            (col('is_HBB')==0),
                            col('ACTIVE_MINUTES')
                        )
                    ).alias('ACTIVE_MINUTES_PAST_30D')
                )

    cnss = cnss.select(
        col('SUBR_NUM'),
        *[col(c).alias("CNSS_APP_" + c.upper()) for c in cnss.columns if c != 'SUBR_NUM']
    )

    result = cnss.join(n1, 'SUBR_NUM','inner').select('CUST_NUM', 'SUBR_NUM', *sorted(cnss.columns[1:]))

    result.write.mode('overwrite').parquet(s11_output_path+f'/{tag.lower()}/date_id={yyyymmdd}')