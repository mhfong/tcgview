from enum import Enum


S11_APP_LIST = ['akamai', 'alipay', 'amazon', 'amazon_aws', 'apple', 'apple_music', 'apple_pay',
                'apple_update', 'applovin', 'appstore', 'baidu', 'bittorrent', 'discord', 'disney_plus',
                'douyin', 'edonkey', 'facebook', 'facebook_live', 'facebook_messenger', 'facebook_video',
                'facetime', 'gmail', 'gnutella', 'google', 'google_ads', 'google_maps', 'google_photos',
                'google_play', 'hsbc', 'icloud', 'instagram', 'kkbox', 'line', 'linkedin', 'ms_teams',
                'mytv_super', 'netflix', 'office365', 'outlook', 'playstation', 'pplive', 'qqvideo',
                'roblox', 'safari_web', 'signal_private_messenger', 'skype', 'snapchat', 'speedtest',
                'spotify', 'steam', 'taobao', 'telegram', 'tencent', 'tiktok', 'twitch', 'twitter', 'unity',
                'viu', 'wechat', 'whatsapp', 'xiaohongshu', 'yahoo', 'youku', 'youtube', 'zattoo', 'zoom']


S11_EBM_MAPPING_TABLE = {
    "app-heur-akamai": 'akamai',
    "app-heur-alipay": 'alipay',
    "app-heur-amazon": 'amazon',
    "app-heur-amazon-aws": 'amazon_aws',
    "app-heur-apple": 'apple',
    "app-heur-itunes-apple-music": 'apple_music',
    "app-heur-apple-pay": 'apple_pay',
    "app-heur-apple-update": 'apple_update',
    "app-heur-applovin": 'applovin',
    "app-heur-appstore": 'appstore',
    "app-heur-baidu": 'baidu',
    "app-heur-bit-torrent": 'bittorrent',
    "app-heur-discord": 'discord',
    "app-heur-disneyplus-video": 'disney_plus',
    "app-heur-douyin": 'douyin',
    "app-heur-edonkey": 'edonkey',
    "app-heur-facebook": 'facebook',
    "app-heur-facebook-live": 'facebook_live',
    "app-heur-facebook-messenger": 'facebook_messenger',
    "app-heur-facebook-video": 'facebook_video',
    "app-heur-facetime": 'facetime',
    "app-heur-gmail": 'gmail',
    "app-heur-gnutella": 'gnutella',
    "app-heur-google": 'google',
    "app-heur-google-ads": 'google_ads',
    "app-heur-google-maps": 'google_maps',
    "app-heur-google-photos": 'google_photos',
    "app-heur-google-play": 'google_play',
    "app-adc-heur-hsbc": 'hsbc',
    "app-heur-icloud": 'icloud',
    "app-heur-instagram": 'instagram',
    "app-heur-kkbox": 'kkbox',
    "app-heur-line": 'line',
    "app-heur-linkedin": 'linkedin',
    "app-adc-heur-teams-voip": 'ms_teams',
    "app-heur-mytv-super": 'mytv_super',
    "app-adc-heur-netflix-video": 'netflix',
    "app-heur-office365": 'office365',
    "app-heur-outlook-hotmail": 'outlook',
    "app-heur-payme": 'payme',
    "app-heur-playstation": 'playstation',
    "app-heur-pplive": 'pplive',
    "app-heur-qqvideo-qqlive": 'qqvideo',
    "app-heur-roblox": 'roblox',
    "app-heur-safari-web": 'safari_web',
    "app-heur-signal-pri-msgr": 'signal_private_messenger',
    "app-heur-skype": 'skype',
    "app-heur-snapchat": 'snapchat',
    "app-adc-net-speedtest": 'speedtest',
    "app-heur-spotify": 'spotify',
    "app-heur-steam": 'steam',
    "app-heur-taobao": 'taobao',
    "app-heur-telegram": 'telegram',
    "app-heur-tencent-qq": 'tencent',
    "app-heur-twitch": 'twitch',
    "app-heur-tiktok": 'tiktok',
    "app-heur-twitter": 'twitter',
    "app-heur-unity3d": 'unity',
    "app-heur-viu": 'viu',
    "app-heur-wechat": 'wechat',
    "app-heur-whatsapp": 'whatsapp',
    "app-heur-xiaohongshu": 'xiaohongshu',
    "app-heur-yahoo": 'yahoo',
    "app-heur-yahoomail": 'yahoomail',
    "app-heur-youku": 'youku',
    "app-heur-youtube-video": 'youtube',
    "app-heur-xunlei": 'xunlei',
    "app-heur-zattoo": 'zattoo',
    "app-adc-heur-zoom": 'zoom'
}


class AppCategory(Enum):
    STREAMING = [
        'disney_plus',
        'mytv_super',
        'netflix',
        'viu',
        'youtube'
    ]
    REMOTE = [
        'ms_teams',
        'zoom'
    ]

COLNAME_EBM_DAILY_UPLINK_USAGE = "UPLINK_MB"
COLNAME_EBM_DAILY_DOWNLINK_USAGE = "USG_MB"
APP_DATA_USAGE_STATISTICS = [
    "whatsapp",
    "wechat",
    "facetime"
]