n1_path = 'dtap://TenantStorage/oracle_data/overwrite_tables/PRD_BIZ_SUMM_VW.VW_PREPD_POSTPAID_SUBR_N1'
active_5G_home_broadband = 'dtap://TenantStorage/oracle_data/overwrite_tables/PRD_BIZ_SUMM_VW.VW_ACT_5GHBB_SUBR'
bm_table_path = 'dtap://TenantStorage/oracle_data/overwrite_tables/PRD_BIZ_SUMM_VW.VW_SUBR_NOMINATION_HIST'

cnss_raw_path = 'dtap://ext_mapr/c360_data/BP.VW_CNSS_DAILY_SUMM'
cnss_c360_raw_path = 'dtap://TenantStorage/pong/c360_data/daily_append_tables/BP.VW_CNSS_DAILY_SUMM'
cnss_app_output_path = 'dtap://TenantStorage/cnss/output_app/date_id={date_id}'
cnss_category_output_path = 'dtap://TenantStorage/cnss/output_category/date_id={date_id}'

# feature for persona path
s11_output_path = 'dtap://TenantStorage/cnss/cnss_s11/output'

# EBM daily result path
ebm_daily_path = 'dtap://TenantStorage/cnss/ebm/ebm_daily/date_id={}'
ebm_personas_features_path = 'dtap://TenantStorage/cnss/ebm/personas_features'

# Raw data source path
s11_src_path = 'dtap://ext_mapr_hive/CNSS/cnss_s11'
ebm_src_path = 'dtap://ext_mapr_hive/PCG_CDR/trx_date={}/event_id=1'
pfcp_src_path = 'dtap://ext_mapr_hive/DMC_ASDR/DMC_DPI_ASDR'

# Raw data result path
s11_raw_path = 'dtap://TenantStorage/cnss/cnss_s11/raw'
ebm_raw_path = 'dtap://TenantStorage/cnss/ebm/raw'
pfcp_raw_path = 'dtap://TenantStorage/cnss/pfcp/raw'
bp_table_raw_path = 'dtap://TenantStorage/cnss/bp_table/raw'