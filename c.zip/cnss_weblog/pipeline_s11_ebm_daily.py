from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F
from pyspark.sql.functions import col
import argparse
from datetime import datetime, timedelta
from src.cnss_configs import S11_EBM_MAPPING_TABLE, S11_APP_LIST
from src.path import s11_raw_path, ebm_raw_path, ebm_daily_path

S11_ACTIVE_MINUTE_THRESHOLD = 900


def read_cnss_s11(spark: SparkSession, run_date: datetime) -> DataFrame:
    return spark.read.parquet(
        *[
            s11_raw_path + '/' + (run_date - timedelta(days=i)).strftime('%Y%m%d')
            for i in range(1)
        ]
    )


def read_ebm(spark: SparkSession, run_date: datetime) -> DataFrame:
    return spark.read.parquet(
        *[
            ebm_raw_path + '/' + (run_date - timedelta(days=i)).strftime('%Y%m%d')
            for i in range(1)
        ]
    )


def clean_cnss_s11(raw_df: DataFrame):
    return raw_df.withColumn('BYTE_PER_PACKET_DL', F.col('bytes_dl') / F.col('packets_dl'))\
                .withColumn(
                    "SUBR_NUM",
                    F.when(F.col("msisdn").startswith("852"), F.substring("msisdn", 4, 20))
                    .otherwise(F.col("msisdn"))
                )\
                .withColumnRenamed("service_name", "APP_NAME")\
                .filter(col('APP_NAME').isin(S11_APP_LIST))\
                .withColumnRenamed("part_key", "DATE_ID")\
                .filter(
                    (F.col('BYTE_PER_PACKET_DL') >= S11_ACTIVE_MINUTE_THRESHOLD)
                ).groupBy('SUBR_NUM','APP_NAME','imsi','DATE_ID')\
                .agg(
                    F.sum(F.col('bytes_dl')/1000/1000).alias('USG_MB'),
                    F.count('*').alias('DURATION_MINUTES'),
                    F.sum(F.col('bytes_ul')/1000/1000).alias('UPLINK_MB'),
                )


# EBM do not have threshold for active minutes because E&O already filter the active minutes
def clean_ebm(raw_df: DataFrame, yyyymm):
    mapping = [(key, value) for key, value in S11_EBM_MAPPING_TABLE.items()]
    mapping_df = spark.createDataFrame(mapping, schema=["service_id", "APP_NAME"])

    return raw_df.withColumn(
                    "SUBR_NUM",
                    F.when(F.col("msisdn").startswith("852"), F.substring("msisdn", 4, 20))
                    .otherwise(F.col("msisdn"))
                ).withColumn(
                    "DATE_ID",
                    F.date_format(F.from_unixtime(F.col("time").cast("long")+8*3600), "yyyyMMdd")
                ).withColumn(
                    "yyyymmddhhmm",
                    F.date_format(F.from_unixtime(F.col("time").cast("long")+8*3600), "yyyyMMddHHmm")
                )\
                .filter(col('DATE_ID').startswith(yyyymm))\
                .withColumnRenamed("service_dl_bytes", "DL_BYTES")\
                .join(F.broadcast(mapping_df), 'service_id', 'left')\
                .groupBy('SUBR_NUM','APP_NAME','imsi','DATE_ID')\
                .agg(
                    F.sum(F.col('DL_BYTES')/1000/1000).alias('USG_MB'),
                    F.countDistinct('yyyymmddhhmm').alias('ACTIVE_MINUTES'),
                    F.sum(F.col('service_ul_bytes')/1000/1000).alias('UPLINK_MB'),
                )


def make_ebm_daily(spark: SparkSession,run_date: datetime):
    yyyymmdd = run_date.strftime('%Y%m%d')
    yyyymm = run_date.strftime('%Y%m')

    s11 = read_cnss_s11(spark, run_date)
    ebm = read_ebm(spark, run_date)

    s11_cleaned = clean_cnss_s11(s11)
    ebm_cleaned = clean_ebm(ebm, yyyymm)

    s11 = s11_cleaned.withColumn('s11', F.lit(1))
    ebm = ebm_cleaned.withColumn('ebm', F.lit(1))

    s11_ebm = s11.join(ebm, ['SUBR_NUM','APP_NAME','imsi','USG_MB','DATE_ID','UPLINK_MB'], 'outer')\
                    .withColumn('ACTIVE_MINUTES', 
                                F.when(
                                    col('ACTIVE_MINUTES').isNull(), col('DURATION_MINUTES')
                                ).otherwise(col('ACTIVE_MINUTES'))
                    )\
                    .groupBy(['SUBR_NUM','APP_NAME','imsi'])\
                    .agg(
                        F.sum('USG_MB').alias('USG_MB'),
                        F.sum('DURATION_MINUTES').alias('DURATION_MINUTES'),
                        F.sum('ACTIVE_MINUTES').alias('ACTIVE_MINUTES'),
                        F.sum('UPLINK_MB').alias('UPLINK_MB'),
                        F.max('s11').alias('s11'),
                        F.max('ebm').alias('ebm'),
                    )

    s11_ebm\
        .withColumn('is_HBB', F.when(
            (col('SUBR_NUM').startswith('19943')) |
            (col('SUBR_NUM').startswith('19944')) |
            (col('SUBR_NUM').startswith('19945')) |
            (col('SUBR_NUM').startswith('19946')), 1).otherwise(0)
        )\
        .fillna(0)\
        .distinct()\
        .repartitionByRange(100,'SUBR_NUM').write.mode('overwrite').parquet(ebm_daily_path.format(yyyymmdd))

def get_dates_in_month(yyyymm):
    year = int(yyyymm[:4])
    month = int(yyyymm[4:])
    date = datetime(year, month, 1)
    dates = []
    while date.month == month:
        dates.append(date.strftime("%Y%m%d"))
        date += timedelta(days=1)
    return dates


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str, default='', help='yyyymmdd of the date of data files')
    args = parser.parse_args()

    spark = SparkSession.builder.appName("ebm_s11_daily").getOrCreate()
    make_ebm_daily(spark, datetime.strptime(args.run_date, '%Y-%m-%d'))
