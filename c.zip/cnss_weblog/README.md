# EBM

## Daily Job 1 - ebm_raw_daily

- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=ebm_raw_daily)
- **Description:** snapshot of raw data (s11, ebm, pfcp) with only useful columns and app_name
- **Script:** pipeline_raw.py
- **Schedule:** Daily 10:00 a.m.
- **Size:** s11 (13 GB) / ebm (11 GB)/ pfcp (14 GB)
- **Run time:** 60 mins
- **Source:**

`dtap://ext_mapr_hive/CNSS/cnss_s11`

`dtap://ext_mapr_hive/PCG_CDR/trx_date={}/event_id=1`

`dtap://ext_mapr_hive/DMC_ASDR/DMC_DPI_ASDR`

- **Result:**

`dtap://TenantStorage/cnss/cnss_s11/raw`

`dtap://TenantStorage/cnss/ebm/raw`

`dtap://TenantStorage/cnss/pfcp/raw`


## Daily Job 2 - ebm_daily

- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=ebm_daily)
- **Description:** aggregated s11 raw data + ebm raw data
- **Script:** pipeline_s11_ebm_daily.py
- **Schedule:** Daily 12:00 p.m.
- **Size:** 500 MB
- **Run time:** 15 mins
- **Source:**

`dtap://TenantStorage/cnss/cnss_s11/raw`

`dtap://TenantStorage/cnss/ebm/raw`

- **Result:**

`dtap://TenantStorage/cnss/ebm/ebm_daily`


## Daily Job 3 - ebm_for_persona

- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=ebm_for_persona)
- **Description:** generate features data for persona tags
- **Script:** pipeline_cnss_for_persona.py
- **Schedule:** Daily 12:45 p.m.
- **Size:** 500 MB
- **Run time:** 7 mins
- **Source:**

`dtap://TenantStorage/cnss/ebm/ebm_daily`

- **Result:**

`dtap://TenantStorage/cnss/cnss_s11/output`


## Monthly Job 1 - ebm_report_monthly

- **Airflow job:** [here](https://dsecp-gateway.hksmartone.com:10216/tree?dag_id=ebm_report_monthly)
- **Description:** generate monthly netflix & disney+ users report for VAS team (s11 + pfcp)
- **Script:** pipeline_cnss_report.py
- **Schedule:** Monthly 10th 10:00 a.m.
- **Size:** 500 MB
- **Run time:** 7 mins
- **Source:**

`dtap://TenantStorage/cnss/cnss_s11/raw`

`dtap://TenantStorage/cnss/pfcp/raw`

- **Result:**

`dtap://TenantStorage/cnss/adhoc`