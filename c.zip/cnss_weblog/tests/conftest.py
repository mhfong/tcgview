import pytest
from pyspark.sql import SparkSession


# Get one spark session for the whole test session
@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master('local[2]').getOrCreate()

