from cnss_apps.data_usage_statistics import data_usage
from pyspark.sql import SparkSession
from unittest.mock import patch
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, StructField, StructType, FloatType, IntegerType


def test_data_usage(spark: SparkSession):
    n1 = spark.createDataFrame(
            [
                ['11111111', '51616948', 'M', 'Y'],
                ['11111111', '99954241', 'M', 'Y'],
                ['44444444', '45468967', 'M', 'Y'],
                ['55555555', '84651286', 'M', 'N'],
                ['55555555', '97451213', 'M', 'Y'],
                ['66666666', '84561992', 'F', 'Y'],
            ],
            schema=StructType([
                StructField('CUST_NUM', StringType()),
                StructField('SUBR_NUM', StringType()),
                StructField('GENDER', StringType()),
                StructField('D_ACTIVE_SUBR_FLG', StringType())
            ])
        )

    schema = StructType([
        StructField("SUBR_NUM", StringType(), True),
        StructField("APP_NAME", StringType(), True),
        StructField("imsi", StringType(), True),
        StructField("USG_MB", FloatType(), True),
        StructField("DURATION_MINUTES", IntegerType(), True),
        StructField("ACTIVE_MINUTES", IntegerType(), True),
        StructField("UPLINK_MB", FloatType(), True),
        StructField("s11", IntegerType(), True),
        StructField("ebm", IntegerType(), True),
        StructField("is_HBB", IntegerType(), True)
    ])

    # Create the data
    data = [
        ("51616948", "instagram", "45406551616948", 0.123863, 3, 3, 0.015636, 1, 0, 0),
        ("51616948", "instagram", "45406551616948", 0.1, 3, 3, 0.02, 1, 0, 0),
        ("51616948", "facetime", "45406551616948", 0.5, 3, 3, 0.036, 1, 0, 0),
        ("51616948", "wechat", "45406551616948", 0.5, 3, 3, 0.036, 1, 0, 0),
        ("51616948", "wechat", "45406551616948", 0.2, 3, 3, 10.0, 1, 0, 0),
        ("51616948", "others-app", "45406551616948", 0.5, 3, 3, 0.036, 1, 0, 0),
        ("97451213", "instagram", "45406551616945", 393.8190149999998, 0, 405, 169.80127699999997, 0, 1, 0),
        ("97451213", "wechat", "45406551616945", 9.080779, 2, 2, 0.136623, 1, 0, 0),
        ("97451213", "whatsapp", "45406551616945", 3.0099880000000017, 0, 106, 0.8165439999999999, 0, 1, 0),
        ("97451213", "linkedin", "45406551616945", 0.036338, 0, 1, 0.004740999999999, 0, 1, 0)
    ]
    # Create the DataFrame
    df = spark.createDataFrame(data, schema)
    run_date = datetime.strptime("20250201", "%Y%m%d")

    app = data_usage(spark, run_date=run_date, tag="DATA_USAGE_UPLINK_DOWNLINK", ebm = df, n1_table=n1, is_save=False).sort('SUBR_NUM').collect()
    
    assert len(app) == 2
    row = app[0]
    
    assert row['CUST_NUM'] == '11111111'
    assert row['SUBR_NUM'] == '51616948'
    assert row['ALL_CNSS_APPS_TOTAL_DOWNLINK_USAGE_30D'] == 1.9238630011677742
    assert row['ALL_CNSS_APPS_TOTAL_UPLINK_USAGE_30D'] == 10.143635995686054

    assert row['FACETIME_DOWNLINK_USAGE_30D'] == 0.5
    assert row['FACETIME_UPLINK_USAGE_30D'] == 0.035999998450279236
    assert row['WECHAT_DOWNLINK_USAGE_30D'] == 0.7000000029802322
    assert row['WECHAT_UPLINK_USAGE_30D'] == 10.03599999845028
    assert row['WHATSAPP_DOWNLINK_USAGE_30D'] == 0.0
    assert row['WHATSAPP_UPLINK_USAGE_30D'] == 0.0

    row_2 = app[1]
    assert row_2['CUST_NUM'] == '55555555'
    assert row_2['SUBR_NUM'] == '97451213'

    assert row_2['ALL_CNSS_APPS_TOTAL_DOWNLINK_USAGE_30D'] == 405.9461053907871
    assert row_2['ALL_CNSS_APPS_TOTAL_UPLINK_USAGE_30D'] == 170.7591775227338

    assert row_2['FACETIME_DOWNLINK_USAGE_30D'] == 0.0
    assert row_2['FACETIME_UPLINK_USAGE_30D'] == 0.0
    assert row_2['WECHAT_DOWNLINK_USAGE_30D'] == 9.080779075622559
    assert row_2['WECHAT_UPLINK_USAGE_30D'] == 0.13662299513816833
    assert row_2['WHATSAPP_DOWNLINK_USAGE_30D'] == 3.0099880695343018
    assert row_2['WHATSAPP_UPLINK_USAGE_30D'] == 0.8165439963340759
