from datetime import datetime
from dateutil.relativedelta import relativedelta
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import (
    StructType,
    StringType,
    StructField,
)
import itertools
from pyspark.sql.window import Window
from pyspark.sql.dataframe import DataFrame
from pyspark.sql import SparkSession
from itertools import chain
from functools import partial, reduce
from src.C360.libs.oracle_data import OracleData
from src.C360.libs.features_tasks import c360_feature
from src.C360.pipeline.derived_configs.cnss_app_usage_configs import AppCategoryLv1


def _fill_na_count_column_as_zero(df: DataFrame) -> DataFrame:
    fill_values = {
        c: 0
        for c in [_.lower() for _ in df.columns]
        if "_count" in c or "_data_usage" in c or "_duration_days" in c
    }
    df = df.fillna(fill_values)

    return df


def _rename_df_columns(
    sdf: DataFrame,
    prefix: str = "",
    suffix: str = "",
    excluded_list: list = ["CUST_NUM", "SUBR_NUM"],
) -> DataFrame:
    if not (prefix or suffix):
        return sdf

    for c in sdf.columns:
        if c in excluded_list:
            continue
        sdf = sdf.withColumnRenamed(c, prefix + c + suffix)
    return sdf


def _app_categories_groups(spark: SparkSession):
    ### ---------------------- layer 1 ------------------------ ###
    # get list of apps
    apps = set.union(*[c.value for c in AppCategoryLv1])

    # get cat, app generators
    rows = [itertools.product([cat.name], cat.value) for cat in AppCategoryLv1]
    # chain all generators
    rows = chain.from_iterable(rows)

    # create spark dataframe for tagging
    layer1_df = spark.createDataFrame(
        rows,
        schema=StructType(
            [
                StructField("APP_CAT_LV1", StringType()),
                StructField("APP_NAME", StringType()),
            ]
        ),
    )

    app_cat = layer1_df
    # ### ---------------------- layer 2 ------------------------ ###
    # try:
    #     # join cat lv2 if defined
    #     AppCategoryLv2

    #     name_getter = attrgetter("name")
    #     rows = [
    #         itertools.product([cat.name], map(name_getter, cat.value))
    #         for cat in AppCategoryLv2
    #     ]
    #     rows = chain.from_iterable(rows)

    #     # create spark dataframe for tagging
    #     layer2_df = spark.createDataFrame(
    #         rows,
    #         schema=StructType(
    #             [
    #                 StructField("APP_CAT_LV2", StringType()),
    #                 StructField("APP_CAT_LV1", StringType()),
    #             ]
    #         ),
    #     )

    #     ## join all app cat dfs
    #     app_cat = app_cat.join(layer2_df, on=["APP_CAT_LV1"], how="left").distinct()

    # except NameError:
    #     pass

    return app_cat


def clean_cnss_activities(
    spark: SparkSession,
    run_date: datetime,
    sdf_cnss_raw: DataFrame,
    sdf_post_paid_trx: DataFrame,
) -> DataFrame:
    # read VW_BM_LIS_ROAM_COUNT
    this_month = run_date.replace(day=1)

    sdf_cnss_raw = (
        sdf_cnss_raw.withColumnRenamed("MSISDN", "SUBR_NUM")
        .filter(col("USG_MB") > 0.0)
        .filter(F.trim(col("SUBR_NUM")) != "")
        .filter(F.length(col("SUBR_NUM")) == 11)
        .filter(col("SUBR_NUM").startswith("852"))
        .withColumn("SUBR_NUM", F.substring(col("SUBR_NUM"), 4, 8))
        .withColumn(
            "APP_NAME",
            F.when(col("APP_NAME").isNull(), col("SERVICE_NAME")).otherwise(
                col("APP_NAME")
            ),
        )
        .drop("SERVICE_NAME")
    )

    # combine apps into one
    # added on 20230505
    sdf_cnss_raw = sdf_cnss_raw.withColumn(
        "APP_NAME",
        F.when(col("APP_NAME") == "youtube_hd", "youtube")
        .when(col("APP_NAME") == "netflix_video", "netflix")
        .otherwise(col("APP_NAME")),
    )

    # group to prevent multiple records on the same day
    sdf_cnss_raw = sdf_cnss_raw.groupby(["SUBR_NUM", "APP_NAME", "ACCS_DATE"]).agg(
        F.sum(col("USG_MB")).alias("USG_MB")
    )

    # list of customer in this month
    sdf_post_paid_trx_cm = sdf_post_paid_trx.select("CUST_NUM", "SUBR_NUM").filter(
        col("MONTH_ID") == F.lit(this_month.strftime("%Y-%m-%d"))
    )

    # spark df of the app category class
    sdf_app_cat = _app_categories_groups(spark)

    # join all functions
    sdf_cleaned = sdf_cnss_raw.join(
        F.broadcast(sdf_post_paid_trx_cm), on=["SUBR_NUM"], how="inner"
    ).join(F.broadcast(sdf_app_cat), on=["APP_NAME"], how="inner")

    return sdf_cleaned


def _get_features_pivot(
    sdf: DataFrame,
    run_date: datetime,
    pivot_col: str,
    pivot_values: list,
    feature_col_prefix: str,
    exclude_list: list = [],
    cnss_last_n_months: int = 3,
) -> DataFrame:
    ## get feature suffix
    if cnss_last_n_months == 1:
        feature_col_suffix = f"_LM"
    else:
        feature_col_suffix = f"_{cnss_last_n_months}M"

    if cnss_last_n_months < 3:
        start = (
            run_date.replace(day=1) - relativedelta(months=cnss_last_n_months - 1)
        ).strftime("%Y-%m-%d")
        sdf = sdf.filter(col("ACCS_DATE") >= F.lit(start))

    # filter excluded apps
    if exclude_list:
        sdf = sdf.filter(~col(pivot_col).isin(exclude_list))
        pivot_values = list(set(pivot_values) - set(exclude_list))

    def _by_session(sdf: DataFrame):
        window = Window.partitionBy("CUST_NUM", "SUBR_NUM", pivot_col).orderBy(
            "CUST_NUM", "SUBR_NUM", pivot_col, "ACCS_DATE"
        )

        # sum of data usage per session/day
        # number of consecutive days
        _sdf_sessions = (
            sdf.withColumn(
                "days_since_last_hit_date",
                F.datediff(col("ACCS_DATE"), F.lag(col("ACCS_DATE")).over(window)),
            )
            .withColumn(
                "is_session_start",
                F.when(col("days_since_last_hit_date").isNull(), 1)
                .when(col("days_since_last_hit_date") > 1, 1)
                .otherwise(0),
            )
            .withColumn("session_id", F.sum(col("is_session_start")).over(window))
            .groupby(
                "CUST_NUM",
                "SUBR_NUM",
                pivot_col,
                "session_id",
            )
            .agg(
                (
                    F.datediff(F.max(col("ACCS_DATE")), F.min(col("ACCS_DATE"))) + 1
                ).alias("session_duration_days"),
                F.sum(col("USG_MB")).alias("session_data_usage"),
            )
        )

        # category pivoting
        _sdf_sessions = (
            _sdf_sessions.groupby("CUST_NUM", "SUBR_NUM")
            .pivot(pivot_col, values=pivot_values)
            .agg(F.max(col("session_duration_days")))
        )

        return _rename_df_columns(
            _sdf_sessions,
            prefix=feature_col_prefix,
            suffix="_MAX_DURATION_DAYS" + feature_col_suffix,
        )

    def _by_wdwe(sdf: DataFrame):
        # weekend indicator
        _sdf_wdwe = sdf.withColumn(
            "wdwe",
            F.when(F.dayofweek("ACCS_DATE").isin([1, 7]), "weekend").otherwise(
                "weekday"
            ),
        )
        # temp pivot column
        _sdf_wdwe = _sdf_wdwe.withColumn(
            "temp_pivot_col", F.concat_ws("_", col(pivot_col), col("wdwe"))
        )
        # get pivot values for wdwe features
        pivot_values_wdwe = [
            "_".join(pair)
            for pair in itertools.product(pivot_values, ["weekday", "weekend"])
        ]

        # pivoting
        _sdf_wdwe = (
            _sdf_wdwe.groupby("CUST_NUM", "SUBR_NUM")
            .pivot("temp_pivot_col", values=pivot_values_wdwe)
            .agg(
                F.count(col("SUBR_NUM")).alias("DAYS_COUNT" + feature_col_suffix),
                F.round(F.sum(col("USG_MB")), 3).alias(
                    "DATA_USAGE" + feature_col_suffix
                ),
            )
        )

        return _rename_df_columns(_sdf_wdwe, prefix=feature_col_prefix)

    def _general(sdf: DataFrame):
        # weekend indicator
        _sdf = (
            sdf.groupby("CUST_NUM", "SUBR_NUM")
            .pivot(pivot_col, values=pivot_values)
            .agg(
                F.count(col("SUBR_NUM")).alias("DAYS_COUNT" + feature_col_suffix),
                F.round(F.sum(col("USG_MB")), 3).alias(
                    "DATA_USAGE" + feature_col_suffix
                ),
            )
        )

        return _rename_df_columns(_sdf, prefix=feature_col_prefix)

    # list of features
    feature_dfs = [_by_session(sdf), _by_wdwe(sdf), _general(sdf)]

    def _join_func(a, b):
        return a.join(b, on=["CUST_NUM", "SUBR_NUM"], how="outer")

    # join feature dfs into one
    all_features = reduce(_join_func, feature_dfs)
    all_features = _fill_na_count_column_as_zero(all_features)

    # col name to upper
    for c in all_features.columns:
        all_features = all_features.withColumnRenamed(c, c.upper())

    return all_features
    # return _sdf_feature_session, _sdf_feature_wdwe


def _get_features_distinct_count(
    sdf: DataFrame,
    run_date: datetime,
    pivot_col: str,
    pivot_values: list,
    count_col: str,
    feature_col_prefix: str,
    pivot_exclude_list: list = [],
    count_exclude_list: list = [],
    cnss_last_n_months: int = 3,
):
    ## get feature suffix
    if cnss_last_n_months == 1:
        feature_col_suffix = f"_LM"
    else:
        feature_col_suffix = f"_{cnss_last_n_months}M"

    if cnss_last_n_months < 3:
        start = (
            run_date.replace(day=1) - relativedelta(months=cnss_last_n_months - 1)
        ).strftime("%Y-%m-%d")
        sdf = sdf.filter(col("ACCS_DATE") >= F.lit(start))

    # filter pivot values
    if pivot_exclude_list:
        sdf = sdf.filter(~col(pivot_col).isin(pivot_exclude_list))
        pivot_values = list(set(pivot_values) - set(pivot_exclude_list))

    # filter count values
    if count_exclude_list:
        sdf = sdf.filter(~col(count_col).isin(count_exclude_list))

    # count distinct
    _sdf_dc = (
        sdf.groupby("CUST_NUM", "SUBR_NUM")
        .pivot(pivot_col, values=pivot_values)
        .agg(
            F.countDistinct(col(count_col)),
        )
    )

    # col name to upper
    for c in _sdf_dc.columns:
        _sdf_dc = _sdf_dc.withColumnRenamed(c, c.upper())

    return _fill_na_count_column_as_zero(
        _rename_df_columns(
            _sdf_dc,
            prefix=feature_col_prefix,
            suffix="_DISTINCT_COUNT" + feature_col_suffix,
        )
    )


def calculate_features(
    spark: SparkSession,
    # injected from config.yaml:
    target_month: str = "1990-01",
) -> DataFrame:
    """

    Args:
        spark:
        target_month:
        raw_input_dir:
        cleansed_dir:
        **kwargs:

    Returns:

    """

    run_date = datetime.strptime(target_month, "%Y-%m")

    def _paths_for_partition_in_days(
        path_format: str, run_date: datetime, prev_n_months: int = 1
    ) -> list:
        # last day
        last_day = run_date + relativedelta(months=1) + relativedelta(days=-1)

        # get number of days in total for prev_n_months
        total_days = (
            last_day - (run_date + relativedelta(months=-(prev_n_months - 1)))
        ).days + 1

        paths = [
            (last_day + relativedelta(days=-i)).strftime(path_format)
            for i in range(total_days)
        ]
        return paths

    # raw data available date
    raw_data_cutoff_date = datetime.strptime("2022-12", "%Y-%m")
    # diff in months, will read data depends on the difference in months
    month_diff = (
        (run_date.year - raw_data_cutoff_date.year) * 12
        + (run_date.month - raw_data_cutoff_date.month)
        + 1
    )

    # list of unfiltered feature months list
    feature_month_cutoff_list = [1, 3, 6, 9, 12]
    # filter with month diff
    feature_month_cutoff_list = [
        i for i in feature_month_cutoff_list if i <= month_diff
    ]

    ## --------------------------- Read Data - CNSS -------------------------- ##
    paths = _paths_for_partition_in_days(
        OracleData.VW_CNSS_DAILY_SUMM.raw() + "/ACCS_DATE=%Y-%m-%d",
        run_date,
        prev_n_months=feature_month_cutoff_list[-1],
    )

    sdf_cnss_raw = spark.read.option(
        "basePath", OracleData.VW_CNSS_DAILY_SUMM.raw()
    ).parquet(*paths)

    ## --------------------------- Read Data - N1 --------------------------- ##
    sdf_post_paid_trx_cm = spark.read.parquet(
        OracleData.VW_SHK_POSTPAID_MASTER_SUMM.cleansed(target_month)
    )

    ## -------------------------- Clean CNSS Data -------------------------- ##
    sdf_cnss = clean_cnss_activities(
        spark,
        run_date,
        sdf_cnss_raw,
        sdf_post_paid_trx_cm,
    )

    ## --------------------------- Get Features --------------------------- ##
    # app features
    get_features_pivot_app = partial(
        _get_features_pivot,
        sdf=sdf_cnss,
        run_date=run_date,
        pivot_col="APP_NAME",
        pivot_values=list(
            reduce(lambda a, b: a.union(b), [a.value for a in AppCategoryLv1])
        ),
        feature_col_prefix="CNSS_APP_",
    )
    # category features
    get_features_pivot_category = partial(
        _get_features_pivot,
        sdf=sdf_cnss,
        run_date=run_date,
        pivot_col="APP_CAT_LV1",
        pivot_values=[a.name for a in AppCategoryLv1],
        feature_col_prefix="CNSS_CATEGORY_",
    )
    # app distinct count
    get_features_distinct_count_app = partial(
        _get_features_distinct_count,
        sdf=sdf_cnss,
        run_date=run_date,
        pivot_col="APP_CAT_LV1",
        pivot_values=[a.name for a in AppCategoryLv1],
        count_col="APP_NAME",
        feature_col_prefix="CNSS_CATEGORY_",
    )

    def _get_features_list_by_month(month):
        cnss_features = [
            get_features_pivot_app(cnss_last_n_months=month),
            get_features_pivot_category(cnss_last_n_months=month),
            get_features_distinct_count_app(cnss_last_n_months=month),
        ]
        return cnss_features

    # get list of all features
    all_cnss_features = reduce(
        lambda x, y: x + y,
        [_get_features_list_by_month(m) for m in feature_month_cutoff_list],
    )

    def _join_func(a, b):
        return a.join(b, on=["CUST_NUM", "SUBR_NUM"], how="outer")

    features = reduce(_join_func, all_cnss_features).withColumn(
        "MONTH_ID", F.to_date(F.lit(run_date.replace(day=1).strftime("%Y-%m-%d")))
    )
    features = _fill_na_count_column_as_zero(features)
    return features


@c360_feature
def cnss_app_usage(spark: SparkSession, target_month: str = "1990-01"):
    """
    Calculate cnss app metrics:
        - _DAYS_COUNT
        - _DATA_USAGE (MB)
        - _MAX_DURATION_DAYS

    Calculate cnss category metrics:
        - _DAYS_COUNT
        - _DATA_USAGE (MB)
        - _MAX_DURATION_DAYS
        - APP_DISTINCT_COUNT

    Source Table:
        Oracle:
            PRD_BIZ_SUMM_VW.VW_SHK_POSTPAID_MASTER_SUMM
        CNSS Oracle:
            BP.VW_CNSS_DAILY_SUMM

    Feature Logic:

    Feature Category:
        - Weblog

    Feature Sub-category:
        - Weblog - CNSS

    Feature Columns:
        - IDENTIFIER_KEY: ['SUBR_NUM', 'CUST_NUM']
        - MONTH_ID
        - CNSS_APP_CALL_OF_DUTY_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using WECHAT
        - CNSS_APP_KKBOX_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using KKBOX
        - CNSS_APP_TMALL_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using TMALL
        - CNSS_APP_BATTLENET_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using DISCORD
        - CNSS_APP_BILIBILI_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using WHATSAPP
        - CNSS_APP_EBAY_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using PUBG
        - CNSS_APP_ROBLOX_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using TAOTE
        - CNSS_APP_IKEA_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using AFREECA
        - CNSS_APP_ALIPAY_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using LINE
        - CNSS_APP_QQVIDEO_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using WECHAT
        - CNSS_APP_KKBOX_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using KKBOX
        - CNSS_APP_TMALL_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using TMALL
        - CNSS_APP_BATTLENET_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using DISCORD
        - CNSS_APP_BILIBILI_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using WHATSAPP
        - CNSS_APP_EBAY_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using PUBG
        - CNSS_APP_ROBLOX_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using TAOTE
        - CNSS_APP_IKEA_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using VIU
        - CNSS_APP_VIU_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using AFREECA
        - CNSS_APP_ALIPAY_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using LINE
        - CNSS_APP_LINE_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using LINE
        - CNSS_APP_QQVIDEO_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_DAYS_COUNT_LM: Number of days in the last 1 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_DAYS_COUNT_LM: Number of days in the last 1 month(s) using WECHAT
        - CNSS_APP_WECHAT_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using WECHAT
        - CNSS_APP_KKBOX_DAYS_COUNT_LM: Number of days in the last 1 month(s) using KKBOX
        - CNSS_APP_KKBOX_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using KKBOX
        - CNSS_APP_TMALL_DAYS_COUNT_LM: Number of days in the last 1 month(s) using TMALL
        - CNSS_APP_TMALL_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using TMALL
        - CNSS_APP_BATTLENET_DAYS_COUNT_LM: Number of days in the last 1 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_DAYS_COUNT_LM: Number of days in the last 1 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_DAYS_COUNT_LM: Number of days in the last 1 month(s) using DISCORD
        - CNSS_APP_DISCORD_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using DISCORD
        - CNSS_APP_BILIBILI_DAYS_COUNT_LM: Number of days in the last 1 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_DAYS_COUNT_LM: Number of days in the last 1 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_DAYS_COUNT_LM: Number of days in the last 1 month(s) using YOUKU
        - CNSS_APP_YOUKU_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_DAYS_COUNT_LM: Number of days in the last 1 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using WHATSAPP
        - CNSS_APP_EBAY_DAYS_COUNT_LM: Number of days in the last 1 month(s) using EBAY
        - CNSS_APP_EBAY_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_DAYS_COUNT_LM: Number of days in the last 1 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_DAYS_COUNT_LM: Number of days in the last 1 month(s) using PUBG
        - CNSS_APP_PUBG_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using PUBG
        - CNSS_APP_ROBLOX_DAYS_COUNT_LM: Number of days in the last 1 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_DAYS_COUNT_LM: Number of days in the last 1 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_DAYS_COUNT_LM: Number of days in the last 1 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_DAYS_COUNT_LM: Number of days in the last 1 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_DAYS_COUNT_LM: Number of days in the last 1 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_DAYS_COUNT_LM: Number of days in the last 1 month(s) using TAOTE
        - CNSS_APP_TAOTE_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using TAOTE
        - CNSS_APP_IKEA_DAYS_COUNT_LM: Number of days in the last 1 month(s) using IKEA
        - CNSS_APP_IKEA_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_DAYS_COUNT_LM: Number of days in the last 1 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_DAYS_COUNT_LM: Number of days in the last 1 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_DAYS_COUNT_LM: Number of days in the last 1 month(s) using VIU
        - CNSS_APP_VIU_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_DAYS_COUNT_LM: Number of days in the last 1 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_DAYS_COUNT_LM: Number of days in the last 1 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_DAYS_COUNT_LM: Number of days in the last 1 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_DAYS_COUNT_LM: Number of days in the last 1 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_DAYS_COUNT_LM: Number of days in the last 1 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_DAYS_COUNT_LM: Number of days in the last 1 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_DAYS_COUNT_LM: Number of days in the last 1 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_DAYS_COUNT_LM: Number of days in the last 1 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_DAYS_COUNT_LM: Number of days in the last 1 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_DAYS_COUNT_LM: Number of days in the last 1 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_DAYS_COUNT_LM: Number of days in the last 1 month(s) using AMAZON
        - CNSS_APP_AMAZON_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_DAYS_COUNT_LM: Number of days in the last 1 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_DAYS_COUNT_LM: Number of days in the last 1 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_DAYS_COUNT_LM: Number of days in the last 1 month(s) using AFREECA
        - CNSS_APP_AFREECA_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using AFREECA
        - CNSS_APP_ALIPAY_DAYS_COUNT_LM: Number of days in the last 1 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DAYS_COUNT_LM: Number of days in the last 1 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_DAYS_COUNT_LM: Number of days in the last 1 month(s) using LINE
        - CNSS_APP_LINE_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using LINE
        - CNSS_APP_QQVIDEO_DAYS_COUNT_LM: Number of days in the last 1 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_DAYS_COUNT_LM: Number of days in the last 1 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_DAYS_COUNT_LM: Number of days in the last 1 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_DAYS_COUNT_LM: Number of days in the last 1 month(s) using TWITTER
        - CNSS_APP_TWITTER_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_DAYS_COUNT_LM: Number of days in the last 1 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_DAYS_COUNT_LM: Number of days in the last 1 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_DAYS_COUNT_LM: Number of days in the last 1 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_DAYS_COUNT_LM: Number of days in the last 1 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_DAYS_COUNT_LM: Number of days in the last 1 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_DAYS_COUNT_LM: Number of days in the last 1 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_DAYS_COUNT_LM: Number of days in the last 1 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_DAYS_COUNT_LM: Number of days in the last 1 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_DAYS_COUNT_LM: Number of days in the last 1 month(s) using STEAM
        - CNSS_APP_STEAM_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_DAYS_COUNT_LM: Number of days in the last 1 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using INSTAGRAM
        - CNSS_CATEGORY_STREAMING_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_MAX_DURATION_DAYS_LM: Max number of consecutive days in the last 1 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DAYS_COUNT_LM: Number of weekdays in the last 1 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DATA_USAGE_LM: Data Usage in MB on weekdays in the last 1 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DAYS_COUNT_LM: Number of weekends in the last 1 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DATA_USAGE_LM: Data Usage in MB on weekends in the last 1 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_DAYS_COUNT_LM: Number of days in the last 1 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_DATA_USAGE_LM: Data Usage in MB in the last 1 month(s) using apps in category RETAIL
        - CNSS_APP_CALL_OF_DUTY_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using WECHAT
        - CNSS_APP_KKBOX_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using KKBOX
        - CNSS_APP_TMALL_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using TMALL
        - CNSS_APP_BATTLENET_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using DISCORD
        - CNSS_APP_BILIBILI_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using WHATSAPP
        - CNSS_APP_EBAY_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using PUBG
        - CNSS_APP_ROBLOX_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using TAOTE
        - CNSS_APP_IKEA_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using AFREECA
        - CNSS_APP_ALIPAY_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using LINE
        - CNSS_APP_QQVIDEO_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using WECHAT
        - CNSS_APP_KKBOX_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using KKBOX
        - CNSS_APP_TMALL_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using TMALL
        - CNSS_APP_BATTLENET_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using DISCORD
        - CNSS_APP_BILIBILI_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using WHATSAPP
        - CNSS_APP_EBAY_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using PUBG
        - CNSS_APP_ROBLOX_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using TAOTE
        - CNSS_APP_IKEA_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using VIU
        - CNSS_APP_VIU_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using AFREECA
        - CNSS_APP_ALIPAY_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using LINE
        - CNSS_APP_LINE_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using LINE
        - CNSS_APP_QQVIDEO_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_DAYS_COUNT_3M: Number of days in the last 3 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_DAYS_COUNT_3M: Number of days in the last 3 month(s) using WECHAT
        - CNSS_APP_WECHAT_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using WECHAT
        - CNSS_APP_KKBOX_DAYS_COUNT_3M: Number of days in the last 3 month(s) using KKBOX
        - CNSS_APP_KKBOX_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using KKBOX
        - CNSS_APP_TMALL_DAYS_COUNT_3M: Number of days in the last 3 month(s) using TMALL
        - CNSS_APP_TMALL_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using TMALL
        - CNSS_APP_BATTLENET_DAYS_COUNT_3M: Number of days in the last 3 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_DAYS_COUNT_3M: Number of days in the last 3 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_DAYS_COUNT_3M: Number of days in the last 3 month(s) using DISCORD
        - CNSS_APP_DISCORD_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using DISCORD
        - CNSS_APP_BILIBILI_DAYS_COUNT_3M: Number of days in the last 3 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_DAYS_COUNT_3M: Number of days in the last 3 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_DAYS_COUNT_3M: Number of days in the last 3 month(s) using YOUKU
        - CNSS_APP_YOUKU_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_DAYS_COUNT_3M: Number of days in the last 3 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using WHATSAPP
        - CNSS_APP_EBAY_DAYS_COUNT_3M: Number of days in the last 3 month(s) using EBAY
        - CNSS_APP_EBAY_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_DAYS_COUNT_3M: Number of days in the last 3 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_DAYS_COUNT_3M: Number of days in the last 3 month(s) using PUBG
        - CNSS_APP_PUBG_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using PUBG
        - CNSS_APP_ROBLOX_DAYS_COUNT_3M: Number of days in the last 3 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_DAYS_COUNT_3M: Number of days in the last 3 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_DAYS_COUNT_3M: Number of days in the last 3 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_DAYS_COUNT_3M: Number of days in the last 3 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_DAYS_COUNT_3M: Number of days in the last 3 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_DAYS_COUNT_3M: Number of days in the last 3 month(s) using TAOTE
        - CNSS_APP_TAOTE_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using TAOTE
        - CNSS_APP_IKEA_DAYS_COUNT_3M: Number of days in the last 3 month(s) using IKEA
        - CNSS_APP_IKEA_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_DAYS_COUNT_3M: Number of days in the last 3 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_DAYS_COUNT_3M: Number of days in the last 3 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_DAYS_COUNT_3M: Number of days in the last 3 month(s) using VIU
        - CNSS_APP_VIU_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_DAYS_COUNT_3M: Number of days in the last 3 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_DAYS_COUNT_3M: Number of days in the last 3 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_DAYS_COUNT_3M: Number of days in the last 3 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_DAYS_COUNT_3M: Number of days in the last 3 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_DAYS_COUNT_3M: Number of days in the last 3 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_DAYS_COUNT_3M: Number of days in the last 3 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_DAYS_COUNT_3M: Number of days in the last 3 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_DAYS_COUNT_3M: Number of days in the last 3 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_DAYS_COUNT_3M: Number of days in the last 3 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_DAYS_COUNT_3M: Number of days in the last 3 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_DAYS_COUNT_3M: Number of days in the last 3 month(s) using AMAZON
        - CNSS_APP_AMAZON_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_DAYS_COUNT_3M: Number of days in the last 3 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_DAYS_COUNT_3M: Number of days in the last 3 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_DAYS_COUNT_3M: Number of days in the last 3 month(s) using AFREECA
        - CNSS_APP_AFREECA_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using AFREECA
        - CNSS_APP_ALIPAY_DAYS_COUNT_3M: Number of days in the last 3 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DAYS_COUNT_3M: Number of days in the last 3 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_DAYS_COUNT_3M: Number of days in the last 3 month(s) using LINE
        - CNSS_APP_LINE_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using LINE
        - CNSS_APP_QQVIDEO_DAYS_COUNT_3M: Number of days in the last 3 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_DAYS_COUNT_3M: Number of days in the last 3 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_DAYS_COUNT_3M: Number of days in the last 3 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_DAYS_COUNT_3M: Number of days in the last 3 month(s) using TWITTER
        - CNSS_APP_TWITTER_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_DAYS_COUNT_3M: Number of days in the last 3 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_DAYS_COUNT_3M: Number of days in the last 3 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_DAYS_COUNT_3M: Number of days in the last 3 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_DAYS_COUNT_3M: Number of days in the last 3 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_DAYS_COUNT_3M: Number of days in the last 3 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_DAYS_COUNT_3M: Number of days in the last 3 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_DAYS_COUNT_3M: Number of days in the last 3 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_DAYS_COUNT_3M: Number of days in the last 3 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_DAYS_COUNT_3M: Number of days in the last 3 month(s) using STEAM
        - CNSS_APP_STEAM_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_DAYS_COUNT_3M: Number of days in the last 3 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using INSTAGRAM
        - CNSS_CATEGORY_STREAMING_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_MAX_DURATION_DAYS_3M: Max number of consecutive days in the last 3 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DAYS_COUNT_3M: Number of weekdays in the last 3 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DATA_USAGE_3M: Data Usage in MB on weekdays in the last 3 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DAYS_COUNT_3M: Number of weekends in the last 3 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DATA_USAGE_3M: Data Usage in MB on weekends in the last 3 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_DAYS_COUNT_3M: Number of days in the last 3 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_DATA_USAGE_3M: Data Usage in MB in the last 3 month(s) using apps in category RETAIL
        - CNSS_APP_CALL_OF_DUTY_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using WECHAT
        - CNSS_APP_KKBOX_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using KKBOX
        - CNSS_APP_TMALL_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using TMALL
        - CNSS_APP_BATTLENET_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using DISCORD
        - CNSS_APP_BILIBILI_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using WHATSAPP
        - CNSS_APP_EBAY_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using PUBG
        - CNSS_APP_ROBLOX_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using TAOTE
        - CNSS_APP_IKEA_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using AFREECA
        - CNSS_APP_ALIPAY_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using LINE
        - CNSS_APP_QQVIDEO_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using WECHAT
        - CNSS_APP_KKBOX_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using KKBOX
        - CNSS_APP_TMALL_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using TMALL
        - CNSS_APP_BATTLENET_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using DISCORD
        - CNSS_APP_BILIBILI_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using WHATSAPP
        - CNSS_APP_EBAY_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using PUBG
        - CNSS_APP_ROBLOX_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using TAOTE
        - CNSS_APP_IKEA_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using VIU
        - CNSS_APP_VIU_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using AFREECA
        - CNSS_APP_ALIPAY_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using LINE
        - CNSS_APP_LINE_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using LINE
        - CNSS_APP_QQVIDEO_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_DAYS_COUNT_6M: Number of days in the last 6 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_DAYS_COUNT_6M: Number of days in the last 6 month(s) using WECHAT
        - CNSS_APP_WECHAT_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using WECHAT
        - CNSS_APP_KKBOX_DAYS_COUNT_6M: Number of days in the last 6 month(s) using KKBOX
        - CNSS_APP_KKBOX_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using KKBOX
        - CNSS_APP_TMALL_DAYS_COUNT_6M: Number of days in the last 6 month(s) using TMALL
        - CNSS_APP_TMALL_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using TMALL
        - CNSS_APP_BATTLENET_DAYS_COUNT_6M: Number of days in the last 6 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_DAYS_COUNT_6M: Number of days in the last 6 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_DAYS_COUNT_6M: Number of days in the last 6 month(s) using DISCORD
        - CNSS_APP_DISCORD_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using DISCORD
        - CNSS_APP_BILIBILI_DAYS_COUNT_6M: Number of days in the last 6 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_DAYS_COUNT_6M: Number of days in the last 6 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_DAYS_COUNT_6M: Number of days in the last 6 month(s) using YOUKU
        - CNSS_APP_YOUKU_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_DAYS_COUNT_6M: Number of days in the last 6 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using WHATSAPP
        - CNSS_APP_EBAY_DAYS_COUNT_6M: Number of days in the last 6 month(s) using EBAY
        - CNSS_APP_EBAY_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_DAYS_COUNT_6M: Number of days in the last 6 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_DAYS_COUNT_6M: Number of days in the last 6 month(s) using PUBG
        - CNSS_APP_PUBG_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using PUBG
        - CNSS_APP_ROBLOX_DAYS_COUNT_6M: Number of days in the last 6 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_DAYS_COUNT_6M: Number of days in the last 6 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_DAYS_COUNT_6M: Number of days in the last 6 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_DAYS_COUNT_6M: Number of days in the last 6 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_DAYS_COUNT_6M: Number of days in the last 6 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_DAYS_COUNT_6M: Number of days in the last 6 month(s) using TAOTE
        - CNSS_APP_TAOTE_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using TAOTE
        - CNSS_APP_IKEA_DAYS_COUNT_6M: Number of days in the last 6 month(s) using IKEA
        - CNSS_APP_IKEA_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_DAYS_COUNT_6M: Number of days in the last 6 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_DAYS_COUNT_6M: Number of days in the last 6 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_DAYS_COUNT_6M: Number of days in the last 6 month(s) using VIU
        - CNSS_APP_VIU_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_DAYS_COUNT_6M: Number of days in the last 6 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_DAYS_COUNT_6M: Number of days in the last 6 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_DAYS_COUNT_6M: Number of days in the last 6 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_DAYS_COUNT_6M: Number of days in the last 6 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_DAYS_COUNT_6M: Number of days in the last 6 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_DAYS_COUNT_6M: Number of days in the last 6 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_DAYS_COUNT_6M: Number of days in the last 6 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_DAYS_COUNT_6M: Number of days in the last 6 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_DAYS_COUNT_6M: Number of days in the last 6 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_DAYS_COUNT_6M: Number of days in the last 6 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_DAYS_COUNT_6M: Number of days in the last 6 month(s) using AMAZON
        - CNSS_APP_AMAZON_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_DAYS_COUNT_6M: Number of days in the last 6 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_DAYS_COUNT_6M: Number of days in the last 6 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_DAYS_COUNT_6M: Number of days in the last 6 month(s) using AFREECA
        - CNSS_APP_AFREECA_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using AFREECA
        - CNSS_APP_ALIPAY_DAYS_COUNT_6M: Number of days in the last 6 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DAYS_COUNT_6M: Number of days in the last 6 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_DAYS_COUNT_6M: Number of days in the last 6 month(s) using LINE
        - CNSS_APP_LINE_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using LINE
        - CNSS_APP_QQVIDEO_DAYS_COUNT_6M: Number of days in the last 6 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_DAYS_COUNT_6M: Number of days in the last 6 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_DAYS_COUNT_6M: Number of days in the last 6 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_DAYS_COUNT_6M: Number of days in the last 6 month(s) using TWITTER
        - CNSS_APP_TWITTER_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_DAYS_COUNT_6M: Number of days in the last 6 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_DAYS_COUNT_6M: Number of days in the last 6 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_DAYS_COUNT_6M: Number of days in the last 6 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_DAYS_COUNT_6M: Number of days in the last 6 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_DAYS_COUNT_6M: Number of days in the last 6 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_DAYS_COUNT_6M: Number of days in the last 6 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_DAYS_COUNT_6M: Number of days in the last 6 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_DAYS_COUNT_6M: Number of days in the last 6 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_DAYS_COUNT_6M: Number of days in the last 6 month(s) using STEAM
        - CNSS_APP_STEAM_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_DAYS_COUNT_6M: Number of days in the last 6 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using INSTAGRAM
        - CNSS_CATEGORY_STREAMING_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_MAX_DURATION_DAYS_6M: Max number of consecutive days in the last 6 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DAYS_COUNT_6M: Number of weekdays in the last 6 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DATA_USAGE_6M: Data Usage in MB on weekdays in the last 6 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DAYS_COUNT_6M: Number of weekends in the last 6 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DATA_USAGE_6M: Data Usage in MB on weekends in the last 6 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_DAYS_COUNT_6M: Number of days in the last 6 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_DATA_USAGE_6M: Data Usage in MB in the last 6 month(s) using apps in category RETAIL
        - CNSS_APP_CALL_OF_DUTY_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using WECHAT
        - CNSS_APP_KKBOX_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using KKBOX
        - CNSS_APP_TMALL_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using TMALL
        - CNSS_APP_BATTLENET_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using DISCORD
        - CNSS_APP_BILIBILI_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using WHATSAPP
        - CNSS_APP_EBAY_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using PUBG
        - CNSS_APP_ROBLOX_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using TAOTE
        - CNSS_APP_IKEA_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using AFREECA
        - CNSS_APP_ALIPAY_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using LINE
        - CNSS_APP_QQVIDEO_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using WECHAT
        - CNSS_APP_KKBOX_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using KKBOX
        - CNSS_APP_TMALL_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using TMALL
        - CNSS_APP_BATTLENET_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using DISCORD
        - CNSS_APP_BILIBILI_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using WHATSAPP
        - CNSS_APP_EBAY_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using PUBG
        - CNSS_APP_ROBLOX_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using TAOTE
        - CNSS_APP_IKEA_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using VIU
        - CNSS_APP_VIU_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using AFREECA
        - CNSS_APP_ALIPAY_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using LINE
        - CNSS_APP_LINE_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using LINE
        - CNSS_APP_QQVIDEO_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_DAYS_COUNT_9M: Number of days in the last 9 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_DAYS_COUNT_9M: Number of days in the last 9 month(s) using WECHAT
        - CNSS_APP_WECHAT_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using WECHAT
        - CNSS_APP_KKBOX_DAYS_COUNT_9M: Number of days in the last 9 month(s) using KKBOX
        - CNSS_APP_KKBOX_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using KKBOX
        - CNSS_APP_TMALL_DAYS_COUNT_9M: Number of days in the last 9 month(s) using TMALL
        - CNSS_APP_TMALL_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using TMALL
        - CNSS_APP_BATTLENET_DAYS_COUNT_9M: Number of days in the last 9 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_DAYS_COUNT_9M: Number of days in the last 9 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_DAYS_COUNT_9M: Number of days in the last 9 month(s) using DISCORD
        - CNSS_APP_DISCORD_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using DISCORD
        - CNSS_APP_BILIBILI_DAYS_COUNT_9M: Number of days in the last 9 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_DAYS_COUNT_9M: Number of days in the last 9 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_DAYS_COUNT_9M: Number of days in the last 9 month(s) using YOUKU
        - CNSS_APP_YOUKU_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_DAYS_COUNT_9M: Number of days in the last 9 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using WHATSAPP
        - CNSS_APP_EBAY_DAYS_COUNT_9M: Number of days in the last 9 month(s) using EBAY
        - CNSS_APP_EBAY_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_DAYS_COUNT_9M: Number of days in the last 9 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_DAYS_COUNT_9M: Number of days in the last 9 month(s) using PUBG
        - CNSS_APP_PUBG_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using PUBG
        - CNSS_APP_ROBLOX_DAYS_COUNT_9M: Number of days in the last 9 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_DAYS_COUNT_9M: Number of days in the last 9 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_DAYS_COUNT_9M: Number of days in the last 9 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_DAYS_COUNT_9M: Number of days in the last 9 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_DAYS_COUNT_9M: Number of days in the last 9 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_DAYS_COUNT_9M: Number of days in the last 9 month(s) using TAOTE
        - CNSS_APP_TAOTE_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using TAOTE
        - CNSS_APP_IKEA_DAYS_COUNT_9M: Number of days in the last 9 month(s) using IKEA
        - CNSS_APP_IKEA_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_DAYS_COUNT_9M: Number of days in the last 9 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_DAYS_COUNT_9M: Number of days in the last 9 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_DAYS_COUNT_9M: Number of days in the last 9 month(s) using VIU
        - CNSS_APP_VIU_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_DAYS_COUNT_9M: Number of days in the last 9 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_DAYS_COUNT_9M: Number of days in the last 9 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_DAYS_COUNT_9M: Number of days in the last 9 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_DAYS_COUNT_9M: Number of days in the last 9 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_DAYS_COUNT_9M: Number of days in the last 9 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_DAYS_COUNT_9M: Number of days in the last 9 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_DAYS_COUNT_9M: Number of days in the last 9 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_DAYS_COUNT_9M: Number of days in the last 9 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_DAYS_COUNT_9M: Number of days in the last 9 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_DAYS_COUNT_9M: Number of days in the last 9 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_DAYS_COUNT_9M: Number of days in the last 9 month(s) using AMAZON
        - CNSS_APP_AMAZON_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_DAYS_COUNT_9M: Number of days in the last 9 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_DAYS_COUNT_9M: Number of days in the last 9 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_DAYS_COUNT_9M: Number of days in the last 9 month(s) using AFREECA
        - CNSS_APP_AFREECA_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using AFREECA
        - CNSS_APP_ALIPAY_DAYS_COUNT_9M: Number of days in the last 9 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DAYS_COUNT_9M: Number of days in the last 9 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_DAYS_COUNT_9M: Number of days in the last 9 month(s) using LINE
        - CNSS_APP_LINE_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using LINE
        - CNSS_APP_QQVIDEO_DAYS_COUNT_9M: Number of days in the last 9 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_DAYS_COUNT_9M: Number of days in the last 9 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_DAYS_COUNT_9M: Number of days in the last 9 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_DAYS_COUNT_9M: Number of days in the last 9 month(s) using TWITTER
        - CNSS_APP_TWITTER_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_DAYS_COUNT_9M: Number of days in the last 9 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_DAYS_COUNT_9M: Number of days in the last 9 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_DAYS_COUNT_9M: Number of days in the last 9 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_DAYS_COUNT_9M: Number of days in the last 9 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_DAYS_COUNT_9M: Number of days in the last 9 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_DAYS_COUNT_9M: Number of days in the last 9 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_DAYS_COUNT_9M: Number of days in the last 9 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_DAYS_COUNT_9M: Number of days in the last 9 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_DAYS_COUNT_9M: Number of days in the last 9 month(s) using STEAM
        - CNSS_APP_STEAM_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_DAYS_COUNT_9M: Number of days in the last 9 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using INSTAGRAM
        - CNSS_CATEGORY_STREAMING_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_MAX_DURATION_DAYS_9M: Max number of consecutive days in the last 9 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DAYS_COUNT_9M: Number of weekdays in the last 9 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DATA_USAGE_9M: Data Usage in MB on weekdays in the last 9 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DAYS_COUNT_9M: Number of weekends in the last 9 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DATA_USAGE_9M: Data Usage in MB on weekends in the last 9 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_DAYS_COUNT_9M: Number of days in the last 9 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_DATA_USAGE_9M: Data Usage in MB in the last 9 month(s) using apps in category RETAIL
        - CNSS_APP_CALL_OF_DUTY_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using WECHAT
        - CNSS_APP_KKBOX_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using KKBOX
        - CNSS_APP_TMALL_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using TMALL
        - CNSS_APP_BATTLENET_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using DISCORD
        - CNSS_APP_BILIBILI_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using WHATSAPP
        - CNSS_APP_EBAY_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using PUBG
        - CNSS_APP_ROBLOX_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using TAOTE
        - CNSS_APP_IKEA_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using AFREECA
        - CNSS_APP_ALIPAY_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using LINE
        - CNSS_APP_QQVIDEO_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using WECHAT
        - CNSS_APP_WECHAT_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using WECHAT
        - CNSS_APP_KKBOX_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using KKBOX
        - CNSS_APP_KKBOX_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using KKBOX
        - CNSS_APP_TMALL_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using TMALL
        - CNSS_APP_TMALL_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using TMALL
        - CNSS_APP_BATTLENET_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using DISCORD
        - CNSS_APP_DISCORD_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using DISCORD
        - CNSS_APP_BILIBILI_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using YOUKU
        - CNSS_APP_YOUKU_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using WHATSAPP
        - CNSS_APP_EBAY_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using EBAY
        - CNSS_APP_EBAY_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using PUBG
        - CNSS_APP_PUBG_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using PUBG
        - CNSS_APP_ROBLOX_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using TAOTE
        - CNSS_APP_TAOTE_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using TAOTE
        - CNSS_APP_IKEA_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using IKEA
        - CNSS_APP_IKEA_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using VIU
        - CNSS_APP_VIU_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using VIU
        - CNSS_APP_VIU_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using AMAZON
        - CNSS_APP_AMAZON_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using AFREECA
        - CNSS_APP_AFREECA_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using AFREECA
        - CNSS_APP_ALIPAY_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using LINE
        - CNSS_APP_LINE_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using LINE
        - CNSS_APP_LINE_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using LINE
        - CNSS_APP_QQVIDEO_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using TWITTER
        - CNSS_APP_TWITTER_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using STEAM
        - CNSS_APP_STEAM_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using INSTAGRAM
        - CNSS_APP_CALL_OF_DUTY_DAYS_COUNT_12M: Number of days in the last 12 month(s) using CALL_OF_DUTY
        - CNSS_APP_CALL_OF_DUTY_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using CALL_OF_DUTY
        - CNSS_APP_WECHAT_DAYS_COUNT_12M: Number of days in the last 12 month(s) using WECHAT
        - CNSS_APP_WECHAT_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using WECHAT
        - CNSS_APP_KKBOX_DAYS_COUNT_12M: Number of days in the last 12 month(s) using KKBOX
        - CNSS_APP_KKBOX_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using KKBOX
        - CNSS_APP_TMALL_DAYS_COUNT_12M: Number of days in the last 12 month(s) using TMALL
        - CNSS_APP_TMALL_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using TMALL
        - CNSS_APP_BATTLENET_DAYS_COUNT_12M: Number of days in the last 12 month(s) using BATTLENET
        - CNSS_APP_BATTLENET_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using BATTLENET
        - CNSS_APP_QQMUSIC_DAYS_COUNT_12M: Number of days in the last 12 month(s) using QQMUSIC
        - CNSS_APP_QQMUSIC_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using QQMUSIC
        - CNSS_APP_DISCORD_DAYS_COUNT_12M: Number of days in the last 12 month(s) using DISCORD
        - CNSS_APP_DISCORD_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using DISCORD
        - CNSS_APP_BILIBILI_DAYS_COUNT_12M: Number of days in the last 12 month(s) using BILIBILI
        - CNSS_APP_BILIBILI_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using BILIBILI
        - CNSS_APP_FACEBOOK_LIVE_DAYS_COUNT_12M: Number of days in the last 12 month(s) using FACEBOOK_LIVE
        - CNSS_APP_FACEBOOK_LIVE_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using FACEBOOK_LIVE
        - CNSS_APP_YOUKU_DAYS_COUNT_12M: Number of days in the last 12 month(s) using YOUKU
        - CNSS_APP_YOUKU_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using YOUKU
        - CNSS_APP_WHATSAPP_DAYS_COUNT_12M: Number of days in the last 12 month(s) using WHATSAPP
        - CNSS_APP_WHATSAPP_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using WHATSAPP
        - CNSS_APP_EBAY_DAYS_COUNT_12M: Number of days in the last 12 month(s) using EBAY
        - CNSS_APP_EBAY_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using EBAY
        - CNSS_APP_POKEMON_GO_DAYS_COUNT_12M: Number of days in the last 12 month(s) using POKEMON_GO
        - CNSS_APP_POKEMON_GO_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using POKEMON_GO
        - CNSS_APP_PUBG_DAYS_COUNT_12M: Number of days in the last 12 month(s) using PUBG
        - CNSS_APP_PUBG_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using PUBG
        - CNSS_APP_ROBLOX_DAYS_COUNT_12M: Number of days in the last 12 month(s) using ROBLOX
        - CNSS_APP_ROBLOX_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using ROBLOX
        - CNSS_APP_FAST_COM_DAYS_COUNT_12M: Number of days in the last 12 month(s) using FAST_COM
        - CNSS_APP_FAST_COM_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using FAST_COM
        - CNSS_APP_JINGDONG_DAYS_COUNT_12M: Number of days in the last 12 month(s) using JINGDONG
        - CNSS_APP_JINGDONG_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using JINGDONG
        - CNSS_APP_YOUTUBE_DAYS_COUNT_12M: Number of days in the last 12 month(s) using YOUTUBE
        - CNSS_APP_YOUTUBE_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using YOUTUBE
        - CNSS_APP_TELEGRAM_DAYS_COUNT_12M: Number of days in the last 12 month(s) using TELEGRAM
        - CNSS_APP_TELEGRAM_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using TELEGRAM
        - CNSS_APP_TAOTE_DAYS_COUNT_12M: Number of days in the last 12 month(s) using TAOTE
        - CNSS_APP_TAOTE_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using TAOTE
        - CNSS_APP_IKEA_DAYS_COUNT_12M: Number of days in the last 12 month(s) using IKEA
        - CNSS_APP_IKEA_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using IKEA
        - CNSS_APP_YOUTUBE_MUSIC_DAYS_COUNT_12M: Number of days in the last 12 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_YOUTUBE_MUSIC_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using YOUTUBE_MUSIC
        - CNSS_APP_CLASH_ROYALE_DAYS_COUNT_12M: Number of days in the last 12 month(s) using CLASH_ROYALE
        - CNSS_APP_CLASH_ROYALE_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using CLASH_ROYALE
        - CNSS_APP_VIU_DAYS_COUNT_12M: Number of days in the last 12 month(s) using VIU
        - CNSS_APP_VIU_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using VIU
        - CNSS_APP_APPLE_MUSIC_DAYS_COUNT_12M: Number of days in the last 12 month(s) using APPLE_MUSIC
        - CNSS_APP_APPLE_MUSIC_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using APPLE_MUSIC
        - CNSS_APP_SPOTIFY_AUDIO_DAYS_COUNT_12M: Number of days in the last 12 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_SPOTIFY_AUDIO_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using SPOTIFY_AUDIO
        - CNSS_APP_APPLE_PAY_DAYS_COUNT_12M: Number of days in the last 12 month(s) using APPLE_PAY
        - CNSS_APP_APPLE_PAY_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using APPLE_PAY
        - CNSS_APP_FACEBOOK_VIDEO_DAYS_COUNT_12M: Number of days in the last 12 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_FACEBOOK_VIDEO_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using FACEBOOK_VIDEO
        - CNSS_APP_TAOBAO_DAYS_COUNT_12M: Number of days in the last 12 month(s) using TAOBAO
        - CNSS_APP_TAOBAO_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using TAOBAO
        - CNSS_APP_FACEBOOK_MESSENGER_DAYS_COUNT_12M: Number of days in the last 12 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_FACEBOOK_MESSENGER_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using FACEBOOK_MESSENGER
        - CNSS_APP_PINDUODUO_DAYS_COUNT_12M: Number of days in the last 12 month(s) using PINDUODUO
        - CNSS_APP_PINDUODUO_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using PINDUODUO
        - CNSS_APP_XIAOHONGSHU_DAYS_COUNT_12M: Number of days in the last 12 month(s) using XIAOHONGSHU
        - CNSS_APP_XIAOHONGSHU_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using XIAOHONGSHU
        - CNSS_APP_WHATSAPP_API_DAYS_COUNT_12M: Number of days in the last 12 month(s) using WHATSAPP_API
        - CNSS_APP_WHATSAPP_API_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using WHATSAPP_API
        - CNSS_APP_FACEBOOK_DAYS_COUNT_12M: Number of days in the last 12 month(s) using FACEBOOK
        - CNSS_APP_FACEBOOK_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using FACEBOOK
        - CNSS_APP_AMAZON_DAYS_COUNT_12M: Number of days in the last 12 month(s) using AMAZON
        - CNSS_APP_AMAZON_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using AMAZON
        - CNSS_APP_YOUTUBE_KIDS_DAYS_COUNT_12M: Number of days in the last 12 month(s) using YOUTUBE_KIDS
        - CNSS_APP_YOUTUBE_KIDS_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using YOUTUBE_KIDS
        - CNSS_APP_SINA_WEIBO_DAYS_COUNT_12M: Number of days in the last 12 month(s) using SINA_WEIBO
        - CNSS_APP_SINA_WEIBO_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using SINA_WEIBO
        - CNSS_APP_AFREECA_DAYS_COUNT_12M: Number of days in the last 12 month(s) using AFREECA
        - CNSS_APP_AFREECA_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using AFREECA
        - CNSS_APP_ALIPAY_DAYS_COUNT_12M: Number of days in the last 12 month(s) using ALIPAY
        - CNSS_APP_ALIPAY_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using ALIPAY
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DAYS_COUNT_12M: Number of days in the last 12 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_SIGNAL_PRIVATE_MESSENGER_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using SIGNAL_PRIVATE_MESSENGER
        - CNSS_APP_LINE_DAYS_COUNT_12M: Number of days in the last 12 month(s) using LINE
        - CNSS_APP_LINE_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using LINE
        - CNSS_APP_QQVIDEO_DAYS_COUNT_12M: Number of days in the last 12 month(s) using QQVIDEO
        - CNSS_APP_QQVIDEO_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using QQVIDEO
        - CNSS_APP_NETFLIX_DAYS_COUNT_12M: Number of days in the last 12 month(s) using NETFLIX
        - CNSS_APP_NETFLIX_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using NETFLIX
        - CNSS_APP_SPOTIFY_DAYS_COUNT_12M: Number of days in the last 12 month(s) using SPOTIFY
        - CNSS_APP_SPOTIFY_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using SPOTIFY
        - CNSS_APP_TWITTER_DAYS_COUNT_12M: Number of days in the last 12 month(s) using TWITTER
        - CNSS_APP_TWITTER_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using TWITTER
        - CNSS_APP_SAMSUNG_PAY_DAYS_COUNT_12M: Number of days in the last 12 month(s) using SAMSUNG_PAY
        - CNSS_APP_SAMSUNG_PAY_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using SAMSUNG_PAY
        - CNSS_APP_DISNEY_PLUS_DAYS_COUNT_12M: Number of days in the last 12 month(s) using DISNEY_PLUS
        - CNSS_APP_DISNEY_PLUS_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using DISNEY_PLUS
        - CNSS_APP_RAKUTEN_DAYS_COUNT_12M: Number of days in the last 12 month(s) using RAKUTEN
        - CNSS_APP_RAKUTEN_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using RAKUTEN
        - CNSS_APP_CANDY_CRUSH_SAGA_DAYS_COUNT_12M: Number of days in the last 12 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_CANDY_CRUSH_SAGA_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using CANDY_CRUSH_SAGA
        - CNSS_APP_MINECRAFT_DAYS_COUNT_12M: Number of days in the last 12 month(s) using MINECRAFT
        - CNSS_APP_MINECRAFT_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using MINECRAFT
        - CNSS_APP_LINKEDIN_DAYS_COUNT_12M: Number of days in the last 12 month(s) using LINKEDIN
        - CNSS_APP_LINKEDIN_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using LINKEDIN
        - CNSS_APP_CLASH_OF_CLANS_DAYS_COUNT_12M: Number of days in the last 12 month(s) using CLASH_OF_CLANS
        - CNSS_APP_CLASH_OF_CLANS_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using CLASH_OF_CLANS
        - CNSS_APP_GOOGLE_PAY_DAYS_COUNT_12M: Number of days in the last 12 month(s) using GOOGLE_PAY
        - CNSS_APP_GOOGLE_PAY_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using GOOGLE_PAY
        - CNSS_APP_STEAM_DAYS_COUNT_12M: Number of days in the last 12 month(s) using STEAM
        - CNSS_APP_STEAM_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using STEAM
        - CNSS_APP_INSTAGRAM_DAYS_COUNT_12M: Number of days in the last 12 month(s) using INSTAGRAM
        - CNSS_APP_INSTAGRAM_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using INSTAGRAM
        - CNSS_CATEGORY_STREAMING_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_MAX_DURATION_DAYS_12M: Max number of consecutive days in the last 12 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DAYS_COUNT_12M: Number of weekdays in the last 12 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKDAY_DATA_USAGE_12M: Data Usage in MB on weekdays in the last 12 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DAYS_COUNT_12M: Number of weekends in the last 12 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_WEEKEND_DATA_USAGE_12M: Data Usage in MB on weekends in the last 12 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_STREAMING_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_STREAMING_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_MUSIC_STREAMING_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category MUSIC_STREAMING
        - CNSS_CATEGORY_COMMUNICATION_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_COMMUNICATION_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category COMMUNICATION
        - CNSS_CATEGORY_PAYMENT_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_PAYMENT_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category PAYMENT
        - CNSS_CATEGORY_VPN_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category VPN
        - CNSS_CATEGORY_VPN_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category VPN
        - CNSS_CATEGORY_SOCIAL_NETWORK_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_SOCIAL_NETWORK_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category SOCIAL_NETWORK
        - CNSS_CATEGORY_ECOMMERCE_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_ECOMMERCE_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category ECOMMERCE
        - CNSS_CATEGORY_GAMING_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category GAMING
        - CNSS_CATEGORY_GAMING_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category GAMING
        - CNSS_CATEGORY_SPEED_TEST_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_SPEED_TEST_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category SPEED_TEST
        - CNSS_CATEGORY_RETAIL_DAYS_COUNT_12M: Number of days in the last 12 month(s) using apps in category RETAIL
        - CNSS_CATEGORY_RETAIL_DATA_USAGE_12M: Data Usage in MB in the last 12 month(s) using apps in category RETAIL

    Returns:
        DataFrame: A dataframe with the columns listed above
    """
    return calculate_features(spark, target_month)
