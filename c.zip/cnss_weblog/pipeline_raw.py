from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F
from datetime import datetime, timedelta
import argparse, logging
from src.path import s11_raw_path, s11_src_path ,ebm_raw_path, ebm_src_path, pfcp_raw_path, pfcp_src_path
from src.schema import ebm_schema, schema, pfcp_schema
from src.cnss_configs import S11_APP_LIST


def make_s11_raw(run_date: datetime):
    yyyymmdd = run_date.strftime('%Y%m%d')
    s11_raw = spark.read.option("basePath", s11_src_path).option('header','False').schema(schema).csv(
        s11_src_path+'/part_key='+yyyymmdd
    )

    s11_raw = s11_raw.filter(F.col('service_name').isin(S11_APP_LIST))\
            .filter(F.trim(F.col("msisdn")) != "")\
            .filter(
                (F.col('msisdn').isNotNull()) & 
                (F.col('packets_dl').isNotNull()) & 
                (F.col('bytes_dl').isNotNull())
            ).select(
                'imsi',
                'msisdn',
                'timeperiod',
                'service_name',
                'bytes_dl',
                'bytes_ul',
                'packets_dl',
                'packets_ul',
                'part_key'
            ).cache()

    s11_raw.repartitionByRange(100,'msisdn').write.mode('overwrite').parquet(f'{s11_raw_path}/{yyyymmdd}')


def make_pfcp_raw(run_date: datetime):
    yyyymmdd = run_date.strftime('%Y%m%d')
    fpcp_raw = spark.read.option("basePath", pfcp_src_path).option('header','False').schema(pfcp_schema).csv(
        pfcp_src_path+'/trx_date='+yyyymmdd
    )

    fpcp_raw = fpcp_raw.filter(F.col('service_name').isin(S11_APP_LIST))\
            .filter(F.trim(F.col("msisdn")) != "")\
            .filter(
                (F.col('msisdn').isNotNull()) & 
                (F.col('downlink_packets').isNotNull()) & 
                (F.col('downlink_bytes').isNotNull())
            ).select(
                'start_time',
                'end_time',
                'imsi',
                'msisdn',
                'service_name',
                'downlink_packets',
                'downlink_bytes',
                'downlink_duration',
                'uplink_packets',
                'uplink_bytes',
                'uplink_duration',
                'trx_date'
            ).cache()

    fpcp_raw.repartitionByRange(100,'msisdn').write.mode('overwrite').parquet(f'{pfcp_raw_path}/{yyyymmdd}')


def make_ebm_raw(run_date: datetime):
    yyyymmdd = run_date.strftime('%Y%m%d')
    ebm_raw = spark.read.schema(ebm_schema).csv(
        ebm_src_path.format(yyyymmdd), sep=';'
    )

    ebm_cleaned = ebm_raw.filter(
                        F.col('service_id').startswith('app-adc-') | 
                        F.col('service_id').startswith('app-heur-')
                    )\
                    .filter(F.trim(F.col("msisdn")) != "")\
                    .filter(
                        (F.col('msisdn').isNotNull()) & 
                        (F.col('service_dl_bytes').isNotNull())
                    ).select(
                        'imsi',
                        'msisdn',
                        'service_id',
                        'service_dl_bytes',
                        'service_ul_bytes',
                        'duration',
                        'time',
                        'trx_date'
                    ).distinct().cache()

    ebm_cleaned.repartitionByRange(100,'msisdn').write.mode('overwrite').parquet(
        f"{ebm_raw_path}/{yyyymmdd}"
    )


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str, default='', help='yyyy-mm-dd of the date of data files')
    args = parser.parse_args()

    spark = SparkSession.builder.appName("cnss-raw").getOrCreate()

    def get_dates_in_month(yyyymm):
        year = int(yyyymm[:4])
        month = int(yyyymm[4:])
        date = datetime(year, month, 1)
        dates = []
        while date.month == month:
            dates.append(date.strftime("%Y%m%d"))
            date += timedelta(days=1)
        return dates

    make_ebm_raw(datetime.strptime(args.run_date, '%Y-%m-%d'))
    make_pfcp_raw(datetime.strptime(args.run_date, '%Y-%m-%d'))
    make_s11_raw(datetime.strptime(args.run_date, '%Y-%m-%d'))