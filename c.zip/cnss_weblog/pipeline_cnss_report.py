from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import LongType
import argparse
from datetime import datetime, timedelta
from src.cnss_configs import S11_EBM_MAPPING_TABLE
from src.path import s11_raw_path, bp_table_raw_path, bm_table_path, pfcp_raw_path, ebm_raw_path


def get_last_day_prev_month(date_str: str) -> str:
    input_date = datetime.strptime(date_str, "%Y-%m-%d")
    first_day_current_month = input_date.replace(day=1)
    last_day_prev_month = first_day_current_month - timedelta(days=1)
    return last_day_prev_month


def read_cnss_s11(spark: SparkSession, run_date: datetime) -> DataFrame:
    return spark.read.parquet(
        *[
            s11_raw_path + '/' + (run_date - timedelta(days=i)).strftime('%Y%m%d')
            for i in range(run_date.day)
        ]
    )


def read_pfcp(spark: SparkSession, run_date: datetime) -> DataFrame:
    return spark.read.parquet(
        *[
            pfcp_raw_path + '/' + (run_date - timedelta(days=i)).strftime('%Y%m%d')
            for i in range(run_date.day+1)
        ]
    )


def read_ebm(spark: SparkSession, run_date: datetime) -> DataFrame:
    return spark.read.parquet(
        *[
            ebm_raw_path + '/' + (run_date - timedelta(days=i)).strftime('%Y%m%d')
            for i in range(run_date.day+1)
        ]
    )


def read_bp_table(spark: SparkSession, run_date: datetime) -> DataFrame:
    return spark.read.parquet(
        *[
            bp_table_raw_path + '/' + (run_date - timedelta(days=i)).strftime('%Y%m%d')
            for i in range(run_date.day)
        ]
    )


def clean_cnss_s11(raw_df: DataFrame, app_list):
    return raw_df.withColumn('BYTE_PER_PACKET_DL', F.col('bytes_dl') / F.col('packets_dl'))\
                .withColumn(
                    "SUBR_NUM",
                    F.when(F.col("msisdn").startswith("852"), F.substring("msisdn", 4, 20))
                    .otherwise(F.col("msisdn"))
                )\
                .withColumnRenamed("service_name", "APP_NAME")\
                .withColumnRenamed("part_key", "DATE_ID")\
                .filter(
                    (F.col('service_name').isin(app_list)) & 
                    (F.col('BYTE_PER_PACKET_DL')>=900)
                ).groupBy('SUBR_NUM','APP_NAME','imsi','DATE_ID')\
                .agg(
                    F.sum(F.col('bytes_dl')/1000/1000).alias('USG_MB'),
                    F.count('*').alias('DURATION_MINUTES'),
                )


def clean_ebm(raw_df: DataFrame, app_list, yyyymm):
    mapping = [(key, value) for key, value in S11_EBM_MAPPING_TABLE.items()]
    mapping_df = spark.createDataFrame(mapping, schema=["service_id", "APP_NAME"])

    return raw_df.withColumn(
                    "SUBR_NUM",
                    F.when(F.col("msisdn").startswith("852"), F.substring("msisdn", 4, 20))
                    .otherwise(F.col("msisdn"))
                ).withColumn(
                    "DATE_ID",
                    F.date_format(F.from_unixtime(F.col("time").cast("long")+8*3600), "yyyyMMdd")
                ).withColumn(
                    "yyyymmddhhmm",
                    F.date_format(F.from_unixtime(F.col("time").cast("long")+8*3600), "yyyyMMddHHmm")
                )\
                .filter(col('DATE_ID').startswith(yyyymm))\
                .join(F.broadcast(mapping_df), 'service_id', 'left')\
                .withColumnRenamed("service_dl_bytes", "DL_BYTES")\
                .filter(F.col('APP_NAME').isin(app_list))\
                .groupBy('SUBR_NUM','APP_NAME','imsi','DATE_ID')\
                .agg(
                    F.sum(F.col('DL_BYTES')/1000/1000).alias('USG_MB'),
                    F.countDistinct('yyyymmddhhmm').alias('ACTIVE_MINUTES'),
                )


def clean_pfcp(raw_df: DataFrame, app_list, yyyymm):
    return raw_df.withColumn('BYTE_PER_PACKET_DL', F.col('downlink_bytes') / F.col('downlink_packets'))\
                .withColumn(
                    "SUBR_NUM",
                    F.when(F.col("msisdn").startswith("852"), F.substring("msisdn", 4, 20))
                    .otherwise(F.col("msisdn"))
                )\
                .withColumnRenamed("service_name", "APP_NAME")\
                .withColumn(
                    "DATE_ID",
                    F.date_format(F.from_unixtime(F.col("end_time").cast("long")/1000+8*3600), "yyyyMMdd")
                ).withColumn(
                    "yyyymmddhhmm",
                    F.date_format(F.from_unixtime(F.col("end_time").cast("long")/1000+8*3600), "yyyyMMddHHmm")
                )\
                .filter(col('DATE_ID').startswith(yyyymm))\
                .filter(
                    (F.col('service_name').isin(app_list)) & 
                    (F.col('BYTE_PER_PACKET_DL')>=900)
                ).groupBy('SUBR_NUM','APP_NAME','imsi','DATE_ID')\
                .agg(
                    F.sum(F.col('downlink_bytes')/1000/1000).alias('USG_MB'),
                    F.count('*').alias('DURATION_MINUTES'),
                    F.countDistinct('yyyymmddhhmm').alias('ACTIVE_MINUTES'),
                )


def clean_bp_table(raw_df: DataFrame, app_list):
    return raw_df.withColumn(
                    "SUBR_NUM",
                    F.when(F.col("msisdn").startswith("852"), F.substring("msisdn", 4, 20))
                    .otherwise(F.col("msisdn"))
                )\
                .filter(F.col("USG_MB") > 0.0)\
                .filter(F.trim(F.col("SUBR_NUM")) != "")\
                .withColumn("DATE_ID", F.date_format("ACCS_DATE", "yyyyMMdd"))\
                .withColumn(
                    "APP_NAME",
                    F.when(F.col('APP_NAME')=='""', F.col('SERVICE_NAME')).otherwise(F.col('APP_NAME'))
                )\
                .filter(F.col('APP_NAME').isin(app_list))\
                .groupBy('SUBR_NUM','APP_NAME','imsi','FILE_TYPE')\
                .agg(
                    F.sum(F.col('USG_MB')).alias('USG_MB'),
                    F.count('*').alias('DURATION_MINUTES'),
                    F.countDistinct('DATE_ID').alias('DISTINCT_DATE_COUNT')
                )


def make_report(spark: SparkSession, yyyymmdd: str):

    run_date = get_last_day_prev_month(yyyymmdd)
    run_date_yyyymm = run_date.strftime('%Y%m')
    apps_list = ['disney_plus', 'netflix']

    bm = spark.read.parquet(bm_table_path).filter(F.col('NOMINATION_FLG')=='Y').select('SUBR_NUM').withColumn('is_BM', F.lit(1)).distinct()
    s11 = read_cnss_s11(spark, run_date)
    pfcp = read_pfcp(spark, run_date)

    s11_cleaned = clean_cnss_s11(s11, apps_list)
    pfcp_cleaned = clean_pfcp(pfcp, apps_list, run_date_yyyymm)

    s11_cleaned.repartitionByRange(100,'SUBR_NUM').write.mode('overwrite').parquet(
        f'dtap://TenantStorage/ws-michael/adhoc/cnss/s11_{run_date_yyyymm}'
    )
    pfcp_cleaned.repartitionByRange(100,'SUBR_NUM').write.mode('overwrite').parquet(
        f'dtap://TenantStorage/ws-michael/adhoc/cnss/pfcp_{run_date_yyyymm}'
    )

    s11 = spark.read.parquet(f'dtap://TenantStorage/ws-michael/adhoc/cnss/s11_{run_date_yyyymm}').withColumn('s11', F.lit(1))
    pfcp = spark.read.parquet(f'dtap://TenantStorage/ws-michael/adhoc/cnss/pfcp_{run_date_yyyymm}').withColumn('pfcp', F.lit(1))

    s11_pfcp = s11.join(pfcp, ['SUBR_NUM','APP_NAME','imsi','USG_MB','DURATION_MINUTES','DATE_ID'], 'outer')\
                    .withColumn('ACTIVE_MINUTES', 
                                F.when(
                                    col('ACTIVE_MINUTES').isNull(), col('DURATION_MINUTES')
                                ).otherwise(col('ACTIVE_MINUTES'))
                    ).fillna(0)\
                    .groupBy(['SUBR_NUM','APP_NAME','imsi'])\
                    .agg(
                        F.sum('USG_MB').alias('USG_MB'),
                        F.sum('DURATION_MINUTES').alias('DURATION_MINUTES'),
                        F.countDistinct('DATE_ID').alias('DISTINCT_DATE_COUNT'),
                        F.sum('ACTIVE_MINUTES').alias('ACTIVE_MINUTES'),
                        F.max('s11').alias('s11'),
                        F.max('pfcp').alias('pfcp')
                    )

    s11_pfcp\
        .withColumn('is_HBB', F.when(
                (col('SUBR_NUM').startswith('19943')) |
                (col('SUBR_NUM').startswith('19944')) |
                (col('SUBR_NUM').startswith('19945')) |
                (col('SUBR_NUM').startswith('19946')), 1).otherwise(0)
        ).join(bm,'SUBR_NUM','left').fillna(0).distinct()\
        .coalesce(1).write.format("csv").option("header", "true").mode("overwrite")\
        .save(f'dtap://TenantStorage/cnss/adhoc/report_s11_pfcp_{run_date_yyyymm}.csv')


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('run_date', type=str, default='', help='yyyy-mm-dd of the date of data files')
    args = parser.parse_args()

    spark = SparkSession.builder.appName("vas_report").getOrCreate()

    make_report(spark, args.run_date)